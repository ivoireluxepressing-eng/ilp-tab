
// ════════════════════════════════════════════════════════
// CONSTANTS & DEFAULTS
// ════════════════════════════════════════════════════════
const WF   = ['reçu','lavage','séchage','repassage','prêt','livré'];
const WFI  = ['📥','🫧','💨','♨️','✅','🚚'];
const WF_H = [0,4,8,12,18,72];
const SK   = 'ilp_v3';

const THEMES = [
  {name:'Bleu Marine',  icon:'🔵', n:'#060d1f',c:'#0b1630',s:'#0f1e3a',s2:'#162245',s3:'#1c2a52',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Noir Charbon', icon:'⚫', n:'#080808',c:'#111111',s:'#161616',s2:'#1e1e1e',s3:'#252525',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Vert Forêt',   icon:'🌿', n:'#030f07',c:'#061a0d',s:'#092414',s2:'#0d301a',s3:'#113d21',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Bordeaux',     icon:'🍷', n:'#120406',c:'#200608',s:'#2e090c',s2:'#3d0c0f',s3:'#4d1013',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Violet Royal', icon:'💜', n:'#08060f',c:'#110d1e',s:'#17112d',s2:'#1e163c',s3:'#261b4b',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Chocolat',     icon:'🍫', n:'#0f0804',c:'#1e1108',s:'#2c190c',s2:'#3a2110',s3:'#472914',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Nuit Dorée',   icon:'🌙', n:'#0a0800',c:'#16110a',s:'#201a0f',s2:'#2a2214',s3:'#342b1a',or:'#e8c96a',oc:'#f5e090',of:'#c9a84c',om:'#a07830'},
  {name:'Ardoise',      icon:'🔷', n:'#060a0f',c:'#0d1520',s:'#111d2b',s2:'#162438',s3:'#1b2d46',or:'#c9a84c',oc:'#e8c96a',of:'#8a6b28',om:'#6b5020'},
  {name:'Clair Doré',   icon:'☀️', n:'#f8f5ee',c:'#ede8dc',s:'#e4dece',s2:'#d8d0bc',s3:'#ccc4aa',or:'#8a6b28',oc:'#6b5020',of:'#5a4015',om:'#4a3412'},
];

// Default admin users (stored in localStorage if none exist)
const DEFAULT_USERS = [
  {id:'ADM001', name:'M. Tobo', role:'admin',         site:'Les deux',    pw:'admin123',  since:'2024-01-01'},
  {id:'GER001', name:'Gérant Bingerville', role:'gerant',       site:'Bingerville', pw:'gerant123', since:'2024-01-01'},
  {id:'REC001', name:'Réceptionniste 1',   role:'receptionniste',site:'Bingerville', pw:'recep123',  since:'2024-01-01'},
  {id:'REC002', name:'Réceptionniste 2',   role:'receptionniste',site:'Jacqueville',  pw:'recep456',  since:'2024-01-01'},
];

// Role configs — which pages each role can see
const ROLE_MENUS = {
  admin: [
    {id:'accueil', label:'Accueil', ico:'🏠'},
    {id:'ops',     label:'Opérations', ico:'⚙️', badge:'retards'},
    {id:'commandes',label:'Commandes', ico:'📋'},
    {id:'clients', label:'Clients', ico:'👥'},
    {id:'relance',  label:'Relances', ico:'🔔', badge:'relances'},
    {id:'process', label:'Process', ico:'🧺'},
    {id:'facturation',label:'Facturation', ico:'💳'},
    {id:'livraisons', label:'Livraisons', ico:'🚚'},
    {id:'historique', label:'Historique', ico:'📊'},
    {id:'tarifs',  label:'Tarifs', ico:'💰'},
    {id:'prospects',label:'Prospects', ico:'🎯'},
    {id:'bilan',   label:'Bilan Clients', ico:'📊'},
    {id:'stock_linge', label:'Stock Linge', ico:'🧺'},
    {id:'stock_produits', label:'Produits', ico:'🧴'},
    {id:'charges', label:'Charges', ico:'💸'},
    {id:'employes', label:'Employés', ico:'👨‍💼'},
    {id:'chat',    label:'Chat Équipe', ico:'💬', badge:'chat'},
    {id:'users',   label:'Utilisateurs', ico:'🔐'},
    {id:'notifs',  label:'Notifications', ico:'🔔', badge:'notifs'},
    {id:'params',  label:'Paramètres', ico:'⚙️'},
  ],
  gerant: [
    {id:'accueil', label:'Accueil', ico:'🏠'},
    {id:'ops',     label:'Opérations', ico:'⚙️', badge:'retards'},
    {id:'commandes',label:'Commandes', ico:'📋'},
    {id:'clients', label:'Clients', ico:'👥'},
    {id:'relance',  label:'Relances', ico:'🔔', badge:'relances'},
    {id:'process', label:'Process', ico:'🧺'},
    {id:'facturation',label:'Facturation', ico:'💳'},
    {id:'livraisons', label:'Livraisons', ico:'🚚'},
    {id:'prospects',label:'Prospects', ico:'🎯'},
    {id:'historique', label:'Historique', ico:'📊'},
    {id:'stock_linge', label:'Stock Linge', ico:'🧺'},
    {id:'stock_produits', label:'Produits', ico:'🧴'},
    {id:'chat',    label:'Chat Équipe', ico:'💬', badge:'chat'},
    {id:'notifs',  label:'Notifications', ico:'🔔', badge:'notifs'},
    {id:'params',  label:'Paramètres', ico:'⚙️'},
  ],
  receptionniste: [
    {id:'accueil', label:'Accueil', ico:'🏠'},
    {id:'commandes',label:'Commandes', ico:'📋'},
    {id:'clients', label:'Clients', ico:'👥'},
    {id:'relance',  label:'Relances', ico:'🔔', badge:'relances'},
    {id:'process', label:'Process', ico:'🧺'},
    {id:'tarifs',  label:'Articles', ico:'🏷️'},
    {id:'stock_linge', label:'Stock Linge', ico:'🧺'},
    {id:'stock_produits', label:'Produits', ico:'🧴'},
    {id:'prospects',label:'Prospects', ico:'🎯'},
    {id:'chat',    label:'Chat Équipe', ico:'💬', badge:'chat'},
    {id:'notifs',  label:'Notifications', ico:'🔔', badge:'notifs'},
    {id:'profil',  label:'Mon profil', ico:'👤'},
  ],
};

// ════════════════════════════════════════════════════════
// DATABASE + SUPABASE BACKEND
// ════════════════════════════════════════════════════════
const SB_URL = 'https://jwrkwhzrqspjehqurdao.supabase.co';
const SB_KEY = 'sb_publishable_LMIwg3fscx0t2Q3WJc4DPg_ikqm0OmH';
let _supa = null; // initialized in DOMContentLoaded after SDK loads

let DB = {users:[], clients:[], commandes:[], items:[], notifs:[], tarifs:[], prospects:[], relancesAuto:[], bilans:[], stockLinge:[], stockProduits:[], stockMouvements:[], charges:[], employes:[], salaires:[], chat:[]};
let CU = null; // current user
let _dbReady = false;

// ── Loading overlay ──────────────────────────────────────
function showLoadingOverlay(show){
  let el = document.getElementById('_sbOverlay');
  if(!el){
    el = document.createElement('div');
    el.id = '_sbOverlay';
    el.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.93);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:9999;font-family:var(--f-u);color:var(--or);gap:14px;transition:opacity .3s;';
    el.innerHTML='<div style="font-size:2rem">☁️</div><div style="font-size:.9rem;letter-spacing:.14em">SYNCHRONISATION…</div><div style="width:52px;height:3px;background:var(--or-muted);border-radius:2px;overflow:hidden"><div id="_sbBar" style="height:100%;background:var(--or);width:0%;transition:width .4s ease-out"></div></div>';
    document.body.appendChild(el);
    setTimeout(()=>{ const b=document.getElementById('_sbBar');if(b)b.style.width='75%'; },80);
  }
  if(show){ el.style.display='flex'; el.style.opacity='1'; }
  else{
    const b=document.getElementById('_sbBar');if(b)b.style.width='100%';
    setTimeout(()=>{ el.style.opacity='0'; setTimeout(()=>{ el.style.display='none'; },300); },250);
  }
}

// ── Supabase helpers ─────────────────────────────────────
async function _sbFetch(table){
  const {data,error}=await _supa.from(table).select('*');
  if(error){ console.warn('SB fetch',table,error); return []; }
  return data||[];
}
async function _sbFetchChat(){
  const {data,error}=await _supa.from('ilp_chat').select('*').order('createdAt',{ascending:false}).limit(100);
  if(error){ console.warn('SB fetch chat',error); return []; }
  return (data||[]).reverse();
}

// ── saveDB : upsert all in-memory data to Supabase ───────
async function saveDB(){
  // ── Projette chaque objet JS sur les colonnes exactes de Supabase ──
  function _pick(obj, keys){ const r={}; keys.forEach(k=>{ if(obj[k]!==undefined) r[k]=obj[k]; }); return r; }

  const COLS = {
    ilp_users:      ['id','name','role','site','pw','since','bio_cred'],
    ilp_clients:    ['id','nom','tel','type','ville','email','notes','createdBy','since'],
    ilp_commandes:  ['id','clientId','statut','site','dateEntree','dateDelai','avance','notes','createdBy','etapes'],
    ilp_items:      ['id','cmdId','art','prix','qte'],
    ilp_notifs:     ['id','type','msg','time','read','categorie','clientId','cmdId','byUser','byRole','forRoles'],
    ilp_prospects:  ['id','nom','tel','email','ville','type','notes','statut','createdBy','createdAt','lastRelance','nextRelance','relanceCount'],
    ilp_relances_auto:['id','clientId','prospectId','type','message','scheduledAt','sent','sentAt','createdBy','createdAt'],
    ilp_bilans:     ['id','clientId','mois','annee','totalCommandes','totalCA','totalEncaisse','totalReste','generatedBy','generatedAt'],
    ilp_stock_linge:['id','clientId','article','quantite','categorie','description','statut','dateEntree','dateSortie','cmdId','createdBy','site','notes'],
    ilp_stock_produits:['id','nom','categorie','unite','quantite','seuil_alerte','prix_achat','fournisseur','description','lastUpdate','updatedBy'],
    ilp_stock_mouvements:['id','produitId','type','quantite','motif','createdBy','createdAt'],
    ilp_charges:    ['id','libelle','montant','categorie','periodicite','date_charge','site','paidBy','justificatif','createdBy','createdAt'],
    ilp_employes:   ['id','nom','prenom','poste','site','salaire_base','telephone','email','date_embauche','statut','userId','notes','createdAt'],
    ilp_salaires:   ['id','employeId','mois','annee','montant','statut','paidAt','paidBy','notes','createdAt'],
    ilp_chat:       ['id','fromId','fromName','fromRole','fromSite','msg','type','toId','readBy','createdAt'],
  };

  async function _up(table, row){
    const cols = COLS[table];
    const clean = cols ? _pick(row, cols) : row;
    if(!clean.id){ console.warn(`[ILP] saveDB skip — ${table} row has no id`); return; }
    const {error} = await _supa.from(table).upsert(clean, {onConflict:'id'});
    if(error) console.error(`[ILP] saveDB ERROR — ${table}:`, error.message, clean);
  }

  try{
    const tasks = [];
    DB.users.forEach(r        => tasks.push(_up('ilp_users',    r)));
    DB.clients.forEach(r      => tasks.push(_up('ilp_clients',  r)));
    DB.commandes.forEach(r    => tasks.push(_up('ilp_commandes',r)));
    DB.items.forEach(r        => tasks.push(_up('ilp_items',    r)));
    DB.notifs.forEach(r       => tasks.push(_up('ilp_notifs',   r)));
    DB.prospects.forEach(r    => tasks.push(_up('ilp_prospects', r)));
    DB.relancesAuto.forEach(r => tasks.push(_up('ilp_relances_auto', r)));
    DB.bilans.forEach(r       => tasks.push(_up('ilp_bilans', r)));
    DB.stockLinge.forEach(r   => tasks.push(_up('ilp_stock_linge', r)));
    DB.stockProduits.forEach(r=> tasks.push(_up('ilp_stock_produits', r)));
    DB.stockMouvements.forEach(r=>tasks.push(_up('ilp_stock_mouvements', r)));
    DB.charges.forEach(r      => tasks.push(_up('ilp_charges', r)));
    DB.employes.forEach(r     => tasks.push(_up('ilp_employes', r)));
    DB.salaires.forEach(r     => tasks.push(_up('ilp_salaires', r)));
    tasks.push(_up('ilp_config', {id:'tarifs', data:JSON.stringify(DB.tarifs)}));
    // Chat: géré par INSERT direct dans sendChatMsg (pas de upsert global)
    await Promise.all(tasks);
    console.log(`[ILP] saveDB OK — clients:${DB.clients.length} commandes:${DB.commandes.length} employes:${DB.employes.length} charges:${DB.charges.length}`);
    // Postgres Changes déclenche la sync automatique sur tous les appareils
  }catch(e){ console.error('[ILP] saveDB FATAL', e); }
}

// ── loadDB : fetch everything from Supabase ───────────────
async function loadDB(){
  showLoadingOverlay(true);
  try{
    const [users,clients,commandes,items,notifs,cfg,prospects,relancesAuto,bilans,stockLinge,stockProduits,stockMouvements,charges,employes,salaires,chat] = await Promise.all([
      _sbFetch('ilp_users'), _sbFetch('ilp_clients'), _sbFetch('ilp_commandes'),
      _sbFetch('ilp_items'), _sbFetch('ilp_notifs'),  _sbFetch('ilp_config'),
      _sbFetch('ilp_prospects'), _sbFetch('ilp_relances_auto'), _sbFetch('ilp_bilans'),
      _sbFetch('ilp_stock_linge'), _sbFetch('ilp_stock_produits'), _sbFetch('ilp_stock_mouvements'),
      _sbFetch('ilp_charges'), _sbFetch('ilp_employes'), _sbFetch('ilp_salaires'), _sbFetchChat(),
    ]);
    console.log(`[ILP] loadDB — users:${users.length} clients:${clients.length} commandes:${commandes.length} items:${items.length}`);
    DB.users     = users.length ? users : [...DEFAULT_USERS];
    DB.clients   = clients;
    DB.commandes = commandes;
    DB.items     = items;
    DB.notifs    = notifs;
    DB.prospects = prospects || [];
    DB.relancesAuto   = relancesAuto || [];
    DB.bilans         = bilans || [];
    DB.stockLinge     = stockLinge || [];
    DB.stockProduits  = stockProduits || [];
    DB.stockMouvements= stockMouvements || [];
    DB.charges        = charges || [];
    DB.employes       = employes || [];
    DB.salaires       = salaires || [];
    // Chat: normaliser readBy (JSONB peut arriver comme string ou array)
    DB.chat = (chat||[]).map(m=>{
      if(typeof m.readBy === 'string') try { m.readBy=JSON.parse(m.readBy); } catch(e){ m.readBy=[]; }
      if(!Array.isArray(m.readBy)) m.readBy=[];
      return m;
    }).sort((a,b)=>new Date(a.createdAt)-new Date(b.createdAt));
    const tarifRow = cfg.find(r=>r.id==='tarifs');
    DB.tarifs = tarifRow ? JSON.parse(tarifRow.data) : defaultTarifs();
    // Bootstrap first run
    if(!users.length) await Promise.all(DEFAULT_USERS.map(u=>_supa.from('ilp_users').upsert(u,{onConflict:'id'})));
    if(!tarifRow) await _supa.from('ilp_config').upsert({id:'tarifs',data:JSON.stringify(DB.tarifs)},{onConflict:'id'});
    _dbReady=true;
  }catch(e){
    console.error('[ILP] loadDB ERROR',e);
    _dbReady=true;
  }
  showLoadingOverlay(false);
}

function initBlank(){
  DB = {users:[...DEFAULT_USERS],clients:[],commandes:[],items:[],notifs:[],tarifs:defaultTarifs(),prospects:[],relancesAuto:[],bilans:[],stockLinge:[],stockProduits:[],stockMouvements:[],charges:[],employes:[],salaires:[]};
  saveDB(); // fire-and-forget ok here
}

// ════════════════════════════════════════════════════════
// REALTIME SYNC  (instant push to all connected devices)
// ════════════════════════════════════════════════════════
let _rtChannel  = null;
let _rtPending  = false; // anti-rebond: une seule sync à la fois
let _rtRetryTimer = null;
let _rtConnected  = false;

// ── Tables → pages à re-render après changement ──────────
const RT_TABLE_PAGES = {
  ilp_clients:      ['clients','accueil','relance'],
  ilp_commandes:    ['commandes','ops','accueil','facturation','livraisons'],
  ilp_items:        ['commandes','ops','facturation'],
  ilp_notifs:       ['notifs'],
  ilp_prospects:    ['prospects','accueil'],
  ilp_stock_linge:  ['stock_linge'],
  ilp_stock_produits:['stock_produits'],
  ilp_stock_mouvements:['stock_produits'],
  ilp_charges:      ['charges'],
  ilp_employes:     ['employes'],
  ilp_salaires:     ['employes'],
  ilp_relances_auto:['relance'],
  ilp_users:        ['profil','users'],
  ilp_config:       ['tarifs'],
};

// ── Handler central : recharger DB + re-render page active ──
let _syncThrottle = null;
function _onRemoteChange(table, event, row){
  // Ignorer mes propres changements (optimistic updates)
  // On re-sync quand c'est un autre appareil
  if(_syncThrottle) clearTimeout(_syncThrottle);
  _syncThrottle = setTimeout(async () => {
    if(!CU) return;
    if(_rtPending) return;
    _rtPending = true;
    try {
      await loadDB();
      // Vérifier que la session est toujours valide
      const fresh = DB.users.find(u => u.id===CU.id && u.pw===CU.pw);
      if(!fresh){ doLogout(); return; }
      CU = fresh; sessionStorage.setItem('ilp_cu', JSON.stringify(CU));
      // Re-render la page active si elle est concernée
      const pages = RT_TABLE_PAGES[table] || [];
      if(pages.includes(curPage) || table==='ilp_users'){
        _renderedPages.delete(curPage);
        if(RENDER_MAP[curPage]) RENDER_MAP[curPage]();
        _renderedPages.add(curPage);
      }
      updateBadges();
      // Toast discret
      _showSyncIndicator();
    } finally {
      _rtPending = false;
    }
  }, 400); // 400ms throttle pour grouper plusieurs changements simultanés
}

// ── Petit indicateur de sync (non-intrusif) ──────────────
let _syncToastTimer = null;
function _showSyncIndicator(){
  const el = document.getElementById('_syncDot');
  if(!el) return;
  el.style.opacity = '1';
  if(_syncToastTimer) clearTimeout(_syncToastTimer);
  _syncToastTimer = setTimeout(() => { el.style.opacity='0'; }, 2000);
}

function _startRealtime(){
  if(_rtChannel) return;

  // ── Canal Postgres Changes sur toutes les tables ─────────
  let ch = _supa.channel('ilp-sync-all', {
    config: { broadcast: { self: false } }
  });

  // Abonner à chaque table
  Object.keys(RT_TABLE_PAGES).forEach(table => {
    ch = ch.on('postgres_changes',
      { event: '*', schema: 'public', table },
      (payload) => _onRemoteChange(table, payload.eventType, payload.new || payload.old)
    );
  });

  _rtChannel = ch.subscribe((status, err) => {
    if(status === 'SUBSCRIBED'){
      _rtConnected = true;
      console.log('[ILP] Realtime connecté — toutes tables');
    }
    if(status === 'CHANNEL_ERROR' || status === 'TIMED_OUT'){
      _rtConnected = false;
      console.warn('[ILP] Realtime déconnecté:', status, err);
      _scheduleRtReconnect();
    }
    if(status === 'CLOSED'){
      _rtConnected = false;
    }
  });

  // Alertes réceptionniste → managers (broadcast reste pour les notifs urgentes)
  if(CU && ['admin','gerant'].includes(CU.role)){
    _supa.channel('ilp-manager-alerts')
      .on('broadcast', {event:'receptionniste_action'}, ({payload})=>{
        if(!payload) return;
        const n = {
          id:uid('N'), type:payload.type||'info',
          msg:payload.msg, time:Date.now(), read:false,
          categorie:payload.categorie||'general',
          clientId:payload.clientId||null, cmdId:payload.cmdId||null,
          byUser:payload.byUser, byRole:'receptionniste', forRoles:'managers'
        };
        DB.notifs.push(n);
        updateBadges();
        if(payload.urgent) showToast('🔔 '+payload.byUser+' — '+payload.msg,'');
        if(payload.cmdId && curPage==='commandes') renderCommandes();
        if(payload.cmdId && curPage==='ops') renderOps();
        if(curPage==='notifs') renderNotifs();
      })
      .subscribe();
  }
}

function _scheduleRtReconnect(){
  if(_rtRetryTimer) return;
  _rtRetryTimer = setTimeout(() => {
    _rtRetryTimer = null;
    if(!_rtConnected && CU){
      console.log('[ILP] Tentative reconnexion Realtime...');
      if(_rtChannel){ _supa.removeChannel(_rtChannel); _rtChannel=null; }
      _startRealtime();
    }
  }, 5000);
}

function _stopRealtime(){
  if(_rtRetryTimer){ clearTimeout(_rtRetryTimer); _rtRetryTimer=null; }
  if(_rtChannel){ _supa.removeChannel(_rtChannel); _rtChannel=null; }
  _rtConnected = false;
  _stopPresence();
}

// ════════════════════════════════════════════════════════
// PRÉSENCE EN LIGNE — Supabase Realtime Presence
// ════════════════════════════════════════════════════════
let _presenceChannel = null;
let _presenceHeartbeat = null;
let _presenceState = {}; // { userId: {userName, userRole, userSite, lastSeen, device} }

const ROLE_COLORS = {
  admin:          { bg:'rgba(201,168,76,.25)',  border:'rgba(201,168,76,.6)',  text:'#c9a84c' },
  gerant:         { bg:'rgba(122,188,224,.22)', border:'rgba(122,188,224,.5)', text:'#7abce0' },
  receptionniste: { bg:'rgba(90,200,136,.18)',  border:'rgba(90,200,136,.4)',  text:'#5ac888' },
};

function _deviceLabel(){
  const ua = navigator.userAgent.toLowerCase();
  if(/iphone|ipad/.test(ua)) return '📱 iOS';
  if(/android/.test(ua))      return '📱 Android';
  if(/mac/.test(ua))          return '💻 Mac';
  if(/win/.test(ua))          return '🖥 Windows';
  return '🌐 Web';
}

async function _startPresence(){
  if(!_supa || !CU) return;
  if(_presenceChannel) return;

  // Upsert dans la table ilp_presence
  await _supa.from('ilp_presence').upsert({
    userId:   CU.id,
    userName: CU.name,
    userRole: CU.role,
    userSite: CU.site,
    lastSeen: new Date().toISOString(),
    isOnline: true,
    device:   _deviceLabel()
  }, {onConflict:'userId'});

  // Canal Realtime Presence (broadcast de la liste)
  _presenceChannel = _supa.channel('ilp-presence', {
    config: { presence: { key: CU.id } }
  });

  _presenceChannel
    .on('presence', { event: 'sync' }, () => {
      const state = _presenceChannel.presenceState();
      _presenceState = {};
      Object.values(state).forEach(arr => {
        arr.forEach(u => {
          if(u.userId) _presenceState[u.userId] = u;
        });
      });
      _renderPresenceBar();
    })
    .on('presence', { event: 'join' }, ({ newPresences }) => {
      newPresences.forEach(u => {
        if(u.userId && u.userId !== CU.id){
          showToast(`🟢 ${u.userName} est en ligne (${u.userSite||u.userRole})`, '');
        }
        if(u.userId) _presenceState[u.userId] = u;
      });
      _renderPresenceBar();
    })
    .on('presence', { event: 'leave' }, ({ leftPresences }) => {
      leftPresences.forEach(u => {
        if(u.userId){
          delete _presenceState[u.userId];
          if(u.userId !== CU.id){
            showToast(`⚫ ${u.userName} s'est déconnecté(e)`, '');
          }
        }
      });
      _renderPresenceBar();
    })
    .subscribe(async (status) => {
      if(status === 'SUBSCRIBED'){
        await _presenceChannel.track({
          userId:   CU.id,
          userName: CU.name,
          userRole: CU.role,
          userSite: CU.site,
          device:   _deviceLabel(),
          onlineAt: new Date().toISOString()
        });
      }
    });

  // Heartbeat toutes les 30s pour maintenir la présence active
  // Et rafraîchir le widget accueil toutes les 30s
  setInterval(()=>{ if(curPage==='accueil') _renderAccueilPresence(); }, 30000);
  _presenceHeartbeat = setInterval(async () => {
    if(!CU || !_presenceChannel) return;
    await _presenceChannel.track({
      userId:   CU.id,
      userName: CU.name,
      userRole: CU.role,
      userSite: CU.site,
      device:   _deviceLabel(),
      onlineAt: new Date().toISOString()
    });
    // Mettre à jour lastSeen dans la table
    _supa.from('ilp_presence').update({
      lastSeen: new Date().toISOString(),
      isOnline: true
    }).eq('userId', CU.id).then(()=>{});
  }, 30000);

  // Marquer hors ligne à la fermeture de l'onglet
  window.addEventListener('beforeunload', _stopPresence);
  document.addEventListener('visibilitychange', () => {
    if(document.visibilityState === 'hidden'){
      _supa.from('ilp_presence').update({isOnline:false,lastSeen:new Date().toISOString()}).eq('userId',CU.id).then(()=>{});
    } else {
      _supa.from('ilp_presence').update({isOnline:true,lastSeen:new Date().toISOString()}).eq('userId',CU.id).then(()=>{});
    }
  });
}

function _renderAccueilPresence(){
  const widget = document.getElementById('accueilPresenceWidget');
  if(!widget) return;

  // Récupérer tous les membres en ligne depuis la table ilp_presence
  if(!_supa) return;
  _supa.from('ilp_presence').select('*').eq('isOnline', true).then(({data}) => {
    if(!data || !data.length){
      // Aucun autre membre en ligne
      if(['admin','gerant'].includes(CU?.role)){
        widget.innerHTML = '<div style="font-size:10px;color:var(--blanc-muted);padding:8px 0">Aucun autre membre de l\'&eacute;quipe en ligne actuellement.</div>';
      }
      return;
    }
    const others = data.filter(u => u.userId !== CU?.id);
    if(!others.length){
      widget.innerHTML = '';
      return;
    }
    const roleOrder = {admin:0, gerant:1, receptionniste:2};
    others.sort((a,b)=>(roleOrder[a.userRole]||3)-(roleOrder[b.userRole]||3));

    widget.innerHTML = `<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:12px 16px;margin-bottom:2px">
      <div style="font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--or);margin-bottom:10px">🟢 Équipe en ligne</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        ${others.map(u => {
          const col = ROLE_COLORS[u.userRole] || ROLE_COLORS.receptionniste;
          const ini2 = u.userName.split(' ').map(w=>w[0]).join('').substring(0,2).toUpperCase();
          const roleLabel = {admin:'Administrateur', gerant:'G&eacute;rant', receptionniste:'R&eacute;ceptionniste'}[u.userRole]||u.userRole;
          const lastSeen = u.lastSeen ? new Date(u.lastSeen) : null;
          const minAgo = lastSeen ? Math.floor((Date.now()-lastSeen)/60000) : 99;
          const isActive = minAgo < 2;
          const dotStyle = 'position:absolute;bottom:0;right:0;width:10px;height:10px;border-radius:50%;border:2px solid var(--surface2);background:'+(isActive?'#22c55e':'#f59e0b')+(isActive?';box-shadow:0 0 6px #22c55e88;animation:pulse-green 2s infinite':'');
          return '<div style="display:flex;align-items:center;gap:8px;background:var(--surface2);border:1px solid '+col.border+';border-radius:8px;padding:8px 12px">'+
            '<div style="position:relative;width:34px;height:34px;border-radius:50%;background:'+col.bg+';border:2px solid '+col.border+';display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:'+col.text+';flex-shrink:0">'+
              ini2+
              '<div style="'+dotStyle+'"></div>'+
            '</div>'+
            '<div>'+
              '<div style="font-size:12px;font-weight:600;color:var(--blanc)">'+u.userName+'</div>'+
              '<div style="font-size:10px;color:'+col.text+'">'+roleLabel+'</div>'+
              '<div style="font-size:9px;color:var(--blanc-muted)">'+(u.userSite||'')+' &middot; '+(u.device||'')+'</div>'+
            '</div>'+
          '</div>';
        }).join('')}
      </div>
    </div>`;
  });
}

async function _stopPresence(){
  if(_presenceHeartbeat){ clearInterval(_presenceHeartbeat); _presenceHeartbeat=null; }
  if(_presenceChannel){
    await _presenceChannel.untrack();
    _supa.removeChannel(_presenceChannel);
    _presenceChannel = null;
  }
  if(CU && _supa){
    _supa.from('ilp_presence').update({isOnline:false,lastSeen:new Date().toISOString()}).eq('userId',CU.id).then(()=>{});
  }
}

function _renderPresenceBar(){
  const bar = document.getElementById('presenceBar');
  if(!bar) return;

  // Filtrer: afficher seulement gérant et réceptionniste (pas l'admin dans sa propre barre, mais admin voit tout)
  const others = Object.values(_presenceState).filter(u => u.userId !== CU.id);

  if(!others.length){
    // Montrer seulement si admin ou gérant (pour voir si l'équipe est là)
    if(['admin','gerant'].includes(CU.role)){
      bar.innerHTML = '<span class="presence-empty" title="Aucun membre en ligne">👤</span>';
    } else {
      bar.innerHTML = '';
    }
    return;
  }

  // Trier: gérants d'abord, puis réceptionnistes
  const sorted = others.sort((a,b) => {
    const order = {admin:0, gerant:1, receptionniste:2};
    return (order[a.userRole]||3) - (order[b.userRole]||3);
  });

  bar.innerHTML = sorted.map(u => {
    const col = ROLE_COLORS[u.userRole] || ROLE_COLORS.receptionniste;
    const initiales = u.userName.split(' ').map(w=>w[0]).join('').substring(0,2).toUpperCase();
    const roleLabel = {admin:'Admin', gerant:'Gérant', receptionniste:'Récep.'}[u.userRole] || u.userRole;
    const siteLabel = u.userSite ? ` · ${u.userSite}` : '';
    const deviceLabel = u.device || '';
    return `<div class="presence-avatar" style="background:${col.bg};border:2px solid ${col.border};color:${col.text};">
      ${initiales}
      <div class="presence-dot online"></div>
      <div class="presence-tooltip">
        <div style="font-weight:700;font-size:11px">${u.userName}</div>
        <div style="color:${col.text}">${roleLabel}${siteLabel}</div>
        <div style="color:#aaa;font-size:9px">${deviceLabel}</div>
      </div>
    </div>`;
  }).join('');
}

// Refresh quand l'onglet redevient visible (retour sur l'app)
document.addEventListener('visibilitychange', async () => {
  if(document.visibilityState === 'visible' && CU){
    // Reconnecter Realtime si nécessaire
    if(!_rtConnected){
      console.log('[ILP] Onglet actif — reconnexion Realtime');
      if(_rtChannel){ _supa.removeChannel(_rtChannel); _rtChannel=null; }
      _startRealtime();
    }
    // Recharger les données pour combler les changements manqués
    await loadDB();
    renderAll();
  }
});

// Sync au retour du focus (retour depuis une autre app)
window.addEventListener('focus', async () => {
  if(CU && document.visibilityState === 'visible'){
    if(!_rtConnected) _startRealtime();
    await loadDB();
    renderAll();
  }
});

function defaultTarifs(){
  return [
    {id:'t1',cat:'Linge de maison',items:[
      {id:'a1',nom:'Drap 160×200',prix:2500},{id:'a2',nom:'Drap king-size',prix:3500},
      {id:'a3',nom:"Taie d'oreiller",prix:800},{id:'a4',nom:'Housse de couette',prix:4500},
      {id:'a5',nom:'Serviette de bain',prix:1000},{id:'a6',nom:'Serviette de table',prix:700},
      {id:'a7',nom:'Nappe 120×120',prix:3500},{id:'a8',nom:'Nappe 200×300',prix:5000},
      {id:'a9',nom:'Chemin de table',prix:2000},
    ]},
    {id:'t2',cat:'Vêtements Homme',items:[
      {id:'b1',nom:'Chemise',prix:1500},{id:'b2',nom:'Pantalon',prix:2000},
      {id:'b3',nom:'Costume 2 pièces',prix:6000},{id:'b4',nom:'Costume 3 pièces',prix:8000},
      {id:'b5',nom:'Veste / Blazer',prix:3500},
    ]},
    {id:'t3',cat:'Vêtements Femme',items:[
      {id:'c1',nom:'Robe simple',prix:3000},{id:'c2',nom:'Robe de soirée',prix:5000},
      {id:'c3',nom:'Tailleur',prix:4500},{id:'c4',nom:'Blouse',prix:1500},
      {id:'c5',nom:'Boubou',prix:4000},
    ]},
    {id:'t4',cat:'Hôtellerie / B2B',items:[
      {id:'d1',nom:'Lot draps ×10',prix:20000},{id:'d2',nom:'Lot serviettes ×20',prix:12000},
      {id:'d3',nom:'Uniforme restaurant',prix:3000},{id:'d4',nom:'Rideau (m²)',prix:2500},
    ]},
  ];
}

// ════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════
const gc   = id => DB.clients.find(c=>c.id===id)||{nom:'Inconnu',tel:'',type:'',ville:''};
const gu   = id => DB.users.find(u=>u.id===id)||{name:'?',role:''};
const gi   = cid => DB.items.filter(i=>i.cmdId===cid);
const gTot = cid => gi(cid).reduce((s,i)=>s+i.prix*i.qte,0);
const gRest= cmd => Math.max(0,gTot(cmd.id)-(cmd.avance||0));
const fmtM = n   => Number(n).toLocaleString('fr-FR')+' FCFA';
const fmtD = iso => !iso?'—':new Date(iso).toLocaleDateString('fr-FR',{day:'2-digit',month:'short'});
const fmtDT= iso => !iso?'—':new Date(iso).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'});
const uid  = p   => p+'-'+Math.random().toString(36).substr(2,6).toUpperCase();
const ini  = n   => (n||'').split(' ').slice(0,2).map(w=>w[0]||'').join('').toUpperCase();

function isRetard(cmd){
  if(cmd.statut==='livré') return false;
  const idx=WF.indexOf(cmd.statut);
  const ss=cmd.etapes&&cmd.etapes[cmd.statut];
  if(!ss) return false;
  return (Date.now()-new Date(ss))/3600000 > (WF_H[idx]||6);
}
function nextSt(cur){ const i=WF.indexOf(cur); return i<WF.length-1?WF[i+1]:null; }
function payStatus(cmd){
  const t=gTot(cmd.id),a=cmd.avance||0;
  if(cmd.statut!=='livré') return 'facturé';
  if(a>=t) return 'payé';
  if(a>0)  return 'partiellement payé';
  return 'impayé';
}
function badge(s){
  const m={'reçu':'b-ticket','lavage':'b-lavage','séchage':'b-sechage','repassage':'b-repassage',
    'prêt':'b-pret','livré':'b-livre','retard':'b-retard','facturé':'b-facture',
    'payé':'b-paye','partiellement payé':'b-partiel','impayé':'b-impaye'};
  const lbls={'reçu':'Reçu','pret':'Prêt'};
  return`<span class="badge ${m[s]||'b-ticket'}">${lbls[s]||s}</span>`;
}
function roleName(r){ return{admin:'Administrateur',gerant:'Gérant',receptionniste:'Réceptionniste'}[r]||r; }
function roleClass(r){ return{admin:'role-admin',gerant:'role-gerant',receptionniste:'role-recep'}[r]||'role-recep'; }
function canDo(action){
  if(!CU) return false;
  const perms = {
    viewKpi:            ['admin','gerant'],
    editClient:         ['admin'],
    deleteClient:       ['admin'],
    editFacture:        ['admin'],
    editDocument:       ['admin'],
    genBilan:           ['admin'],
    deleteCommande:     ['admin'],
    viewHistorique:     ['admin','gerant'],
    manageUsers:        ['admin'],
    editTarifs:         ['admin','gerant'],
    createCommande:     ['admin','gerant','receptionniste'],
    createClient:       ['admin','gerant','receptionniste'],
    viewFacturation:    ['admin','gerant'],
    viewLivraisons:     ['admin','gerant'],
    genDocument:        ['admin','gerant'],
    genRecu:            ['admin','gerant','receptionniste'],
    sendRecuWA:         ['admin','gerant','receptionniste'],
    sendFactureWA:      ['admin','gerant'],
    sendWhatsApp:       ['admin','gerant','receptionniste'],
    manageProspects:    ['admin','gerant','receptionniste'],
    viewRelances:       ['admin','gerant','receptionniste'],
    manageRelancesAuto: ['admin','gerant'],
    viewStockLinge:     ['admin','gerant','receptionniste'],
    editStockLinge:     ['admin','gerant','receptionniste'],
    viewStockProduits:  ['admin','gerant','receptionniste'],
    editStockProduits:  ['admin','gerant'],
    viewCharges:        ['admin'],
    editCharges:        ['admin'],
    viewEmployes:       ['admin'],
    editEmployes:       ['admin'],
    viewStock:          ['admin','gerant','receptionniste'],
    editStock:          ['admin','gerant','receptionniste'],
    viewCharges:        ['admin'],
    editCharges:        ['admin'],
    viewEmployes:       ['admin'],
    editEmployes:       ['admin'],
  };
  return (perms[action]||[]).includes(CU.role);
}

// ════════════════════════════════════════════════════════
// AUTH + BIOMETRIC (WebAuthn)
// ════════════════════════════════════════════════════════
const BIO_KEY = 'ilp_bio_v1'; // stores {userId, credentialId (base64)}

function togglePw(){
  const i=document.getElementById('loginPw');
  i.type = i.type==='password'?'text':'password';
}

// ── Manual login ──
async function doLogin(){
  const id = document.getElementById('loginId').value.trim().toUpperCase();
  const pw = document.getElementById('loginPw').value;
  const user = DB.users.find(u=>u.id===id && u.pw===pw);
  if(!user){ document.getElementById('loginError').style.display='block'; return; }
  document.getElementById('loginError').style.display='none';
  CU = user;
  sessionStorage.setItem('ilp_cu', JSON.stringify(CU));
  document.getElementById('loginScreen').style.display='none';
  document.getElementById('app').style.display='flex';
  initApp();
  // Notifier les managers de la connexion réceptionniste
  if(CU.role==='receptionniste'){
    addNotif('connexion',`${CU.name} s'est connecté(e) (${CU.site})`,{categorie:'systeme',notifyManagers:true});
    saveDB();
  }
  // After successful manual login, offer biometric registration
  setTimeout(()=>checkBioOffer(), 1500);
}

function doLogout(){
  _stopPresence();
  _stopChat();
  CU = null;
  _renderedPages.clear();
  _stopRealtime();
  sessionStorage.removeItem('ilp_cu');
  document.getElementById('app').style.display='none';
  document.getElementById('loginScreen').style.display='flex';
  document.getElementById('loginId').value='';
  document.getElementById('loginPw').value='';
  initLoginScreen();
}

function restoreSession(){
  const s = sessionStorage.getItem('ilp_cu');
  if(s){
    const u = JSON.parse(s);
    const fresh = DB.users.find(x=>x.id===u.id&&x.pw===u.pw);
    if(fresh){ CU=fresh; return true; }
  }
  return false;
}

// ── Init login screen (show biometric if registered) ──
function initLoginScreen(){
  const regs = getBioRegistrations();
  const bioSec = document.getElementById('bioSection');
  const manSec = document.getElementById('manualSection');
  const manTitle = document.getElementById('manualTitle');
  const hint = document.getElementById('bioRegisterHint');
  
  if(regs.length > 0 && isBioSupported()){
    bioSec.style.display='block';
    manTitle.textContent='Connexion manuelle';
    
    // Show user chips
    const chips = document.getElementById('bioUserChips');
    chips.innerHTML = regs.map(r=>{
      const u=DB.users.find(x=>x.id===r.userId);
      if(!u) return '';
      return `<div class="bio-user-chip" onclick="setBioTarget('${r.userId}')">
        <div class="bio-user-chip-av">${ini(u.name)}</div>
        <div>
          <div class="bio-user-chip-name">${u.name}</div>
          <div class="bio-user-chip-role">${roleName(u.role)} · ${u.site}</div>
        </div>
      </div>`;
    }).join('');
    
    // Detect biometric type for icon
    detectBioType().then(type=>{
      const btn=document.getElementById('bioBtn');
      const ico=document.getElementById('bioIcon');
      const lbl=document.getElementById('bioLabel');
      if(type==='fingerprint'){
        ico.textContent='🫰';
        lbl.textContent='Déverrouiller avec empreinte digitale';
      } else if(type==='face'){
        ico.textContent='😊';
        lbl.textContent='Déverrouiller avec Face ID';
      } else {
        ico.textContent='🔐';
        lbl.textContent='Déverrouiller avec biométrie / PIN';
      }
    });
    
    hint.style.display='none';
  } else {
    bioSec.style.display='none';
    // Show hint if biometric supported but not registered
    if(isBioSupported()){
      hint.style.display='block';
    }
  }
}

// ── Biometric support check ──
function isBioSupported(){
  return !!(window.PublicKeyCredential && navigator.credentials && window.location.protocol==='https:' ||
            window.PublicKeyCredential && navigator.credentials && window.location.hostname==='localhost' ||
            window.PublicKeyCredential && navigator.credentials && window.location.protocol==='file:');
}

async function detectBioType(){
  try{
    if(PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable){
      const ok = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if(!ok) return 'none';
    }
    // Heuristic: check UA for touch/mobile
    const ua=navigator.userAgent.toLowerCase();
    if(/iphone|ipad/.test(ua)) return 'face';
    if(/android/.test(ua)) return 'fingerprint';
    if(/mac/.test(ua)) return 'face'; // Touch ID on Mac
    return 'fingerprint';
  }catch(e){ return 'none'; }
}

// ── Bio target (which user to authenticate) ──
let bioTargetUserId = null;
function setBioTarget(userId){
  bioTargetUserId=userId;
  const regs=getBioRegistrations();
  const reg=regs.find(r=>r.userId===userId);
  const u=DB.users.find(x=>x.id===userId);
  if(!u)return;
  // Update chip styling
  document.querySelectorAll('.bio-user-chip').forEach(c=>c.style.borderColor='');
  event.currentTarget.style.borderColor='var(--or)';
  document.getElementById('bioLabel').textContent=`Connecter en tant que ${u.name}`;
  showToast(`Empreinte pour ${u.name} — Appuyez sur le bouton ci-dessus`,'');
}

// ── REGISTER biometric ──
async function registerBiometric(userId){
  if(!isBioSupported()){
    showToast('Biométrie non disponible sur cet appareil/navigateur','w');
    return false;
  }
  const user = DB.users.find(u=>u.id===userId);
  if(!user){ showToast('Utilisateur introuvable','w'); return false; }
  
  try{
    // Challenge: random bytes
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    
    const userIdBytes = new TextEncoder().encode(user.id);
    
    const credential = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: 'Ivoire Luxe Pressing', id: location.hostname||'localhost' },
        user: {
          id: userIdBytes,
          name: user.id,
          displayName: user.name,
        },
        pubKeyCredParams: [
          {type:'public-key', alg:-7},   // ES256
          {type:'public-key', alg:-257},  // RS256
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform', // device biometric only
          userVerification: 'required',
        },
        timeout: 60000,
        attestation: 'none',
      }
    });
    
    // Store credential ID
    const credIdB64 = btoa(String.fromCharCode(...new Uint8Array(credential.rawId)));
    saveBioRegistration(userId, credIdB64);
    showToast(`Empreinte enregistrée pour ${user.name} ✓`,'s');
    initLoginScreen();
    return true;
  } catch(err){
    if(err.name==='NotAllowedError'){
      showToast('Opération annulée ou refusée','w');
    } else if(err.name==='InvalidStateError'){
      showToast('Biométrie déjà enregistrée pour cet utilisateur','w');
    } else {
      showToast('Erreur biométrique: '+err.message,'w');
    }
    return false;
  }
}

// ── AUTHENTICATE biometric ──
async function doBiometric(){
  if(!isBioSupported()){
    showToast('Biométrie non supportée','w'); return;
  }
  const regs = getBioRegistrations();
  if(!regs.length){ showToast('Aucune empreinte enregistrée','w'); return; }
  
  // Select target: if user chose a chip, use that; else use first registered
  const targetReg = bioTargetUserId
    ? regs.find(r=>r.userId===bioTargetUserId) || regs[0]
    : regs[0];
  
  const btn=document.getElementById('bioBtn');
  const ico=document.getElementById('bioIcon');
  const errEl=document.getElementById('bioError');
  errEl.style.display='none';
  btn.classList.add('scanning');
  ico.textContent='⏳';
  
  try{
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    
    // Build allowCredentials from all registered creds (or just target)
    const credIds = (bioTargetUserId ? [targetReg] : regs).map(r=>({
      type:'public-key',
      id: Uint8Array.from(atob(r.credId), c=>c.charCodeAt(0)),
      transports:['internal'],
    }));
    
    await navigator.credentials.get({
      publicKey:{
        challenge,
        rpId: location.hostname||'localhost',
        allowCredentials: credIds,
        userVerification: 'required',
        timeout: 60000,
      }
    });
    
    // Success — log in as target user
    btn.classList.remove('scanning');
    ico.textContent='✅';
    
    const user = DB.users.find(u=>u.id===targetReg.userId);
    if(!user){ showToast('Utilisateur introuvable','w'); return; }
    
    CU = user;
    sessionStorage.setItem('ilp_cu', JSON.stringify(CU));
    
    setTimeout(()=>{
      document.getElementById('loginScreen').style.display='none';
      document.getElementById('app').style.display='flex';
      initApp();
      showToast(`Bonjour ${user.name} 👋`,'s');
    }, 400);
    
  } catch(err){
    btn.classList.remove('scanning');
    ico.textContent='🔐';
    
    let msg='Authentification échouée';
    if(err.name==='NotAllowedError') msg='Opération annulée ou délai dépassé';
    else if(err.name==='SecurityError') msg='Erreur de sécurité — vérifiez le protocole HTTPS';
    else if(err.name==='InvalidStateError') msg='Empreinte non reconnue';
    else msg = err.message || 'Erreur inconnue';
    
    errEl.textContent='❌ '+msg;
    errEl.style.display='block';
    setTimeout(()=>errEl.style.display='none', 4000);
  }
}

// ── Bio registrations storage ──
function getBioRegistrations(){
  try{ return JSON.parse(localStorage.getItem(BIO_KEY)||'[]'); }catch(e){return [];}
}
function saveBioRegistration(userId, credId){
  const regs = getBioRegistrations().filter(r=>r.userId!==userId); // remove old
  regs.push({userId, credId});
  localStorage.setItem(BIO_KEY, JSON.stringify(regs));
}
function removeBioRegistration(userId){
  const regs = getBioRegistrations().filter(r=>r.userId!==userId);
  localStorage.setItem(BIO_KEY, JSON.stringify(regs));
}

// ── Offer bio registration after manual login ──
function checkBioOffer(){
  if(!isBioSupported()) return;
  const regs=getBioRegistrations();
  const alreadyReg = regs.find(r=>r.userId===CU.id);
  if(!alreadyReg){
    showBioOffer();
  }
}

function showBioOffer(){
  // Show a toast-like offer
  const t=document.createElement('div');
  t.className='toast';
  t.style.cssText='border-color:rgba(201,168,76,.5);min-width:280px;max-width:340px;';
  t.innerHTML=`
    <span style="font-size:20px">🔐</span>
    <div style="flex:1">
      <div style="font-size:12px;color:var(--blanc);margin-bottom:5px">Activer la connexion biométrique ?</div>
      <div style="font-size:10px;color:var(--blanc-muted)">Empreinte digitale ou Face ID</div>
      <div style="display:flex;gap:7px;margin-top:8px">
        <button class="btn btn-gold btn-xs" onclick="activateBio(this)">✓ Activer</button>
        <button class="btn btn-ghost btn-xs" onclick="this.closest('.toast').remove()">Plus tard</button>
        <button class="btn btn-ghost btn-xs" onclick="dismissBio(this)">Ne plus demander</button>
      </div>
    </div>`;
  document.getElementById('toasts').appendChild(t);
}
async function activateBio(btn){
  btn.closest('.toast').remove();
  const ok = await registerBiometric(CU.id);
  if(ok) showToast('Biométrie activée ! Prochain accès sans mot de passe 🔐','s');
}
function dismissBio(btn){
  btn.closest('.toast').remove();
  localStorage.setItem('ilp_bio_dismissed_'+CU.id,'1');
}

function showBioRegisterInfo(){
  showToast('Connectez-vous manuellement, puis activez la biométrie depuis la notification','');
}

// ── Bio management in profile page ──
function renderBioStatus(){
  const regs=getBioRegistrations();
  const reg=regs.find(r=>r.userId===CU.id);
  const supported=isBioSupported();
  return `
    <div style="font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--or);margin-bottom:10px;margin-top:18px">🔐 Connexion biométrique</div>
    ${!supported?`<div style="font-size:11px;color:var(--blanc-muted);padding:10px;background:var(--surface2);border-radius:var(--radius)">Non disponible sur cet appareil ou protocole HTTP.<br>Requis: HTTPS + appareil avec capteur biométrique.</div>`
    :reg?`
      <div style="display:flex;align-items:center;gap:10px;padding:10px;background:rgba(58,138,92,.08);border:1px solid rgba(58,138,92,.2);border-radius:var(--radius);margin-bottom:8px">
        <span style="font-size:18px">✅</span>
        <div style="flex:1;font-size:12px;color:var(--vert)">Biométrie activée pour ce compte</div>
        <button class="btn btn-danger btn-xs" onclick="deactivateBio()">Désactiver</button>
      </div>`:
    `<button class="bio-btn" onclick="activateBioFromProfile()">
        <span class="bio-icon">🔐</span>
        <span>Activer empreinte / Face ID</span>
      </button>`}`;
}

async function activateBioFromProfile(){
  await registerBiometric(CU.id);
  renderProfil();
}
function deactivateBio(){
  if(!confirm('Désactiver la biométrie pour votre compte ?')) return;
  removeBioRegistration(CU.id);
  showToast('Biométrie désactivée','s');
  renderProfil();
  initLoginScreen();
}

// ════════════════════════════════════════════════════════
// NAVIGATION
// ════════════════════════════════════════════════════════
let curPage = 'accueil';
let _renderedPages = new Set(); // track already-rendered pages
const RENDER_MAP = {
  accueil:renderAccueil, ops:renderOps, commandes:renderCommandes, clients:renderClients, relance:renderRelance, bilan:renderBilan, chat:renderChat, stock_linge:renderStockLinge, stock_produits:renderStockProduits, charges:renderCharges, employes:renderEmployes,
  process:renderProcess, facturation:renderFacturation, livraisons:renderLivraisons,
  tarifs:renderTarifs, historique:renderHistorique, notifs:renderNotifs,
  profil:renderProfil, users:renderUsers, params:renderParams,
  prospects:renderProspects,
};

function nav(pg){
  if(pg==='bilan')    setTimeout(initBilanPage,50);
  if(pg==='chat')     setTimeout(renderChat,50);
  if(pg==='employes') setTimeout(initEmployesPage,50);
  // Check permission
  const menu = ROLE_MENUS[CU.role]||[];
  if(!menu.find(m=>m.id===pg)){
    showToast('Accès non autorisé pour votre rôle','w');
    return;
  }
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('[data-pg]').forEach(n=>n.classList.remove('active'));
  document.querySelectorAll('[data-bnav]').forEach(n=>n.classList.remove('active'));
  const pg2=document.getElementById('page-'+pg);
  if(pg2) pg2.classList.add('active');
  document.querySelectorAll(`[data-pg="${pg}"]`).forEach(n=>n.classList.add('active'));
  document.querySelectorAll(`[data-bnav="${pg}"]`).forEach(n=>n.classList.add('active'));
  curPage=pg;
  // Always re-render live pages; other pages only if not yet rendered
  const alwaysRender = new Set(['accueil','ops','notifs','chat']);
  if(RENDER_MAP[pg] && (alwaysRender.has(pg) || !_renderedPages.has(pg))){
    RENDER_MAP[pg]();
    _renderedPages.add(pg);
  }
  if(window.innerWidth<=768) document.getElementById('sidebar').classList.remove('open');
}
function renderAll(){ 
  // Invalidate cache for data-sensitive pages so they re-render fresh
  _renderedPages.clear();
  if(RENDER_MAP[curPage]) RENDER_MAP[curPage](); 
  _renderedPages.add(curPage);
  updateBadges(); 
}
function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('open'); }

// ════════════════════════════════════════════════════════
// APP INIT
// ════════════════════════════════════════════════════════
function initApp(){
  // Start realtime sync with Supabase
  _startRealtime();
  // Start presence system
  _startPresence();
  // Start chat realtime
  _startChat();
  // Start relances auto scheduler
  _scheduleRelanceCheck();
  // Vérification périodique connexion Realtime (toutes les 30s)
  setInterval(() => {
    if(CU && !_rtConnected){
      console.log('[ILP] Realtime inactif — reconnexion auto...');
      if(_rtChannel){ _supa.removeChannel(_rtChannel); _rtChannel=null; }
      _startRealtime();
    }
  }, 30000);
  // Show install button in topbar if not standalone
  if(!isStandalone()){
    const b=document.getElementById('pwaTopBtn');
    if(b) b.style.display='flex';
  }
  // Logos
  if(typeof LOGO_B64!=='undefined'){
    ['topbarLogo','loginLogo'].forEach(id=>{const el=document.getElementById(id);if(el)el.src=LOGO_B64;});
  }
  // Topbar user info
  document.getElementById('topAvatar').textContent = ini(CU.name);
  document.getElementById('topName').textContent   = CU.name;
  const rb = document.getElementById('topRole');
  rb.textContent  = roleName(CU.role);
  rb.className    = 'role-badge '+roleClass(CU.role);
  document.getElementById('sideUserName').textContent = CU.name;
  document.getElementById('sideUserRole').textContent = roleName(CU.role)+' · '+CU.site;

  // Build sidebar nav
  buildSidebarNav();
  buildBottomNav();

  // Restore theme
  loadTheme();

  // Render
  nav('accueil');
  updateBadges();

  // Retard check loop
  setInterval(()=>{
    DB.commandes.filter(c=>isRetard(c)&&c.statut!=='livré').forEach(c=>{
      if(!DB.notifs.some(n=>n.msg.includes(c.id)&&!n.read&&n.type==='retard'))
        addNotif('retard',`${c.id} — ${gc(c.clientId).nom} : retard à l'étape ${c.statut}`);
    });
    updateBadges();
  },30000);

  // Close sidebar on outside click
  document.addEventListener('click',e=>{
    const sb=document.getElementById('sidebar'),mt=document.getElementById('menuToggle');
    if(window.innerWidth<=768&&sb&&sb.classList.contains('open')&&!sb.contains(e.target)&&mt&&!mt.contains(e.target))
      sb.classList.remove('open');
  });

  // PWA
  initPWA();
}

function buildSidebarNav(){
  const menu = ROLE_MENUS[CU.role]||[];
  const groups = [
    {label:'Principal',  ids:['accueil','ops','commandes']},
    {label:'Gestion',    ids:['clients','relance','process','facturation','livraisons']},
    {label:'Stock',      ids:['stock_linge','stock_produits']},
    {label:'Commerce',   ids:['tarifs','prospects','bilan']},
    {label:'Finance',    ids:['charges','employes','historique']},
    {label:'Admin',      ids:['users']},
    {label:'Système',    ids:['chat','notifs','params','profil']},
  ];
  let html='';
  groups.forEach(g=>{
    const items = menu.filter(m=>g.ids.includes(m.id));
    if(!items.length) return;
    html+=`<div class="sidebar-section"><div class="sidebar-lbl">${g.label}</div>`;
    items.forEach(m=>{
      html+=`<div class="nav-item" data-pg="${m.id}" onclick="nav('${m.id}')"><span class="nav-icon">${m.ico}</span>${m.label}`;
      if(m.badge==='retards') html+=`<span class="nav-count" id="retardBadge" style="display:none">0</span>`;
      if(m.badge==='notifs')  html+=`<span class="nav-count g" id="notifSide" style="display:none">0</span>`;
      html+=`</div>`;
    });
    html+='</div>';
  });
  document.getElementById('sidebarNav').innerHTML=html;
}

function buildBottomNav(){
  const menu  = ROLE_MENUS[CU.role]||[];
  const items = menu.slice(0,5);
  let html='';
  items.forEach((m,i)=>{
    html+=`<div class="bnav-item" data-bnav="${m.id}" onclick="nav('${m.id}')">
      <span class="nav-icon">${m.ico}</span><span>${m.label}</span>
    </div>`;
  });
  document.getElementById('bnavInner').innerHTML=html;
}

function updateBadges(){
  const unread = DB.notifs.filter(n=>!n.read).length;
  const rets   = DB.commandes.filter(c=>isRetard(c)).length;
  const prosp  = typeof getProspectsBadgeCount==='function' ? getProspectsBadgeCount() : 0;
  const nd = document.getElementById('notifDot');
  if(nd){nd.textContent=unread;nd.style.display=unread?'flex':'none';}
  const ns = document.getElementById('notifSide');
  if(ns){ns.textContent=unread;ns.style.display=unread?'inline-flex':'none';}
  const rb = document.getElementById('retardBadge');
  if(rb){rb.textContent=rets;rb.style.display=rets?'inline-flex':'none';}
  // Prospects badge
  document.querySelectorAll('[data-pg="prospects"],[data-bnav="prospects"]').forEach(el=>{
    let bd=el.querySelector('.nav-badge');
    if(!bd && prosp>0){bd=document.createElement('span');bd.className='nav-badge';el.appendChild(bd);}
    if(bd){bd.textContent=prosp;bd.style.display=prosp>0?'inline-flex':'none';}
  });
}

// ════════════════════════════════════════════════════════
// MODALS
// ════════════════════════════════════════════════════════
function openModal(id){
  const el=document.getElementById('modal-'+id);
  if(!el) return;
  el.classList.add('open');
  if(id==='newOrder')   initNewOrder();
  if(id==='editTarifs') initEditTarifs();
  if(id==='newUser')    initNewUserForm();
}
function closeModal(id){ const el=document.getElementById('modal-'+id);if(el)el.classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(m=>{m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('open');});});

// ════════════════════════════════════════════════════════
// NEW ORDER
// ════════════════════════════════════════════════════════
let oItems=[];
function initNewOrder(){
  const sel=document.getElementById('f-client');
  sel.innerHTML='<option value="">— Sélectionner —</option>';
  // Tous les rôles voient tous les clients (pour créer une commande)
  const visClients = DB.clients;
  visClients.forEach(c=>{sel.innerHTML+=`<option value="${c.id}">${c.nom}</option>`;});
  document.getElementById('f-date').value=new Date().toISOString().split('T')[0];
  document.getElementById('f-avance').value='0';
  document.getElementById('f-notes').value='';
  oItems=[{art:'',prix:0,qte:1}];
  renderOItems();
}
function renderOItems(){
  const el=document.getElementById('itemsList');el.innerHTML='';
  const arts=[];
  DB.tarifs.forEach(cat=>cat.items.forEach(it=>arts.push({...it,cat:cat.cat})));
  oItems.forEach((it,i)=>{
    let opts='<option value="">— Article —</option>';
    const cats={};
    arts.forEach(a=>{if(!cats[a.cat])cats[a.cat]=[];cats[a.cat].push(a);});
    Object.entries(cats).forEach(([cat,items])=>{
      opts+=`<optgroup label="${cat}">`;
      items.forEach(a=>{opts+=`<option value="${a.nom}" data-p="${a.prix}" ${it.art===a.nom?'selected':''}>${a.nom} — ${a.prix.toLocaleString('fr-FR')}</option>`;});
      opts+=`</optgroup>`;
    });
    const row=document.createElement('div');row.className='item-row';
    row.innerHTML=`
      <select class="fs" style="font-size:11px" onchange="iChg(${i},'art',this.value,this)">${opts}</select>
      <input type="number" class="fi" value="${it.qte}" min="1" onchange="iChg(${i},'qte',+this.value)" style="text-align:center">
      <input type="number" class="fi" value="${it.prix}" min="0" onchange="iChg(${i},'prix',+this.value)" id="ip-${i}">
      <div class="item-tot" id="it-${i}">${fmtM(it.prix*it.qte)}</div>
      <button class="btn btn-danger btn-xs" onclick="rmItem(${i})">✕</button>`;
    el.appendChild(row);
  });
  recalcTot();
}
function iChg(i,f,v,sel){
  if(f==='art'&&sel){
    const opt=sel.querySelector(`option[value="${v}"]`);
    const p=opt?+opt.dataset.p:0;
    oItems[i].art=v;oItems[i].prix=p;
    const pi=document.getElementById('ip-'+i);if(pi)pi.value=p;
  }else oItems[i][f]=v;
  const t=document.getElementById('it-'+i);if(t)t.textContent=fmtM(oItems[i].prix*oItems[i].qte);
  recalcTot();
}
function addItem(){ oItems.push({art:'',prix:0,qte:1}); renderOItems(); }
function rmItem(i){ if(oItems.length>1){oItems.splice(i,1);renderOItems();} }
function recalcTot(){
  const tot=oItems.reduce((s,i)=>s+i.prix*i.qte,0);
  const av=+document.getElementById('f-avance')?.value||0;
  const te=document.getElementById('oTotal'),re=document.getElementById('oReste');
  if(te)te.textContent=fmtM(tot);
  if(re)re.textContent=fmtM(Math.max(0,tot-av));
}
async function saveOrder(){
  const cId=document.getElementById('f-client').value;
  if(!cId){showToast('Sélectionner un client','w');return;}
  const f=oItems.filter(i=>i.art&&i.prix>0);
  if(!f.length){showToast('Ajouter au moins un article','w');return;}
  const id=uid('CMD');const now=new Date().toISOString();
  DB.commandes.push({id,clientId:cId,statut:'reçu',site:document.getElementById('f-site').value,
    dateEntree:now,dateDelai:new Date(Date.now()+(+document.getElementById('f-delai').value||2)*86400000).toISOString(),
    avance:+document.getElementById('f-avance').value||0,notes:document.getElementById('f-notes').value,
    createdBy:CU.id,etapes:{reçu:now}});
  f.forEach(it=>DB.items.push({id:uid('I'),cmdId:id,art:it.art,prix:it.prix,qte:it.qte}));
  addNotif('commande',`Commande ${id} créée pour ${gc(cId).nom} par ${CU.name}`,{categorie:'commandes',cmdId:id,clientId:cId,notifyManagers:true});
  await saveDB();closeModal('newOrder');showToast(`Commande ${id} créée ✓`,'s');renderAll();
}

// ════════════════════════════════════════════════════════
// CLIENTS
// ════════════════════════════════════════════════════════
async function saveClient(){
  const nom=document.getElementById('nc-nom').value.trim();
  if(!nom){showToast('Nom requis','w');return;}
  const id=uid('C');
  DB.clients.push({id,nom,
    tel:document.getElementById('nc-tel').value,
    type:document.getElementById('nc-type').value,
    ville:document.getElementById('nc-ville').value,
    email:document.getElementById('nc-email').value,
    notes:document.getElementById('nc-notes').value,
    createdBy:CU.id,since:new Date().toISOString()
  });
  await saveDB();closeModal('newClient');showToast(`${nom} ajouté ✓`,'s');renderClients();
}

function openClientDetail(cId){
  const client=DB.clients.find(c=>c.id===cId);if(!client)return;
  const cmds=DB.commandes.filter(c=>c.clientId===cId);
  const ca=cmds.reduce((s,c)=>s+gTot(c.id),0);
  const createdBy=DB.users.find(u=>u.id===client.createdBy);
  document.getElementById('cdTitle').textContent=client.nom;
  document.getElementById('cdBody').innerHTML=`
    <div style="display:flex;gap:20px;flex-wrap:wrap;margin-bottom:16px">
      <div class="pc-avatar" style="width:56px;height:56px;font-size:22px;margin:0">${ini(client.nom)}</div>
      <div style="flex:1">
        <div style="font-size:18px;color:var(--blanc);margin-bottom:4px">${client.nom}</div>
        <div style="font-size:12px;color:var(--blanc-muted)">${client.tel||'—'} ${client.email?'· '+client.email:''}</div>
        <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap">
          ${badge(client.type.toLowerCase().includes('hôtel')||client.type.toLowerCase().includes('b2b')?'facturé':'reçu')}
          <span style="font-size:10px;color:var(--blanc-muted)">${client.ville||''}</span>
        </div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
      <div class="kpi"><div class="kpi-lbl">Commandes</div><div class="kpi-val">${cmds.length}</div></div>
      <div class="kpi"><div class="kpi-lbl">CA total</div><div class="kpi-val sm">${fmtM(ca)}</div></div>
      <div class="kpi"><div class="kpi-lbl">Client depuis</div><div class="kpi-val sm" style="font-size:16px">${fmtD(client.since)}</div></div>
    </div>
    ${client.notes?`<div style="font-size:12px;color:var(--blanc-muted);margin-bottom:14px;padding:10px;background:var(--surface2);border-radius:var(--radius)">${client.notes}</div>`:''}
    <div style="font-size:9px;letter-spacing:.15em;text-transform:uppercase;color:var(--or);margin-bottom:8px">Historique commandes</div>
    <div class="tbl-wrap"><table><thead><tr><th>N°</th><th>Total</th><th>Statut</th><th>Date</th></tr></thead>
    <tbody>${cmds.length?cmds.map(c=>`<tr onclick="openDetail('${c.id}')"><td style="color:var(--or-clair);font-family:var(--f-d)">${c.id}</td><td style="font-family:var(--f-d)">${fmtM(gTot(c.id))}</td><td>${badge(c.statut)}</td><td class="td-m">${fmtD(c.dateEntree)}</td></tr>`).join(''):'<tr><td colspan="4" style="text-align:center;color:var(--blanc-muted);padding:20px">Aucune commande</td></tr>'}</tbody>
    </table></div>
    <div style="font-size:10px;color:var(--blanc-muted);margin-top:12px">Enregistré par : ${createdBy?createdBy.name:'—'} · ID: ${client.id}</div>`;
  const isAdmin = canDo('editClient');
  document.getElementById('cdFt').innerHTML=`
    <button class="btn btn-ghost" onclick="closeModal('clientDetail')">Fermer</button>
    ${isAdmin?`<button class="btn btn-danger" onclick="deleteClient('${cId}')">🗑 Supprimer</button>`:''}
    ${isAdmin?`<button class="btn btn-gold" onclick="editClientModal('${cId}')">✎ Modifier</button>`:''}`;
  openModal('clientDetail');
}

async function deleteClient(cId){
  if(!canDo('deleteClient')){showToast('Accès réservé à l\'administrateur','w');return;}
  if(!confirm('Supprimer ce client et ses données ?')) return;
  DB.clients    = DB.clients.filter(c=>c.id!==cId);
  DB.commandes  = DB.commandes.filter(c=>c.clientId!==cId);
  await saveDB();closeModal('clientDetail');showToast('Client supprimé','s');renderClients();
}

function editClientModal(cId){
  if(!canDo('editClient')){showToast('Réservé administrateur','w');return;}
  const client=DB.clients.find(c=>c.id===cId);if(!client)return;
  closeModal('clientDetail');
  // Re-open newClient modal with pre-filled data for edit
  openModal('newClient');
  document.getElementById('nc-nom').value   = client.nom;
  document.getElementById('nc-tel').value   = client.tel||'';
  document.getElementById('nc-type').value  = client.type||'Particulier';
  document.getElementById('nc-ville').value = client.ville||'';
  document.getElementById('nc-email').value = client.email||'';
  document.getElementById('nc-notes').value = client.notes||'';
  // Override save to update instead
  const ft = document.querySelector('#modal-newClient .modal-ft');
  ft.querySelector('.btn-gold').onclick = async ()=>{
    client.nom   = document.getElementById('nc-nom').value.trim();
    client.tel   = document.getElementById('nc-tel').value;
    client.type  = document.getElementById('nc-type').value;
    client.ville = document.getElementById('nc-ville').value;
    client.email = document.getElementById('nc-email').value;
    client.notes = document.getElementById('nc-notes').value;
    await saveDB();closeModal('newClient');showToast('Client mis à jour ✓','s');renderClients();
    ft.querySelector('.btn-gold').onclick = saveClient; // restore
  };
}

// ════════════════════════════════════════════════════════
// ORDER DETAIL
// ════════════════════════════════════════════════════════
function openDetail(cmdId){
  const cmd=DB.commandes.find(c=>c.id===cmdId);if(!cmd)return;
  const client=gc(cmd.clientId);const items=gi(cmdId);
  const total=gTot(cmdId);const reste=gRest(cmd);const ps=payStatus(cmd);
  const creator=DB.users.find(u=>u.id===cmd.createdBy);
  document.getElementById('detailTitle').textContent=`${cmd.id} — ${client.nom}`;
  const wf=WF.map((s,i)=>{const idx=WF.indexOf(cmd.statut);let cls=i<idx?'done':i===idx?'cur':'';return`<div class="wf-step ${cls}">${WFI[i]}<br>${s}</div>`;}).join('');
  const rows=items.map(it=>`<tr><td>${it.art}</td><td class="td-m">${it.qte}</td><td class="td-m">${fmtM(it.prix)}</td><td style="font-family:var(--f-d);color:var(--or-clair)">${fmtM(it.prix*it.qte)}</td></tr>`).join('');
  document.getElementById('detailBody').innerHTML=`
    <div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:14px">
      <div><div class="tot-lbl">Site</div><div style="font-size:13px">${cmd.site}</div></div>
      <div><div class="tot-lbl">Entrée</div><div>${fmtD(cmd.dateEntree)}</div></div>
      <div><div class="tot-lbl">Délai</div><div>${fmtD(cmd.dateDelai)}</div></div>
      <div><div class="tot-lbl">Statut</div>${badge(isRetard(cmd)?'retard':cmd.statut)}</div>
      <div><div class="tot-lbl">Créée par</div><div style="font-size:11px">${creator?creator.name:'—'}</div></div>
      ${cmd.notes?`<div><div class="tot-lbl">Notes</div><div style="font-size:12px;color:var(--blanc-muted)">${cmd.notes}</div></div>`:''}
    </div>
    <div class="wf-bar">${wf}</div>
    <div class="divider"></div>
    <div class="tbl-wrap"><table><thead><tr><th>Article</th><th>Qté</th><th>Prix unit.</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="order-totals">
      <div style="text-align:right"><div class="tot-lbl">Total</div><div class="tot-val">${fmtM(total)}</div></div>
      <div style="text-align:right"><div class="tot-lbl">Avance</div><div class="tot-val g">${fmtM(cmd.avance||0)}</div></div>
      <div style="text-align:right"><div class="tot-lbl">Reste</div><div class="tot-val ${reste>0?'r':''}">${fmtM(reste)}</div></div>
    </div>
    <div style="margin-top:8px;text-align:right">Paiement: ${badge(ps)}</div>`;
  const nx=nextSt(cmd.statut);
  const isAdmin=canDo('deleteCommande');
  document.getElementById('detailFt').innerHTML=`
    <button class="btn btn-ghost" onclick="closeModal('detail')">Fermer</button>
    ${isAdmin?`<button class="btn btn-danger btn-sm" onclick="deleteCmd('${cmdId}')">🗑</button>`:''}
    ${(canDo('genRecu')||canDo('genDocument'))?`<button class="btn btn-outline" onclick="genRecu('${cmdId}')">🧾 Reçu</button>`:''}
    ${canDo('genDocument')?`<button class="btn btn-outline" onclick="genFacture('${cmdId}')">📄 Facture</button>`:''}
    ${canDo('sendRecuWA')?`<button class="btn btn-outline" style="color:#25D366;border-color:rgba(37,211,102,.4)" onclick="sendWhatsApp('${cmdId}','recu')">💬 Reçu WA</button>`:''}
    ${canDo('sendFactureWA')?`<button class="btn btn-outline" style="color:#25D366;border-color:rgba(37,211,102,.4)" onclick="sendWhatsApp('${cmdId}','facture')">💬 Facture WA</button>`:''}
    ${!canDo('genRecu')&&!canDo('genDocument')?`<div style="font-size:10px;color:var(--blanc-muted);padding:4px 8px">🔒 Génération réservée Admin/Gérant</div>`:''}
    ${nx?`<button class="btn btn-gold" onclick="advSt('${cmdId}','${nx}')">→ ${nx}</button>`:''}`;
  openModal('detail');
}

async function deleteCmd(cmdId){
  if(!canDo('deleteCommande')){showToast('Réservé administrateur','w');return;}
  if(!confirm('Supprimer cette commande ?')) return;
  DB.commandes = DB.commandes.filter(c=>c.id!==cmdId);
  DB.items     = DB.items.filter(i=>i.cmdId!==cmdId);
  await saveDB();closeModal('detail');showToast('Commande supprimée','s');renderAll();
}

async function advSt(cmdId,nxt){
  const cmd=DB.commandes.find(c=>c.id===cmdId);if(!cmd)return;
  cmd.statut=nxt;if(!cmd.etapes)cmd.etapes={};cmd.etapes[nxt]=new Date().toISOString();
  addNotif(nxt==='prêt'?'pret':'info',`Commande ${cmdId} — ${gc(DB.commandes.find(c=>c.id===cmdId)?.clientId||'').nom||''} → étape «${nxt}» (par ${CU.name})`,{categorie:'commandes',cmdId,clientId:DB.commandes.find(c=>c.id===cmdId)?.clientId,notifyManagers:true});
  await saveDB();closeModal('detail');showToast(`Statut → ${nxt}`,'s');renderAll();
}

// ════════════════════════════════════════════════════════
// RENDER PAGES
// ════════════════════════════════════════════════════════
function renderAccueil(){
  document.getElementById('todayLbl').textContent=new Date().toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  const today=new Date();today.setHours(0,0,0,0);
  const ec=DB.commandes.filter(c=>c.statut!=='livré').length;
  const rets=DB.commandes.filter(c=>isRetard(c)).length;
  const prets=DB.commandes.filter(c=>c.statut==='prêt').length;
  const caT=DB.commandes.filter(c=>new Date(c.dateEntree)>=today).reduce((s,c)=>s+gTot(c.id),0);
  const caSem=DB.commandes.filter(c=>new Date(c.dateEntree)>=new Date(Date.now()-7*864e5)).reduce((s,c)=>s+gTot(c.id),0);
  const caMois=DB.commandes.filter(c=>new Date(c.dateEntree)>=new Date(Date.now()-30*864e5)).reduce((s,c)=>s+gTot(c.id),0);
  const pm=DB.commandes.length?Math.round(DB.commandes.reduce((s,c)=>s+gTot(c.id),0)/DB.commandes.length):0;

  const showCA = canDo('viewKpi');
  const prosp_due = (DB.prospects||[]).filter(p=>typeof isRelanceDue==='function'&&isRelanceDue(p)&&p.statut!=='converti').length;
  const clients_anciens = (DB.clients||[]).filter(c=>typeof isClientAncien==='function'&&isClientAncien(c)).length;
  document.getElementById('kpiGrid').innerHTML=`
    <div class="kpi"><div class="kpi-ico">📋</div><div class="kpi-lbl">En cours</div><div class="kpi-val">${ec}</div><div class="kpi-sub">${prets} prêt(s)</div></div>
    <div class="kpi" style="border-color:${rets?'rgba(212,75,58,.3)':'var(--border)'}"><div class="kpi-ico">⚠️</div><div class="kpi-lbl">Retards</div><div class="kpi-val" style="color:${rets?'var(--rouge)':'var(--or-clair)'}">${rets}</div></div>
    <div class="kpi"><div class="kpi-ico">👥</div><div class="kpi-lbl">Clients</div><div class="kpi-val">${DB.clients.length}</div></div>
    <div class="kpi" style="cursor:pointer;border-color:${prosp_due>0?'rgba(212,75,58,.3)':'var(--border)'}" onclick="nav('prospects')"><div class="kpi-ico">🎯</div><div class="kpi-lbl">Prospects</div><div class="kpi-val" style="color:${prosp_due>0?'var(--rouge)':'var(--or-clair)'}">${(DB.prospects||[]).length}<div class="kpi-sub">${prosp_due>0?prosp_due+' relance(s)':''}</div></div></div>
    <div class="kpi" style="cursor:pointer;border-color:${clients_anciens>0?'rgba(232,160,48,.4)':'var(--border)'}" onclick="nav('prospects')"><div class="kpi-ico">🔔</div><div class="kpi-lbl">À relancer</div><div class="kpi-val" style="color:${clients_anciens>0?'#e8a030':'var(--or-clair)'}">${clients_anciens}</div></div>
    ${showCA?`
    <div class="kpi"><div class="kpi-ico">💰</div><div class="kpi-lbl">CA aujourd'hui</div><div class="kpi-val sm">${fmtM(caT)}</div></div>
    <div class="kpi"><div class="kpi-ico">📈</div><div class="kpi-lbl">CA semaine</div><div class="kpi-val sm">${fmtM(caSem)}</div></div>
    <div class="kpi"><div class="kpi-ico">🏆</div><div class="kpi-lbl">CA mois</div><div class="kpi-val sm">${fmtM(caMois)}</div></div>
    <div class="kpi"><div class="kpi-ico">🛒</div><div class="kpi-lbl">Panier moyen</div><div class="kpi-val sm">${fmtM(pm)}</div></div>
    `:'<div class="kpi"><div class="kpi-lbl">Chiffres CA</div><div style="font-size:11px;color:var(--blanc-muted);margin-top:8px">🔒 Réservé Admin / Gérant</div></div>'}
  `;
  // Chart (admin/gerant only)
  if(showCA){
    const bars=Array(7).fill(0);
    DB.commandes.forEach(c=>{const d=Math.floor((Date.now()-new Date(c.dateEntree))/864e5);if(d<7)bars[6-d]+=gTot(c.id);});
    const mx=Math.max(...bars,1);
    document.getElementById('miniChart').innerHTML=bars.map((v,i)=>`<div class="mini-bar" style="flex:1;background:${i===6?'var(--or)':'var(--or-muted)'};height:${Math.round(v/mx*42)+3}px" title="${fmtM(v)}"></div>`).join('');
    const days=['L','M','M','J','V','S','D'];const dw=new Date().getDay();
    document.getElementById('chartLbls').innerHTML=bars.map((_,i)=>`<span>${i===6?'Auj':days[(dw-6+i+7)%7]}</span>`).join('');
  } else {
    document.getElementById('miniChart').innerHTML='<div style="flex:1;text-align:center;font-size:11px;color:var(--blanc-muted);padding:12px">🔒 Accès restreint</div>';
    document.getElementById('chartLbls').innerHTML='';
  }
  // Distrib
  const dist={};WF.forEach(s=>dist[s]=0);DB.commandes.forEach(c=>{if(dist[c.statut]!==undefined)dist[c.statut]++;});
  document.getElementById('distrib').innerHTML=Object.entries(dist).map(([s,n])=>`
    <div class="stat-bar"><div class="stat-bar-lbl">${WFI[WF.indexOf(s)]} ${s}</div>
    <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${DB.commandes.length?Math.round(n/DB.commandes.length*100):0}%"></div></div>
    <div class="stat-bar-val">${n}</div></div>`).join('');
  // Commandes récentes : tous les rôles voient toutes les commandes
  const rCmds = DB.commandes;
  const rec=[...rCmds].sort((a,b)=>new Date(b.dateEntree)-new Date(a.dateEntree)).slice(0,5);
  document.getElementById('recentTbody').innerHTML=rec.map(cmd=>`<tr onclick="openDetail('${cmd.id}')">
    <td style="color:var(--or-clair);font-family:var(--f-d)">${cmd.id}</td>
    <td>${gc(cmd.clientId).nom}</td><td class="td-m">${gi(cmd.id).length}</td>
    <td style="font-family:var(--f-d);color:var(--or-clair)">${showCA?fmtM(gTot(cmd.id)):'—'}</td>
    <td>${badge(isRetard(cmd)?'retard':cmd.statut)}</td><td class="td-m">${fmtD(cmd.dateEntree)}</td>
    <td><button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();openDetail('${cmd.id}')">Voir</button></td></tr>`).join('')
  ||'<tr><td colspan="7" style="text-align:center;color:var(--blanc-muted);padding:30px">Aucune commande — créez la première !</td></tr>';
  // Mettre à jour le widget présence dans l'accueil
  _renderAccueilPresence();
}

function renderOps(){
  const counts={};WF.forEach(s=>counts[s]=0);DB.commandes.filter(c=>c.statut!=='livré').forEach(c=>{if(counts[c.statut]!==undefined)counts[c.statut]++;});
  document.getElementById('pipeline').innerHTML=WF.slice(0,-1).map((s,i)=>`
    <div class="pip ${counts[s]>0?'act':''}" onclick="document.getElementById('cmdFilter').value='${s}';nav('commandes')">
      <div class="pip-ico">${WFI[i]}</div><div class="pip-n">${counts[s]}</div><div class="pip-lbl">${s}</div>
    </div>`).join('');
  const rets=DB.commandes.filter(c=>isRetard(c));
  document.getElementById('retardCount').textContent=`${rets.length} retard(s)`;
  document.getElementById('alertList').innerHTML=rets.length?rets.map(c=>`
    <div class="alert-row"><span style="color:var(--rouge)">⚠️</span>
    <span style="flex:1"><strong>${c.id}</strong> — ${gc(c.clientId).nom} — ${c.statut}</span>
    <button class="btn btn-gold btn-sm" onclick="openDetail('${c.id}')">Voir</button></div>`).join('')
    :'<div style="color:var(--vert);text-align:center;padding:12px">✓ Aucun retard</div>';
  const ec=DB.commandes.filter(c=>c.statut!=='livré');
  document.getElementById('enCoursTbody').innerHTML=ec.map(cmd=>{
    const ss=cmd.etapes&&cmd.etapes[cmd.statut]?new Date(cmd.etapes[cmd.statut]):null;
    const hrs=ss?Math.round((Date.now()-ss)/3600000):0;
    const nx=nextSt(cmd.statut);
    return`<tr onclick="openDetail('${cmd.id}')">
      <td style="color:var(--or-clair);font-family:var(--f-d)">${cmd.id}</td>
      <td>${gc(cmd.clientId).nom}</td><td>${badge(isRetard(cmd)?'retard':cmd.statut)}</td>
      <td class="td-m">${hrs}h</td>
      <td>${nx?`<button class="btn btn-gold btn-sm" onclick="event.stopPropagation();advSt('${cmd.id}','${nx}')">→ ${nx}</button>`:badge('livré')}</td></tr>`;}).join('')
  ||'<tr><td colspan="5" style="text-align:center;color:var(--blanc-muted);padding:24px">Aucune commande en cours</td></tr>';
}

function renderCommandes(){
  const f=document.getElementById('cmdFilter')?.value||'';
  const src = DB.commandes; // Tous les rôles voient toutes les commandes
  const list=f?src.filter(c=>c.statut===f):src;
  document.getElementById('cmdCount').textContent=`${list.length} commande(s)`;
  const showCA=canDo('viewKpi');
  document.getElementById('cmdTbody').innerHTML=list.map(cmd=>{
    const total=gTot(cmd.id),reste=gRest(cmd),cr=DB.users.find(u=>u.id===cmd.createdBy);
    return`<tr onclick="openDetail('${cmd.id}')">
      <td style="color:var(--or-clair);font-family:var(--f-d)">${cmd.id}</td>
      <td>${gc(cmd.clientId).nom}</td>
      <td class="td-m" style="font-size:10px">${cr?cr.name:'—'}</td>
      <td class="td-m">${gi(cmd.id).length}</td>
      <td style="font-family:var(--f-d)">${showCA?fmtM(total):'—'}</td>
      <td style="color:var(--vert)">${showCA?fmtM(cmd.avance||0):'—'}</td>
      <td style="color:${reste>0?'var(--rouge)':'var(--vert)'}">${showCA?fmtM(reste):'—'}</td>
      <td>${badge(isRetard(cmd)?'retard':cmd.statut)}</td>
      <td class="td-m">${fmtD(cmd.dateEntree)}</td>
      <td style="display:flex;gap:3px;padding:6px 10px" onclick="event.stopPropagation()">
        <button class="btn btn-ghost btn-sm" onclick="openDetail('${cmd.id}')">👁</button>
        <button class="btn btn-outline btn-sm" onclick="genFacture('${cmd.id}')">📄</button>
        <button class="btn btn-outline btn-sm" onclick="genRecu('${cmd.id}')">🧾</button>
        ${canDo('sendWhatsApp')?`<button class="btn btn-xs" style="background:rgba(37,211,102,.12);color:#25D366;border:1px solid rgba(37,211,102,.3);border-radius:3px;padding:3px 6px;cursor:pointer;font-size:9px" onclick="sendWhatsApp('${cmd.id}','facture')" title="Envoyer facture WhatsApp">💬</button>`:''}
        ${nextSt(cmd.statut)?`<button class="btn btn-gold btn-sm" onclick="advSt('${cmd.id}','${nextSt(cmd.statut)}')">→</button>`:''}
      </td></tr>`;}).join('')
  ||'<tr><td colspan="10" style="text-align:center;color:var(--blanc-muted);padding:30px">Aucune commande</td></tr>';
}

function renderClients(){
  const q=(document.getElementById('clientSearch')?.value||'').toLowerCase();
  const tf=document.getElementById('clientTypeFilter')?.value||'';
  let list = DB.clients; // Tous les rôles voient tous les clients
  if(q) list=list.filter(c=>(c.nom+c.tel+c.ville+(c.email||'')).toLowerCase().includes(q));
  if(tf) list=list.filter(c=>c.type===tf);
  list = list.slice().sort((a,b)=>a.nom.localeCompare(b.nom,'fr',{sensitivity:'base'}));
  document.getElementById('clientCount').textContent=`${list.length} client(s)`;
  // Show relance section for admin/gérant
  const relSec = document.getElementById('clientsRelanceSection');
  if(relSec && canDo('sendWhatsApp')){
    const anciens = DB.clients.filter(c=>isClientAncien(c));
    if(anciens.length>0){
      relSec.innerHTML=`<div style="background:rgba(232,160,48,.08);border:1px solid rgba(232,160,48,.3);border-radius:var(--radius);padding:12px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div><span style="font-size:13px;color:#e8a030">🔔 ${anciens.length} client(s) inactif(s) depuis +2 semaines</span>
        <div style="font-size:10px;color:var(--blanc-muted);margin-top:2px">${anciens.slice(0,3).map(c=>c.nom).join(', ')}${anciens.length>3?' …':''}</div></div>
        <button class="btn btn-sm" style="background:#e8a03022;color:#e8a030;border:1px solid rgba(232,160,48,.4)" onclick="afficherClientsARelancer()">Voir &amp; Relancer</button>
      </div>`;
    } else {
      relSec.innerHTML='';
    }
  } else if(relSec){
    relSec.innerHTML='';
  }
  document.getElementById('clientsGrid').innerHTML=list.map(c=>{
    const cmds=DB.commandes.filter(cmd=>cmd.clientId===c.id);
    const ca=cmds.reduce((s,cmd)=>s+gTot(cmd.id),0);
    const cr=DB.users.find(u=>u.id===c.createdBy);
    return`<div class="profile-card" onclick="openClientDetail('${c.id}')">
      <div class="pc-avatar">${ini(c.nom)}</div>
      <div class="pc-name">${c.nom}</div>
      <div class="pc-meta">${c.tel||'—'}</div>
      <div class="pc-meta">${c.ville||''} ${c.type?'· '+c.type:''}</div>
      <div style="margin-top:5px;font-size:9px;color:var(--blanc-muted)">Par: ${cr?cr.name:'—'}</div>
      <div class="pc-stats">
        <div class="pc-stat"><span class="pc-sv">${cmds.length}</span><span class="pc-sl">Cmds</span></div>
        ${canDo('viewKpi')?`<div class="pc-stat"><span class="pc-sv" style="font-size:14px">${Math.round(ca/1000)}k</span><span class="pc-sl">FCFA</span></div>`:''}
      </div></div>`;}).join('')
  ||`<div class="empty" style="grid-column:1/-1"><div class="empty-ico">👥</div><div class="empty-txt">Aucun client</div></div>`;
}

function afficherClientsARelancer(){
  if(!canDo('viewRelances')){showToast('🔒 Accès non autorisé','w');return;}
  const anciens = DB.clients.filter(c=>isClientAncien(c));
  if(anciens.length===0){showToast('Aucun client inactif','');return;}
  // Build a simple selection modal message
  const list = anciens.map(c=>{
    const cmds=DB.commandes.filter(cmd=>cmd.clientId===c.id);
    const lastCmd = cmds.length ? cmds.reduce((a,b)=>new Date(a.dateEntree)>new Date(b.dateEntree)?a:b) : null;
    const days = lastCmd ? Math.floor((Date.now()-new Date(lastCmd.dateEntree))/(1000*60*60*24)) : null;
    return {c, days};
  });
  // Open a selection popup
  const modal = document.createElement('div');
  modal.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9000;display:flex;align-items:center;justify-content:center;padding:16px';
  modal.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;max-width:480px;width:100%;max-height:80vh;overflow:hidden;display:flex;flex-direction:column">
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
      <div style="font-family:var(--f-d);color:var(--or-clair)">🔔 Clients à relancer</div>
      <button onclick="this.closest('[style*=fixed]').remove()" style="background:none;border:none;color:var(--blanc-muted);font-size:20px;cursor:pointer">×</button>
    </div>
    <div style="overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px">
      ${list.map(({c,days})=>`
        <div style="background:var(--charbon);border-radius:5px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">
          <div>
            <div style="font-size:13px">${c.nom}</div>
            <div style="font-size:10px;color:var(--blanc-muted)">${c.tel||'Pas de tel'} · ${days?'Inactif depuis '+days+'j':'Jamais commandé'}</div>
          </div>
          ${c.tel?`<button class="btn btn-xs" style="background:rgba(37,211,102,.15);color:#25D366;border:1px solid rgba(37,211,102,.3);flex-shrink:0" onclick="relancerClientWA('${c.id}',this.closest('[style*=fixed]'))">💬 Relancer</button>`:'<span style="font-size:9px;color:var(--blanc-muted)">Pas de tel</span>'}
        </div>`).join('')}
    </div>
    <div style="padding:12px 16px;border-top:1px solid var(--border);text-align:right">
      <button class="btn btn-ghost btn-sm" onclick="this.closest('[style*=fixed]').remove()">Fermer</button>
    </div>
  </div>`;
  document.body.appendChild(modal);
}

async function relancerClientWA(cId, modalEl){
  if(!canDo('sendWhatsApp')){showToast('🔒 Non autorisé','w');return;}
  const client = DB.clients.find(c=>c.id===cId);
  if(!client||!client.tel){showToast('Pas de numéro pour ce client','w');return;}
  let tel=(client.tel||'').replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  const msg=[
    '\uD83C\uDFF7 *IVOIRE LUXE PRESSING*',
    '_Redorer l\'\u00e9clat de votre linge_',
    '',
    'Bonjour *'+client.nom+'*,',
    '',
    'Nous pensons \u00e0 vous ! \uD83D\uDE0A',
    'Votre linge m\u00e9rite le meilleur soin.',
    '',
    'Revenez nous confier votre linge —',
    'nous le traitons avec soin et \u00e9l\u00e9gance.',
    '',
    '\uD83D\uDCDE 01 01 81 33 01 / 05 85 05 41 16',
    '\uD83D\uDCCD Bingerville &amp; Jacqueville · C\u00f4te d\'Ivoire',
  ].join('\n');
  window.open('https://wa.me/'+tel+'?text='+encodeURIComponent(msg),'_blank');
  addNotif('relance','Relance WhatsApp envoyée à '+client.nom+' par '+CU.name,{categorie:'relances',clientId:cId,notifyManagers:true});
  await saveDB();
  showToast('Relance envoyée à '+client.nom+' 💬','s');
  if(modalEl) modalEl.remove();
}

function renderProcess(){
  const actif = DB.commandes.filter(c=>c.statut!=='livré'); // Tous les rôles voient tout le process
  document.getElementById('processList').innerHTML=actif.map(cmd=>{
    const si=WF.indexOf(cmd.statut);
    const steps=WF.slice(0,-1).map((s,i)=>{let cls=i<si?'done':i===si?'cur':'';return`<div class="step-dot ${cls}" title="${s}" onclick="advSt('${cmd.id}','${WF[i+1]||s}')">${WFI[i]}</div>`;}).join('');
    return`<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:12px;margin-bottom:8px;display:flex;align-items:center;gap:12px">
      <div style="font-family:var(--f-d);font-size:18px;color:var(--or-clair);min-width:50px">#${cmd.id.split('-').pop()}</div>
      <div style="flex:1"><div style="font-size:13px">${gc(cmd.clientId).nom}</div><div style="font-size:10px;color:var(--blanc-muted)">${gi(cmd.id).length} pcs · ${cmd.site} · ${fmtD(cmd.dateEntree)}</div></div>
      <div style="display:flex;gap:3px">${steps}</div>${isRetard(cmd)?badge('retard'):''}
    </div>`;}).join('')||`<div class="empty"><div class="empty-ico">🧺</div><div class="empty-txt">Aucune commande en cours</div></div>`;
}

function renderFacturation(){
  if(!canDo('viewFacturation')){
    document.getElementById('factKpis').innerHTML='';
    document.getElementById('factTbody').innerHTML=`<tr><td colspan="7"><div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Accès restreint</div><div class="restricted-sub">Réservé Administrateur et Gérant</div></div></td></tr>`;
    return;
  }
  const f=document.getElementById('factFilter')?.value||'';
  const list=DB.commandes.filter(c=>f?payStatus(c)===f:true);
  const totCA=DB.commandes.reduce((s,c)=>s+gTot(c.id),0);
  const totPay=DB.commandes.reduce((s,c)=>s+(c.avance||0),0);
  document.getElementById('factSub').textContent=`${list.length} facture(s)`;
  document.getElementById('factKpis').innerHTML=`
    <div class="kpi"><div class="kpi-lbl">CA Total</div><div class="kpi-val sm">${fmtM(totCA)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Encaissé</div><div class="kpi-val sm" style="color:var(--vert)">${fmtM(totPay)}</div></div>
    <div class="kpi"><div class="kpi-lbl">À recouvrer</div><div class="kpi-val sm" style="color:var(--rouge)">${fmtM(Math.max(0,totCA-totPay))}</div></div>`;
  document.getElementById('factTbody').innerHTML=list.map(cmd=>{
    const total=gTot(cmd.id),reste=gRest(cmd),ps=payStatus(cmd);
    const isAdmin=canDo('editFacture');
    return`<tr><td style="color:var(--or-clair);font-family:var(--f-d)">${cmd.id}</td>
      <td>${gc(cmd.clientId).nom}</td><td style="font-family:var(--f-d)">${fmtM(total)}</td>
      <td style="color:var(--vert)">${fmtM(cmd.avance||0)}</td>
      <td style="color:${reste>0?'var(--rouge)':'var(--vert)'}">${fmtM(reste)}</td>
      <td>${badge(ps)}</td>
      <td style="display:flex;gap:3px;padding:6px 10px">
        ${isAdmin?`<button class="btn btn-ghost btn-sm" onclick="encaisser('${cmd.id}')">💳</button>`:''}
        ${canDo('genDocument')?`<button class="btn btn-outline btn-sm" onclick="genFacture('${cmd.id}')">📄</button>`:''}
        ${canDo('genDocument')?`<button class="btn btn-outline btn-sm" onclick="genRecu('${cmd.id}')">🧾</button>`:''}
        ${canDo('sendWhatsApp')?`<button class="btn btn-xs" style="background:rgba(37,211,102,.12);color:#25D366;border:1px solid rgba(37,211,102,.3);border-radius:3px;padding:4px 7px;cursor:pointer;font-size:10px" onclick="sendWhatsApp('${cmd.id}','facture')" title="Envoyer WhatsApp">💬 WA</button>`:''}
      </td></tr>`;}).join('')
  ||'<tr><td colspan="7" style="text-align:center;color:var(--blanc-muted);padding:30px">Aucun résultat</td></tr>';
}

async function encaisser(cmdId){
  if(!canDo('editFacture')){showToast('Réservé administrateur','w');return;}
  const cmd=DB.commandes.find(c=>c.id===cmdId);if(!cmd)return;
  const r=gRest(cmd);
  const m=prompt(`${cmd.id} — Reste: ${fmtM(r)}\nMontant à encaisser (FCFA):`);
  if(!m||isNaN(+m))return;
  cmd.avance=(cmd.avance||0)+(+m);
  addNotif('paiement',`Encaissement ${fmtM(+m)} — ${cmd.id} (${gc(cmd.clientId).nom}) par ${CU.name}`,{categorie:'paiements',cmdId:cmd.id,clientId:cmd.clientId,notifyManagers:true});
  await saveDB();showToast(`${fmtM(+m)} enregistré ✓`,'s');renderFacturation();
}

function renderLivraisons(){
  if(!canDo('viewLivraisons')){
    document.getElementById('livrGrid').innerHTML=`<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Accès restreint</div><div class="restricted-sub">Réservé Administrateur et Gérant</div></div>`;
    return;
  }
  const livs=DB.commandes.filter(c=>c.statut==='livré');
  document.getElementById('livrGrid').innerHTML=livs.length?livs.map(cmd=>{
    const client=gc(cmd.clientId),total=gTot(cmd.id),ps=payStatus(cmd);
    return`<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:14px;margin-bottom:8px;display:flex;align-items:center;gap:12px">
      <div style="width:38px;height:38px;background:rgba(201,168,76,.1);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0">🚚</div>
      <div style="flex:1"><div style="font-size:13px">${cmd.id} — ${client.nom}</div>
      <div style="font-size:10px;color:var(--blanc-muted)">${cmd.site} · ${fmtD(cmd.etapes?.livré)} · ${gi(cmd.id).length} pcs</div>
      <div style="margin-top:4px">${badge(ps)}</div></div>
      <div style="text-align:right">
        <div style="font-family:var(--f-d);font-size:20px;color:var(--or-clair)">${fmtM(total)}</div>
        <button class="btn btn-outline btn-sm" onclick="genFacture('${cmd.id}')" style="margin-top:4px">📄 Facture</button>
      </div></div>`;}).join('')
  :`<div class="empty"><div class="empty-ico">🚚</div><div class="empty-txt">Aucune livraison archivée</div></div>`;
}

function renderTarifs(){
  // Show/hide edit actions based on role
  const actions=document.getElementById('tarifsActions');
  if(actions) actions.style.display=canDo('editTarifs')?'flex':'none';
  document.getElementById('tarifsGrid').innerHTML=DB.tarifs.map(cat=>`
    <div style="margin-bottom:18px">
      <div style="font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:var(--or);margin-bottom:9px;padding-bottom:5px;border-bottom:1px solid var(--border)">🏷 ${cat.cat}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:7px">
        ${cat.items.map(it=>`<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:10px 12px;display:flex;justify-content:space-between;align-items:center">
          <div style="font-size:12px">${it.nom}</div>
          <div style="text-align:right"><div style="font-family:var(--f-d);font-size:17px;color:var(--or-clair)">${it.prix.toLocaleString('fr-FR')}</div><div style="font-size:9px;color:var(--blanc-muted)">FCFA/pce</div></div>
        </div>`).join('')}
      </div>
    </div>`).join('');
}

function initEditTarifs(){
  document.getElementById('editTarifsBody').innerHTML=DB.tarifs.map((cat,ci)=>`
    <div style="margin-bottom:18px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:9px">
        <div style="font-size:10px;letter-spacing:.16em;text-transform:uppercase;color:var(--or);font-weight:700">${cat.cat}</div>
        <button class="btn btn-ghost btn-sm" onclick="addArt(${ci})">＋ Article</button>
      </div>
      ${cat.items.map((it,ii)=>`
        <div style="display:grid;grid-template-columns:auto 2fr 1fr 30px;gap:7px;align-items:center;padding:5px 0;border-bottom:1px solid var(--border)">
          <span style="font-size:10px;color:var(--blanc-muted)">${ii+1}.</span>
          <input class="fi" value="${it.nom}" id="tn-${ci}-${ii}" style="font-size:11px">
          <input type="number" class="fi" value="${it.prix}" id="tp-${ci}-${ii}">
          <button class="btn btn-danger btn-xs" onclick="delArt(${ci},${ii})">✕</button>
        </div>`).join('')}
    </div>`).join('');
}
function addArt(ci){ DB.tarifs[ci].items.push({id:uid('A'),nom:'Nouvel article',prix:0}); initEditTarifs(); }
function delArt(ci,ii){ if(!confirm('Supprimer ?'))return; DB.tarifs[ci].items.splice(ii,1); initEditTarifs(); }
async function saveTarifs(){
  DB.tarifs.forEach((cat,ci)=>cat.items.forEach((it,ii)=>{
    const n=document.getElementById(`tn-${ci}-${ii}`),p=document.getElementById(`tp-${ci}-${ii}`);
    if(n)it.nom=n.value;if(p)it.prix=+p.value;
  }));
  await saveDB();closeModal('editTarifs');showToast('Tarifs mis à jour ✓','s');renderTarifs();
}
async function addCat(){
  const n=document.getElementById('newCatName').value.trim();
  if(!n){showToast('Nom requis','w');return;}
  DB.tarifs.push({id:uid('T'),cat:n,items:[]});
  await saveDB();closeModal('addCat');showToast(`"${n}" créée ✓`,'s');renderTarifs();
}

// ════════════════════════════════════════════════════════
// HISTORIQUE MENSUEL
// ════════════════════════════════════════════════════════
function renderHistorique(){
  if(!canDo('viewHistorique')){
    document.getElementById('histMonths').innerHTML=`<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Accès restreint</div><div class="restricted-sub">Réservé Administrateur et Gérant</div></div>`;
    document.getElementById('histGlobal').innerHTML='';
    return;
  }
  // Build year selector
  const years=[...new Set(DB.commandes.map(c=>new Date(c.dateEntree).getFullYear()))].sort((a,b)=>b-a);
  if(!years.length) years.push(new Date().getFullYear());
  const yel=document.getElementById('histYear');
  const curYear=+yel.value||years[0];
  yel.innerHTML=years.map(y=>`<option value="${y}" ${y===curYear?'selected':''}>${y}</option>`).join('');

  const cmdsYear=DB.commandes.filter(c=>new Date(c.dateEntree).getFullYear()===curYear);
  const totalCA=cmdsYear.reduce((s,c)=>s+gTot(c.id),0);
  const totalPay=cmdsYear.reduce((s,c)=>s+(c.avance||0),0);
  const livrees=cmdsYear.filter(c=>c.statut==='livré').length;

  document.getElementById('histGlobal').innerHTML=`
    <div class="kpi"><div class="kpi-lbl">Commandes ${curYear}</div><div class="kpi-val">${cmdsYear.length}</div></div>
    <div class="kpi"><div class="kpi-lbl">CA ${curYear}</div><div class="kpi-val sm">${fmtM(totalCA)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Encaissé</div><div class="kpi-val sm" style="color:var(--vert)">${fmtM(totalPay)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Livraisons</div><div class="kpi-val">${livrees}</div></div>`;

  const MOIS=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
  let html='';
  for(let m=11;m>=0;m--){
    const cmds=cmdsYear.filter(c=>new Date(c.dateEntree).getMonth()===m);
    if(!cmds.length) continue;
    const ca=cmds.reduce((s,c)=>s+gTot(c.id),0);
    const pay=cmds.reduce((s,c)=>s+(c.avance||0),0);
    const livr=cmds.filter(c=>c.statut==='livré').length;
    const rets=cmds.filter(c=>isRetard(c)).length;
    // Per-user breakdown
    const byUser={};
    cmds.forEach(c=>{
      const u=c.createdBy||'?';
      if(!byUser[u]) byUser[u]={count:0,ca:0};
      byUser[u].count++;byUser[u].ca+=gTot(c.id);
    });
    html+=`<div class="month-card">
      <div class="month-card-hd">
        <div>
          <div class="month-name">${MOIS[m]} ${curYear}</div>
          <div style="font-size:10px;color:var(--blanc-muted)">${cmds.length} commande(s)</div>
        </div>
        <div style="text-align:right">
          <div style="font-family:var(--f-d);font-size:22px;color:var(--or-clair)">${fmtM(ca)}</div>
          <div style="font-size:10px;color:var(--vert)">Encaissé: ${fmtM(pay)}</div>
        </div>
      </div>
      <div class="month-stats">
        <div class="mst"><span class="mst-val">${cmds.length}</span><span class="mst-lbl">Commandes</span></div>
        <div class="mst"><span class="mst-val">${livr}</span><span class="mst-lbl">Livrées</span></div>
        <div class="mst"><span class="mst-val" style="color:${rets?'var(--rouge)':'var(--or-clair)'}">${rets}</span><span class="mst-lbl">Retards</span></div>
        <div class="mst"><span class="mst-val" style="font-size:15px">${fmtM(ca-pay)}</span><span class="mst-lbl">À recouvrer</span></div>
      </div>
      ${Object.keys(byUser).length>1?`
      <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)">
        <div style="font-size:9px;letter-spacing:.15em;text-transform:uppercase;color:var(--blanc-muted);margin-bottom:8px">Par utilisateur</div>
        ${Object.entries(byUser).map(([uid,s])=>{const u=DB.users.find(x=>x.id===uid);return`
          <div class="stat-bar"><div class="stat-bar-lbl">${u?u.name:uid}</div>
          <div class="stat-bar-track"><div class="stat-bar-fill" style="width:${Math.round(s.count/cmds.length*100)}%"></div></div>
          <div class="stat-bar-val">${s.count} cmds</div></div>`;}).join('')}
      </div>`:''}
    </div>`;
  }
  document.getElementById('histMonths').innerHTML=html||`<div class="empty"><div class="empty-ico">📊</div><div class="empty-txt">Aucune donnée pour ${curYear}</div></div>`;
}

// ════════════════════════════════════════════════════════
// NOTIFICATIONS
// ════════════════════════════════════════════════════════
function addNotif(type, msg, opts){
  opts = opts || {};
  const n = {
    id:       uid('N'),
    type:     type,
    msg:      msg,
    time:     Date.now(),
    read:     false,
    categorie: opts.categorie || _notifCategorie(type),
    clientId:  opts.clientId  || null,
    cmdId:     opts.cmdId     || null,
    byUser:    opts.byUser    || (CU ? CU.name : null),
    byRole:    opts.byRole    || (CU ? CU.role : null),
    forRoles:  opts.forRoles  || 'all',
  };
  DB.notifs.push(n);
  // Si envoyé par réceptionniste → notifier admin/gérant en temps réel
  if(CU && CU.role === 'receptionniste' && opts.notifyManagers !== false){
    n.forRoles = 'managers';
    // Broadcast to managers via Supabase realtime
    if(_supa){
      _supa.channel('ilp-manager-alerts').send({
        type:'broadcast', event:'receptionniste_action',
        payload:{
          type, msg, categorie:n.categorie,
          clientId:n.clientId, cmdId:n.cmdId,
          byUser:n.byUser, urgent: ['commande','paiement','retard'].includes(type)
        }
      }).catch(()=>{});
    }
  }
  updateBadges();
}

function _notifCategorie(type){
  const map = {
    retard:'retards', pret:'commandes', info:'general',
    commande:'commandes', client:'clients', paiement:'paiements',
    relance:'relances', document:'documents', connexion:'systeme'
  };
  return map[type] || 'general';
}
async function markAllRead(){
  const role = CU ? CU.role : 'all';
  DB.notifs.forEach(n=>{
    if(n.forRoles==='all' || n.forRoles==='managers' && ['admin','gerant'].includes(role) || n.byRole===role) n.read=true;
  });
  await saveDB(); updateBadges(); renderNotifs(); showToast('Toutes lues ✓','s');
}

async function markNotifRead(nId){
  const n=DB.notifs.find(x=>x.id===nId); if(n) n.read=true;
  await saveDB(); updateBadges(); renderNotifs();
}

function _notifVisible(n){
  if(!CU) return false;
  if(n.forRoles==='all') return true;
  if(n.forRoles==='managers') return ['admin','gerant'].includes(CU.role);
  return true;
}

function renderNotifs(){
  // Filter by role visibility
  let notifs = DB.notifs.filter(n=>_notifVisible(n));

  // Get active category filter
  const cat = document.getElementById('notifCatFilter')?.value || '';
  if(cat) notifs = notifs.filter(n=>(n.categorie||'general')===cat);

  // Sort: unread first, then by time desc (chronological newest-first)
  notifs.sort((a,b)=>{
    if(!a.read && b.read) return -1;
    if(a.read && !b.read) return 1;
    return b.time - a.time;
  });

  const unread = notifs.filter(n=>!n.read).length;

  const catIco = {
    commandes:'📋', clients:'👥', paiements:'💳', documents:'📄',
    relances:'🔔', retards:'⚠️', general:'ℹ️', systeme:'🔐', 'general':'ℹ️'
  };
  const catColor = {
    retards:'var(--rouge)', commandes:'var(--or)', paiements:'var(--vert)',
    documents:'#7abce0', relances:'#e8a030', systeme:'#888', general:'var(--or)'
  };

  // Group by date
  const groups = {};
  notifs.forEach(n=>{
    const d = new Date(n.time);
    const today = new Date(); today.setHours(0,0,0,0);
    const yesterday = new Date(today); yesterday.setDate(yesterday.getDate()-1);
    let key;
    if(d >= today) key = "Aujourd'hui";
    else if(d >= yesterday) key = "Hier";
    else key = d.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    if(!groups[key]) groups[key]=[];
    groups[key].push(n);
  });

  const html = Object.entries(groups).map(([date,items])=>`
    <div style="font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:var(--or);padding:10px 0 6px;border-bottom:1px solid var(--border);margin-bottom:4px">${date}</div>
    ${items.map(n=>{
      const ico = catIco[n.categorie||'general']||'ℹ';
      const col = catColor[n.categorie||'general']||'var(--or)';
      const client = n.clientId ? (DB.clients.find(c=>c.id===n.clientId)||DB.prospects.find(p=>p.id===n.clientId)) : null;
      const timeStr = new Date(n.time).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
      const bgColor = n.read ? 'transparent' : 'rgba(201,168,76,.04)';
      const brdColor = n.read ? 'transparent' : 'rgba(201,168,76,.12)';
      const txtColor = n.read ? 'var(--blanc)' : 'var(--or-clair)';
      const clientBadge = client ? `<span style="font-size:9px;background:rgba(201,168,76,.12);color:var(--or-clair);padding:1px 6px;border-radius:10px">👤 ${client.nom}</span>` : '';
      const byBadge = (n.byUser&&n.byRole==='receptionniste') ? `<span style="font-size:9px;background:rgba(90,120,200,.12);color:#7abce0;padding:1px 6px;border-radius:10px">par ${n.byUser}</span>` : '';
      const unreadDot = n.read ? '' : '<div style="width:7px;height:7px;background:var(--or);border-radius:50%;flex-shrink:0;margin-top:5px"></div>';
      const unreadBadge = n.read ? '' : '<span style="color:var(--or)">· non lu</span>';
      return `<div data-nid="${n.id}" class="_notif-row" style="display:flex;gap:10px;padding:10px 8px;border-radius:6px;margin-bottom:3px;cursor:pointer;background:${bgColor};border:1px solid ${brdColor};transition:background .15s">
        <div style="width:30px;height:30px;border-radius:8px;background:${col}18;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0">${ico}</div>
        <div style="flex:1;min-width:0">
          <div style="font-size:12px;color:${txtColor};line-height:1.4">${n.msg}</div>
          <div style="display:flex;gap:8px;align-items:center;margin-top:3px;flex-wrap:wrap">
            ${clientBadge}${byBadge}
            <span style="font-size:9px;color:var(--blanc-muted)">${timeStr} ${unreadBadge}</span>
          </div>
        </div>
        ${unreadDot}
      </div>`;
    }).join('')}    }).join('')}
  `).join('') || '<div style="color:var(--blanc-muted);text-align:center;padding:30px">Aucune notification</div>';

  document.getElementById('notifLog').innerHTML = html;
  // Bind click on notif rows
  document.getElementById('notifLog').querySelectorAll('._notif-row').forEach(row=>{
    row.addEventListener('click', ()=>{ markNotifRead(row.dataset.nid); });
    row.addEventListener('mouseover', ()=>{ row.style.background='rgba(255,255,255,.04)'; });
    row.addEventListener('mouseout', ()=>{
      const n=DB.notifs.find(x=>x.id===row.dataset.nid);
      row.style.background = n&&!n.read?'rgba(201,168,76,.04)':'transparent';
    });
  });
  // Update header count
  const hdr = document.getElementById('notifUnreadCount');
  if(hdr) hdr.textContent = unread > 0 ? `${unread} non lue(s)` : 'Tout est lu ✓';
}

// ════════════════════════════════════════════════════════
// PROFIL
// ════════════════════════════════════════════════════════
function renderProfil(){
  const cmds=DB.commandes.filter(c=>c.createdBy===CU.id);
  const clients=DB.clients.filter(c=>c.createdBy===CU.id);
  const isAdmin = CU.role==='admin';
  document.getElementById('profilBody').innerHTML=`
    <div style="display:grid;grid-template-columns:${isAdmin?'1fr 1fr':'1fr'};gap:16px;max-width:900px">

      <!-- MON PROFIL -->
      <div class="card">
        <div class="card-hd"><div class="card-title">👤 Mon profil</div></div>
        <div class="card-body">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px">
            <div style="width:58px;height:58px;border-radius:50%;background:linear-gradient(135deg,var(--or-muted),var(--or-fonce));display:flex;align-items:center;justify-content:center;font-family:var(--f-d);font-size:24px;color:var(--or-clair)">${ini(CU.name)}</div>
            <div>
              <div style="font-family:var(--f-d);font-size:20px;color:var(--blanc)">${CU.name}</div>
              <span class="role-badge ${roleClass(CU.role)}">${roleName(CU.role)}</span>
              <div style="font-size:11px;color:var(--blanc-muted);margin-top:3px">Site: ${CU.site} · ID: ${CU.id}</div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:18px">
            <div class="kpi"><div class="kpi-lbl">Commandes</div><div class="kpi-val">${cmds.length}</div></div>
            <div class="kpi"><div class="kpi-lbl">Clients</div><div class="kpi-val">${clients.length}</div></div>
          </div>
          <div style="font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--or);margin-bottom:10px">Modifier mon nom</div>
          <div style="display:flex;gap:8px;margin-bottom:16px">
            <input class="fi" id="editMyName" value="${CU.name}" style="flex:1">
            <button class="btn btn-gold btn-sm" onclick="saveMyName()">✓</button>
          </div>
          <div style="font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--or);margin-bottom:10px">Changer mon mot de passe</div>
          <div style="display:flex;flex-direction:column;gap:9px">
            <div class="fg"><label class="fl">Nouveau mot de passe</label><input class="fi" type="password" id="newPw1" placeholder="Minimum 6 caractères"></div>
            <div class="fg"><label class="fl">Confirmer</label><input class="fi" type="password" id="newPw2" placeholder="Répéter le mot de passe"></div>
            <button class="btn btn-gold btn-sm" onclick="changePw()" style="align-self:flex-start">Mettre à jour</button>
          </div>
          \${renderBioStatus()}
        </div>
      </div>

      <!-- MODIFIER UTILISATEURS (ADMIN ONLY) -->
      ${isAdmin?`
      <div class="card">
        <div class="card-hd"><div class="card-title">🔐 Modifier un utilisateur</div></div>
        <div class="card-body">
          <div class="fg" style="margin-bottom:12px">
            <label class="fl">Sélectionner l'utilisateur</label>
            <select class="fs" id="editUserSel" onchange="loadUserEdit()">
              <option value="">— Choisir —</option>
              ${DB.users.map(u=>`<option value="${u.id}">${u.name} (${roleName(u.role)})</option>`).join('')}
            </select>
          </div>
          <div id="editUserForm" style="display:none">
            <div style="display:flex;flex-direction:column;gap:10px">
              <div class="fg"><label class="fl">Nom complet</label><input class="fi" id="eu-name" placeholder="Nom"></div>
              <div class="fg"><label class="fl">Rôle</label>
                <select class="fs" id="eu-role">
                  <option value="receptionniste">Réceptionniste</option>
                  <option value="gerant">Gérant</option>
                  <option value="admin">Administrateur</option>
                </select>
              </div>
              <div class="fg"><label class="fl">Site assigné</label>
                <select class="fs" id="eu-site"><option>Bingerville</option><option>Jacqueville</option><option>Les deux</option></select>
              </div>
              <div class="fg"><label class="fl">Nouveau mot de passe (laisser vide = inchangé)</label>
                <div style="display:flex;gap:7px">
                  <input class="fi" id="eu-pw" placeholder="Laisser vide pour ne pas changer" style="flex:1">
                  <button class="btn btn-ghost btn-sm" onclick="document.getElementById('eu-pw').value=genRandPw()">🎲</button>
                </div>
              </div>
              <div style="display:flex;gap:8px;margin-top:4px">
                <button class="btn btn-gold" onclick="saveUserEdit()" style="flex:1">✓ Enregistrer</button>
                <button class="btn btn-danger btn-sm" onclick="deleteUserFromProfil()">🗑 Supprimer</button>
              </div>
            </div>
          </div>
          <div id="editUserEmpty" style="text-align:center;padding:20px;color:var(--blanc-muted);font-size:12px">
            Sélectionnez un utilisateur ci-dessus pour modifier son profil
          </div>
        </div>
      </div>
      `:''}
    </div>`;
}

async function saveMyName(){
  const n=document.getElementById('editMyName')?.value.trim();
  if(!n){showToast('Nom requis','w');return;}
  const user=DB.users.find(u=>u.id===CU.id);
  if(!user)return;
  user.name=n;CU.name=n;
  sessionStorage.setItem('ilp_cu',JSON.stringify(CU));
  await saveDB();
  // Update topbar
  document.getElementById('topName').textContent=n;
  document.getElementById('topAvatar').textContent=ini(n);
  document.getElementById('sideUserName').textContent=n;
  showToast('Nom mis à jour ✓','s');
}

async function loadUserEdit(){
  const uid=document.getElementById('editUserSel').value;
  const form=document.getElementById('editUserForm');
  const empty=document.getElementById('editUserEmpty');
  if(!uid){form.style.display='none';empty.style.display='block';return;}
  const u=DB.users.find(x=>x.id===uid);
  if(!u)return;
  form.style.display='block';empty.style.display='none';
  document.getElementById('eu-name').value=u.name;
  document.getElementById('eu-role').value=u.role;
  document.getElementById('eu-site').value=u.site;
  document.getElementById('eu-pw').value='';
}

function genRandPw(){
  const chars='ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let pw='';for(let i=0;i<8;i++) pw+=chars[Math.floor(Math.random()*chars.length)];
  return pw;
}

async function saveUserEdit(){
  const uid=document.getElementById('editUserSel').value;
  if(!uid){showToast('Sélectionner un utilisateur','w');return;}
  const u=DB.users.find(x=>x.id===uid);
  if(!u)return;
  const name=document.getElementById('eu-name').value.trim();
  const role=document.getElementById('eu-role').value;
  const site=document.getElementById('eu-site').value;
  const pw=document.getElementById('eu-pw').value.trim();
  if(!name){showToast('Nom requis','w');return;}
  if(pw && pw.length<6){showToast('Mot de passe: minimum 6 caractères','w');return;}
  u.name=name;u.role=role;u.site=site;
  if(pw) u.pw=pw;
  // If editing self, update session
  if(uid===CU.id){
    CU.name=name;CU.role=role;CU.site=site;
    if(pw) CU.pw=pw;
    sessionStorage.setItem('ilp_cu',JSON.stringify(CU));
    document.getElementById('topName').textContent=name;
    document.getElementById('topAvatar').textContent=ini(name);
    document.getElementById('sideUserName').textContent=name;
  }
  await saveDB();
  showToast(`${name} mis à jour ✓`+(pw?' — MDP: '+pw:''),'s');
  renderProfil();
  renderUsers();
}

async function deleteUserFromProfil(){
  const uid=document.getElementById('editUserSel').value;
  if(!uid)return;
  if(uid===CU.id){showToast('Vous ne pouvez pas supprimer votre propre compte','w');return;}
  const u=DB.users.find(x=>x.id===uid);
  if(!u||!confirm(`Supprimer l'accès de ${u.name} ?`))return;
  DB.users=DB.users.filter(x=>x.id!==uid);
  await saveDB();showToast(`${u.name} supprimé ✓`,'s');renderProfil();renderUsers();
}
async function changePw(){
  const p1=document.getElementById('newPw1').value;
  const p2=document.getElementById('newPw2').value;
  if(!p1||p1.length<6){showToast('Minimum 6 caractères','w');return;}
  if(p1!==p2){showToast('Les mots de passe ne correspondent pas','w');return;}
  const user=DB.users.find(u=>u.id===CU.id);if(!user)return;
  user.pw=p1;CU.pw=p1;sessionStorage.setItem('ilp_cu',JSON.stringify(CU));
  await saveDB();showToast('Mot de passe mis à jour ✓','s');
}

// ════════════════════════════════════════════════════════
// USERS (ADMIN)
// ════════════════════════════════════════════════════════
async function renderUsers(){
  if(!canDo('manageUsers')){
    document.getElementById('usersList').innerHTML=`<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Accès Administrateur uniquement</div></div>`;
    return;
  }
  document.getElementById('usersList').innerHTML=DB.users.map(u=>{
    const cmds=DB.commandes.filter(c=>c.createdBy===u.id).length;
    return`<div class="user-row">
      <div class="user-row-avatar">${ini(u.name)}</div>
      <div class="user-row-info">
        <div class="user-row-name">${u.name}</div>
        <div class="user-row-meta">${roleName(u.role)} · ${u.site} · ${cmds} commande(s)</div>
        <div style="margin-top:3px"><span class="role-badge ${roleClass(u.role)}">${roleName(u.role)}</span></div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px">
        <span class="user-row-id">${u.id}</span>
        ${u.id!==CU.id?`<button class="btn btn-danger btn-xs" onclick="deleteUser('${u.id}')">🗑 Supprimer</button>`:'<span style="font-size:10px;color:var(--or)">Vous</span>'}
      </div>
    </div>`;}).join('');
}

async function initNewUserForm(){
  document.getElementById('nu-nom').value='';
  document.getElementById('nu-pw').value='';
  document.getElementById('nu-id').value='';
  document.getElementById('nu-role').value='receptionniste';
  genId();
}
function genId(){
  const role=document.getElementById('nu-role').value;
  const prefix={admin:'ADM',gerant:'GER',receptionniste:'REC'}[role]||'USR';
  const existing=DB.users.filter(u=>u.id.startsWith(prefix)).length+1;
  document.getElementById('nu-id').value=prefix+String(existing).padStart(3,'0');
}
document.addEventListener('change', e=>{ if(e.target.id==='nu-role') genId(); });
async function genPw(){
  const chars='ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let pw='';for(let i=0;i<8;i++) pw+=chars[Math.floor(Math.random()*chars.length)];
  document.getElementById('nu-pw').value=pw;
}
async function saveUser(){
  const nom=document.getElementById('nu-nom').value.trim();
  const pw=document.getElementById('nu-pw').value;
  const id=document.getElementById('nu-id').value;
  if(!nom){showToast('Nom requis','w');return;}
  if(!pw||pw.length<6){showToast('Mot de passe: minimum 6 caractères','w');return;}
  if(DB.users.find(u=>u.id===id)){showToast('Cet ID existe déjà','w');return;}
  DB.users.push({id,name:nom,role:document.getElementById('nu-role').value,
    site:document.getElementById('nu-site').value,pw,since:new Date().toISOString()});
  await saveDB();closeModal('newUser');
  showToast(`Accès créé — ID: ${id} · MDP: ${pw}`, 's');
  renderUsers();
}
async function deleteUser(uid){
  if(!canDo('manageUsers'))return;
  const u=DB.users.find(x=>x.id===uid);if(!u)return;
  if(!confirm(`Supprimer l'accès de ${u.name} ?`))return;
  DB.users=DB.users.filter(x=>x.id!==uid);
  await saveDB();showToast('Utilisateur supprimé','s');renderUsers();
}

// ════════════════════════════════════════════════════════
// PARAMS / THÈME
// ════════════════════════════════════════════════════════
async function renderParams(){
  const cur=JSON.parse(localStorage.getItem('ilp_theme')||'null')||THEMES[0];
  const n=getCV('--noir')||'#060d1f';
  const c=getCV('--charbon')||'#0b1630';
  const s=getCV('--surface')||'#0f1e3a';
  const o=getCV('--or')||'#c9a84c';
  document.getElementById('paramsBody').innerHTML=`
    <div style="font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:var(--or);margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid var(--border)">🎨 Thèmes préréglés</div>
    <div class="theme-presets">
      ${THEMES.map((t,i)=>`
        <div class="theme-swatch ${cur.name===t.name?'active':''}" style="background:${t.c}" onclick="applyTheme(${i})">
          ${cur.name===t.name?'<div style="text-align:right;font-size:10px;color:var(--or)">✓</div>':''}
          <div class="theme-dots">
            <div class="theme-dot" style="background:${t.n}"></div>
            <div class="theme-dot" style="background:${t.s}"></div>
            <div class="theme-dot" style="background:${t.or}"></div>
          </div>
          <div class="theme-swatch-name">${t.icon} ${t.name}</div>
        </div>`).join('')}
    </div>
    <div style="font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:var(--or);margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border)">🖌 Personnaliser</div>
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:4px;padding:14px;margin-bottom:20px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        ${[{id:'p-n',lbl:'Fond principal',val:n},{id:'p-c',lbl:'Fond secondaire',val:c},{id:'p-s',lbl:'Surfaces/Cartes',val:s},{id:'p-o',lbl:'Couleur accent',val:o}].map(f=>`
          <div class="fg">
            <label class="fl">${f.lbl}</label>
            <div style="display:flex;gap:6px;align-items:center">
              <label style="cursor:pointer;position:relative">
                <input type="color" id="${f.id}-pick" value="${f.val}" oninput="livePrev('${f.id}',this.value);document.getElementById('${f.id}-hex').value=this.value" style="position:absolute;opacity:0;width:0;height:0">
                <div id="${f.id}-sw" style="width:36px;height:32px;border-radius:4px;background:${f.val};border:2px solid rgba(201,168,76,.3);cursor:pointer"></div>
              </label>
              <input class="fi" id="${f.id}-hex" value="${f.val}" oninput="onHex('${f.id}',this.value)" style="font-family:monospace;font-size:11px" maxlength="7" placeholder="#000000">
            </div>
          </div>`).join('')}
      </div>
      <div style="margin-top:12px;display:flex;gap:8px">
        <button class="btn btn-gold" onclick="applyCustom()" style="flex:1">✓ Appliquer</button>
        <button class="btn btn-ghost" onclick="applyTheme(0)">↺ Réinitialiser</button>
      </div>
    </div>
    <div style="font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:var(--or);margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid var(--border)">⚙ Système</div>
    <div class="stg-row"><div><div class="stg-lbl">Installer l'app (PWA)</div><div class="stg-sub">Ajouter à l'écran d'accueil</div></div><button class="btn btn-gold btn-sm" onclick="installPWA()">📲 Installer</button></div>
    <div class="stg-row"><div><div class="stg-lbl">Exporter les données (JSON)</div></div><button class="btn btn-outline btn-sm" onclick="exportData()">Exporter</button></div>
    ${CU.role==='admin'?`<div class="stg-row"><div><div class="stg-lbl">Réinitialiser (démo)</div></div><button class="btn btn-danger btn-sm" onclick="if(confirm('Effacer toutes les données ?')){initBlank();renderAll();showToast('Réinitialisé','s')}">Reset</button></div>`:''}
  `;
}

function getCV(v){ return rgbToHex(getComputedStyle(document.documentElement).getPropertyValue(v).trim())||''; }
function rgbToHex(rgb){ if(!rgb||rgb.startsWith('#'))return rgb||''; const m=rgb.match(/\d+/g); if(!m||m.length<3)return''; return'#'+[+m[0],+m[1],+m[2]].map(x=>Math.max(0,Math.min(255,x)).toString(16).padStart(2,'0')).join(''); }
function hexToRgb(h){ const c=(h||'').replace('#',''); if(c.length!==6)return{r:0,g:0,b:0}; return{r:parseInt(c.slice(0,2),16),g:parseInt(c.slice(2,4),16),b:parseInt(c.slice(4,6),16)}; }
function h2(r,g,b){ return'#'+[r,g,b].map(x=>Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join(''); }
async function lighten(h,a){ const c=hexToRgb(h); return h2(c.r+a,c.g+a,c.b+a); }
function darken(h,a){  const c=hexToRgb(h); return h2(c.r-a,c.g-a,c.b-a); }
function validHex(h){ return /^#[0-9a-fA-F]{6}$/.test((h||'').trim()); }

async function applyThemeObj(t){
  const r=document.documentElement.style;
  r.setProperty('--noir',t.n);r.setProperty('--charbon',t.c);r.setProperty('--surface',t.s);
  r.setProperty('--surface2',t.s2);r.setProperty('--surface3',t.s3);
  r.setProperty('--or',t.or);r.setProperty('--or-clair',t.oc);r.setProperty('--or-fonce',t.of);r.setProperty('--or-muted',t.om);
  const rgb=hexToRgb(t.or);
  r.setProperty('--border',`rgba(${rgb.r},${rgb.g},${rgb.b},.15)`);
  r.setProperty('--border-bright',`rgba(${rgb.r},${rgb.g},${rgb.b},.4)`);
  const mt=document.querySelector('meta[name="theme-color"]'); if(mt)mt.content=t.c;
  localStorage.setItem('ilp_theme',JSON.stringify(t));
  // Light theme body class
  if(t.name==='Clair Doré') document.body.classList.add('theme-light');
  else document.body.classList.remove('theme-light');
}
function applyTheme(i){ const t=THEMES[i]; if(!t)return; applyThemeObj(t); showToast(`Thème "${t.name}" ✓`,'s'); renderParams(); }
async function applyCustom(){
  const n=document.getElementById('p-n-hex')?.value.trim()||'#060d1f';
  const c=document.getElementById('p-c-hex')?.value.trim()||'#0b1630';
  const s=document.getElementById('p-s-hex')?.value.trim()||'#0f1e3a';
  const or=document.getElementById('p-o-hex')?.value.trim()||'#c9a84c';
  if(!validHex(n)||!validHex(c)||!validHex(s)||!validHex(or)){showToast('Code invalide — format #RRGGBB','w');return;}
  applyThemeObj({name:'Personnalisé',icon:'🎨',n,c,s,s2:lighten(s,6),s3:lighten(s,12),or,oc:lighten(or,18),of:darken(or,22),om:darken(or,38)});
  showToast('Thème personnalisé appliqué ✓','s'); renderParams();
}
function livePrev(id,val){
  const sw=document.getElementById(id+'-sw'); if(sw&&validHex(val)) sw.style.background=val;
}
async function onHex(id,val){
  const sw=document.getElementById(id+'-sw'),pi=document.getElementById(id+'-pick');
  if(validHex(val)){if(sw)sw.style.background=val;if(pi)pi.value=val;}
}
function loadTheme(){
  try{ const t=localStorage.getItem('ilp_theme'); if(t){const th=JSON.parse(t);applyThemeObj(th);} }catch(e){}
}

// ════════════════════════════════════════════════════════
// FACTURE / REÇU THERMIQUE
// ════════════════════════════════════════════════════════
async function buildDoc(cmdId, type){
  const cmd = DB.commandes.find(c=>c.id===cmdId); if(!cmd) return null;
  const client = gc(cmd.clientId);
  const items  = gi(cmdId);
  const total  = gTot(cmdId);
  const avance = cmd.avance||0;
  const reste  = Math.max(0, total-avance);
  const ps     = payStatus(cmd);
  const logo   = typeof LOGO_NOBG!=='undefined' ? LOGO_NOBG : (typeof LOGO_B64!=='undefined' ? LOGO_B64 : '');
  const isFacture = type === 'facture';
  const num    = isFacture ? `FAC-${cmd.id.split('-').pop()}` : `REC-${cmd.id.split('-').pop()}`;
  const dateStr = new Date().toLocaleDateString('fr-FR', {day:'2-digit', month:'2-digit', year:'numeric'});
  const timeStr = new Date().toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});

  // ── Ligne de séparation style thermique ──
  const sep  = '--------------------------------';
  const sep2 = '================================';

  // ── Lignes articles format thermique ──
  const rows = items.map(it => {
    const nom   = it.art.length > 18 ? it.art.substring(0,17)+'…' : it.art;
    const qte   = `x${it.qte}`;
    const pu    = `${it.prix.toLocaleString('fr-FR')}`;
    const ttl   = `${(it.prix*it.qte).toLocaleString('fr-FR')}`;
    return `<div class="trow">
      <span class="tnom">${nom}</span>
      <span class="tqpu">${qte} x ${pu}</span>
      <span class="tttl">${ttl}</span>
    </div>`;
  }).join('');

  // Statut paiement
  const statutColor = ps==='payé'?'#2a7a4e': ps==='partiellement payé'?'#c07030':'#d44b3a';
  const statutLabel = ps==='payé'?'✓ SOLDÉ' : ps==='partiellement payé'?'~ PARTIEL' : '✗ IMPAYÉ';

  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
<title>${isFacture?'Facture':'Reçu'} ${num}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');
  *{ margin:0; padding:0; box-sizing:border-box; }
  body{
    background: ${isFacture ? '#f0ece4' : '#e8e8e8'};
    min-height: 100vh;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 30px 10px;
    font-family: 'Share Tech Mono', 'Courier New', monospace;
  }
  /* ── Ticket wrapper ── */
  .ticket{
    background: #fff;
    width: 100%;
    max-width: ${isFacture ? '680px' : '320px'};
    padding: ${isFacture ? '40px 48px' : '22px 20px'};
    box-shadow: 0 4px 24px rgba(0,0,0,.18);
    position: relative;
    /* Effet bord dentelé haut et bas */
    ${!isFacture ? `
      border-top: none;
      background:
        radial-gradient(circle at 50% 0%, #e8e8e8 6px, #fff 6px),
        radial-gradient(circle at 50% 100%, #e8e8e8 6px, #fff 6px);
      background-size: 16px 12px, 16px 12px;
      background-repeat: repeat-x, repeat-x;
      background-position: 0 0, 0 100%;
      padding-top: 28px;
      padding-bottom: 28px;
    ` : ''}
  }

  /* ══════════════════════════════════
     TICKET THERMIQUE (reçu)
  ══════════════════════════════════ */
  .logo-img{ display:block; width:64px; height:64px; object-fit:contain; margin: 0 auto 4px; border-radius:50%; }
  .center{ text-align:center; }
  .shop-name{ font-size:15px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; color:#1a1a1a; }
  .shop-tag{  font-size:10px; color:#555; margin-top:1px; }
  .shop-tel{  font-size:10px; color:#444; margin-top:2px; }
  .shop-site{ font-size:9px;  color:#777; margin-top:1px; }
  .sep{  font-size:11px; color:#bbb; letter-spacing:.06em; margin: 7px 0; text-align:center; }
  .sep2{ font-size:11px; color:#555; letter-spacing:.06em; margin: 7px 0; text-align:center; }
  .doc-type{
    font-size:13px; font-weight:700; letter-spacing:.2em;
    text-align:center; text-transform:uppercase;
    color:#1a1a1a; margin:6px 0 2px;
  }
  .doc-num{ font-size:10px; text-align:center; color:#555; }
  .doc-date{ font-size:10px; text-align:center; color:#555; margin-bottom:4px; }
  .label-block{ font-size:10px; color:#666; margin:4px 0 1px; }
  .value-block{ font-size:11px; color:#111; font-weight:700; }

  /* Lignes articles */
  .thead-row{ display:flex; justify-content:space-between; font-size:10px; color:#666; margin:6px 0 2px; }
  .trow{
    display: grid;
    grid-template-columns: 1fr auto auto;
    gap: 4px;
    font-size: 11px;
    color: #111;
    padding: 3px 0;
    border-bottom: 1px dotted #ccc;
    align-items: baseline;
  }
  .tnom{ font-size:11px; }
  .tqpu{ font-size:10px; color:#555; white-space:nowrap; padding: 0 6px; }
  .tttl{ font-size:12px; font-weight:700; text-align:right; white-space:nowrap; }

  /* Totaux */
  .tot-row{ display:flex; justify-content:space-between; font-size:11px; color:#333; padding:3px 0; }
  .tot-row.big{
    font-size:14px; font-weight:700; color:#111;
    border-top:2px solid #1a1a1a;
    padding-top:6px; margin-top:3px;
  }
  .tot-row.vert{ color:#2a7a4e; }
  .tot-row.rouge{ color:#d44b3a; }

  /* Statut */
  .statut-box{
    text-align:center; font-size:12px; font-weight:700;
    letter-spacing:.12em; padding:6px;
    border:2px solid ${statutColor};
    color:${statutColor};
    margin:8px 0;
  }

  /* Footer */
  .merci{ text-align:center; font-size:11px; color:#444; margin-top:4px; font-style:italic; }
  .consigne{ text-align:center; font-size:9px; color:#888; margin-top:3px; }

  /* ══════════════════════════════════
     FACTURE (grand format)
  ══════════════════════════════════ */
  .fact-top{ display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:28px; padding-bottom:20px; border-bottom:3px solid #c9a84c; }
  .fact-logo{ width:68px; height:68px; object-fit:contain; border-radius:50%; }
  .fact-bname{ font-family:serif; font-size:20px; color:#8a6b28; }
  .fact-btag{ font-size:9px; letter-spacing:.2em; text-transform:uppercase; color:#8a8070; }
  .fact-dtype{ font-family:serif; font-size:36px; font-weight:300; color:#c9a84c; text-align:right; }
  .fact-dnum{ font-size:11px; color:#8a8070; text-align:right; margin-top:4px; }
  .fact-meta{ display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:24px; }
  .fact-mb{ background:#f8f5ee; border-left:3px solid #c9a84c; padding:12px 14px; font-family:sans-serif; }
  .fact-mt{ font-size:9px; letter-spacing:.18em; text-transform:uppercase; color:#8a6b28; font-weight:600; margin-bottom:7px; }
  .fact-mv{ font-size:13px; color:#1a1a1a; line-height:1.6; }
  .fact-ms{ font-size:11px; color:#8a8070; }
  .fact-table{ width:100%; border-collapse:collapse; margin-bottom:20px; font-family:sans-serif; }
  .fact-table thead{ background:#8a6b28; }
  .fact-table thead th{ color:#f5f0e8; padding:9px 12px; text-align:left; font-size:10px; letter-spacing:.1em; text-transform:uppercase; }
  .fact-table thead th:last-child, .fact-table thead th:nth-child(3){ text-align:right; }
  .fact-table tbody td{ padding:9px 12px; border-bottom:1px solid #e8e0d0; font-size:12px; }
  .fact-table tbody tr:nth-child(even){ background:#faf8f2; }
  .fact-tots{ display:flex; justify-content:flex-end; margin-bottom:22px; }
  .fact-tbox{ background:#f8f5ee; border:1px solid #e8e0d0; padding:16px 20px; min-width:240px; font-family:sans-serif; }
  .fact-trow{ display:flex; justify-content:space-between; gap:26px; padding:5px 0; font-size:12px; color:#555; }
  .fact-trow.big{ border-top:2px solid #c9a84c; margin-top:7px; padding-top:9px; font-size:20px; color:#8a6b28; font-family:serif; }
  .fact-trow.av .tv{ font-size:17px; color:#3a8a5c; font-family:serif; }
  .fact-trow.re .tv{ font-size:17px; color:#d44b3a; font-family:serif; }
  .fact-sbanner{ background:${statutColor}18; border:1px solid ${statutColor}40; border-radius:3px; padding:10px 14px; margin-bottom:20px; display:flex; align-items:center; gap:9px; font-family:sans-serif; }
  .fact-foot{ text-align:center; padding-top:18px; border-top:1px solid #e8e0d0; font-family:sans-serif; }

  /* Print */
  .pbtn{ position:fixed; bottom:22px; right:22px; background:linear-gradient(135deg,#555,#333); color:#fff; border:none; padding:11px 22px; font-family:monospace; font-size:12px; letter-spacing:.1em; cursor:pointer; border-radius:2px; box-shadow:0 4px 20px rgba(0,0,0,.3); z-index:999; }
  @media print{ .pbtn{display:none;} body{background:#fff;padding:0;} .ticket{box-shadow:none;} }
</style></head><body>

${isFacture ? `
<!-- ══════════════════════════════════
     FACTURE GRAND FORMAT
══════════════════════════════════ -->
<div class="ticket">
  <div class="fact-top">
    <div style="display:flex;align-items:center;gap:12px">
      <img class="fact-logo" src="${logo}" alt="ILP">
      <div>
        <div class="fact-bname">Ivoire Luxe Pressing</div>
        <div class="fact-btag">Bingerville &amp; Jacqueville · Côte d'Ivoire</div>
        <div style="font-family:serif;font-size:12px;color:#b89040;font-style:italic;margin-top:3px">Redorer l'éclat de votre linge</div>
      </div>
    </div>
    <div>
      <div class="fact-dtype">FACTURE</div>
      <div class="fact-dnum">N° ${num}</div>
      <div class="fact-dnum">${dateStr}</div>
    </div>
  </div>
  <div class="fact-meta">
    <div class="fact-mb">
      <div class="fact-mt">Établissement</div>
      <div class="fact-mv">Ivoire Luxe Pressing</div>
      <div class="fact-ms">Site : ${cmd.site}</div>
      <div class="fact-ms">📞 01 01 81 33 01 / 05 85 05 41 16</div>
      <div class="fact-ms">✉ ivoireluxe.pressing@gmail.com</div>
    </div>
    <div class="fact-mb">
      <div class="fact-mt">Client</div>
      <div class="fact-mv">${client.nom}</div>
      <div class="fact-ms">${client.tel||''}</div>
      <div class="fact-ms">${client.type||''} ${client.ville?'· '+client.ville:''}</div>
    </div>
  </div>
  <div class="fact-sbanner">
    <div style="width:8px;height:8px;border-radius:50%;background:${statutColor};flex-shrink:0"></div>
    <div><span style="color:${statutColor};font-weight:700;letter-spacing:.1em;font-size:11px">${ps.toUpperCase()}</span>
    <span style="color:#555;font-size:11px"> — ${cmd.id} · Enregistrée le ${fmtDT(cmd.dateEntree)}</span></div>
  </div>
  <table class="fact-table">
    <thead><tr><th>Article / Prestation</th><th>Qté</th><th style="text-align:right">Prix unit.</th><th style="text-align:right">Total</th></tr></thead>
    <tbody>${items.map(it=>`<tr><td>${it.art}</td><td>${it.qte}</td><td style="text-align:right">${it.prix.toLocaleString('fr-FR')}</td><td style="text-align:right;font-family:serif;font-size:15px;color:#8a6b28">${fmtM(it.prix*it.qte)}</td></tr>`).join('')}</tbody>
  </table>
  <div class="fact-tots"><div class="fact-tbox">
    <div class="fact-trow big"><span>Total</span><span>${fmtM(total)}</span></div>
    <div class="fact-trow av"><span>Avance versée</span><span class="tv">${fmtM(avance)}</span></div>
    <div class="fact-trow re"><span>Solde restant</span><span class="tv">${fmtM(reste)}</span></div>
  </div></div>
  <div class="fact-foot">
    <div style="font-family:serif;font-size:17px;color:#c9a84c;margin-bottom:5px">Merci pour votre confiance</div>
    <div style="font-size:10px;color:#8a8070;letter-spacing:.14em;text-transform:uppercase">Ivoire Luxe Pressing · Redorer l'éclat de votre linge</div>
    <div style="font-size:11px;color:#8a8070;margin-top:7px;line-height:1.8">Bingerville · Jacqueville · Côte d'Ivoire<br>📞 01 01 81 33 01 &nbsp;/&nbsp; 05 85 05 41 16 &nbsp;·&nbsp; ✉ ivoireluxe.pressing@gmail.com</div>
  </div>
</div>
` : `
<!-- ══════════════════════════════════
     REÇU THERMIQUE STYLE CAISSE
══════════════════════════════════ -->
<div class="ticket">

  <!-- En-tête -->
  ${logo ? `<img class="logo-img" src="${logo}" alt="ILP">` : ''}
  <div class="center shop-name">IVOIRE LUXE PRESSING</div>
  <div class="center shop-tag">Pressing · Blanchisserie · Repassage</div>
  <div class="center shop-tel">Tel: 01 01 81 33 01 / 05 85 05 41 16</div>
  <div class="center shop-site">${cmd.site} · Côte d'Ivoire</div>

  <div class="sep">${sep}</div>

  <!-- Type document -->
  <div class="doc-type">REÇU</div>
  <div class="doc-num">N° ${num}</div>
  <div class="doc-date">${dateStr}  ${timeStr}</div>

  <div class="sep">${sep}</div>

  <!-- Infos client & commande -->
  <div class="label-block">CLIENT</div>
  <div class="value-block">${client.nom}</div>
  ${client.tel ? `<div style="font-size:10px;color:#555">${client.tel}</div>` : ''}
  <div style="font-size:10px;color:#555;margin-top:2px">Cmd: ${cmd.id}</div>
  <div style="font-size:10px;color:#555">Enreg. le: ${fmtDT(cmd.dateEntree)}</div>

  <div class="sep">${sep}</div>

  <!-- Articles -->
  <div class="thead-row">
    <span>ARTICLE</span>
    <span style="padding:0 6px">QTE x PU</span>
    <span>TOTAL</span>
  </div>
  <div style="border-top:1px solid #aaa;margin-bottom:4px"></div>
  ${rows}

  <div style="border-top:1px solid #aaa;margin-top:4px"></div>

  <!-- Totaux -->
  <div class="tot-row big">
    <span>TOTAL</span>
    <span>${fmtM(total)}</span>
  </div>
  <div class="tot-row vert">
    <span>Avance versee</span>
    <span>${fmtM(avance)}</span>
  </div>
  ${reste > 0 ? `
  <div class="tot-row rouge">
    <span>Solde restant</span>
    <span>${fmtM(reste)}</span>
  </div>` : ''}

  <div class="sep2">${sep2}</div>

  <!-- Statut -->
  <div class="statut-box">${statutLabel}</div>

  <div class="sep">${sep}</div>

  <!-- Pied de ticket -->
  <div class="merci">Merci pour votre confiance !</div>
  <div class="consigne">Ramassage &amp; livraison gratuits des 20 articles</div>
  <div class="sep">${sep}</div>
  <div style="text-align:center;font-size:9px;color:#999;margin-top:2px">
    ** Conservez ce recu **<br>
    ivoireluxe.pressing@gmail.com
  </div>

</div>
`}

<button class="pbtn" onclick="window.print()">🖨 Imprimer</button>
</body></html>`;
}

async function genFacture(id){
  if(!canDo('genDocument')){showToast('🔒 Réservé Administrateur et Gérant','w');return;}
  const h=await buildDoc(id,'facture');if(!h)return;
  const w=window.open('','_blank');w.document.write(h);w.document.close();
  const _fcmd=DB.commandes.find(c=>c.id===id);
  addNotif('document',`Facture générée — ${id} (${_fcmd?gc(_fcmd.clientId).nom:''})`,{categorie:'documents',cmdId:id,clientId:_fcmd?.clientId,notifyManagers:true});await saveDB();
}
async function genRecu(id){
  if(!canDo('genRecu') && !canDo('genDocument')){showToast('🔒 Non autorisé','w');return;}
  const h=await buildDoc(id,'recu');if(!h)return;
  const w=window.open('','_blank');w.document.write(h);w.document.close();
  const _rcmd=DB.commandes.find(c=>c.id===id);
  addNotif('document',`Reçu généré — ${id} (${_rcmd?gc(_rcmd.clientId).nom:''})`,{categorie:'documents',cmdId:id,clientId:_rcmd?.clientId,notifyManagers:true});await saveDB();
}

async function sendWhatsApp(cmdId, docType){
  // Réceptionniste peut envoyer les reçus seulement
  if(docType==='facture' && !canDo('sendFactureWA')){
    showToast('🔒 Envoi facture WA réservé Admin et Gérant','w');return;
  }
  if(docType==='recu' && !canDo('sendRecuWA')){
    showToast('🔒 Non autorisé','w');return;
  }
  const cmd=DB.commandes.find(c=>c.id===cmdId);
  if(!cmd){showToast('Commande introuvable','w');return;}
  const client=gc(cmd.clientId);
  const total=gTot(cmdId);const reste=gRest(cmd);const ps=payStatus(cmd);
  let tel=(client.tel||'').replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  if(!tel){
    tel=prompt('Numéro WhatsApp du client '+client.nom+' (ex: 2250700000000):');
    if(!tel)return;
    tel=tel.replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  }
  const num=docType==='facture'?'FAC-'+cmd.id.split('-').pop():'TKT-'+cmd.id.split('-').pop();
  const items=gi(cmdId);
  const lines=items.map(it=>'  \u2022 '+it.art+' \u00d7 '+it.qte+' = '+fmtM(it.prix*it.qte)).join('\n');
  const msg=[
    '\uD83C\uDFF7 *IVOIRE LUXE PRESSING*',
    '_Redorer l\'\u00e9clat de votre linge_',
    '',
    '\uD83D\uDCC4 *'+(docType==='facture'?'FACTURE':'REÇU')+' N\u00b0 '+num+'*',
    '\uD83D\uDCCB Commande : '+cmd.id,
    '\uD83D\uDCCD Site : '+cmd.site,
    '',
    '\uD83D\uDC64 *Client :* '+client.nom,
    '',
    '\uD83E\uDDFA *D\u00e9tail :*',
    lines,
    '',
    '\uD83D\uDCB0 *Total :* '+fmtM(total),
    '\u2705 *Avanc\u00e9 :* '+fmtM(cmd.avance||0),
    (reste>0?'\u26A0\uFE0F *Reste \u00e0 payer :* '+fmtM(reste):'\u2705 *Sold\u00e9*'),
    '\uD83D\uDCCA Statut : '+ps.toUpperCase(),
    '',
    '\uD83D\uDCDE 01 01 81 33 01 / 05 85 05 41 16',
    '\u2709 ivoireluxe.pressing@gmail.com',
  ].join('\n');
  const url='https://wa.me/'+tel+'?text='+encodeURIComponent(msg);
  window.open(url,'_blank');
  const _wacmd2=DB.commandes.find(c=>c.id===cmdId);
  addNotif('document',(docType==='facture'?'Facture':'Reçu thermique')+' envoyé(e) WA — '+cmdId+' ('+gc(_wacmd2?.clientId||'').nom+')',{categorie:'documents',cmdId,clientId:_wacmd2?.clientId,notifyManagers:true});
  await saveDB();
  showToast('WhatsApp ouvert pour '+client.nom+' \uD83D\uDCAC','s');
}


// ════════════════════════════════════════════════════════
// PROSPECTS & RELANCES
// ════════════════════════════════════════════════════════

function uid_prospect(){ return 'PROS-'+Date.now().toString(36).toUpperCase(); }

function isRelanceDue(p){
  if(!p.nextRelance) return false;
  const due = new Date(p.nextRelance);
  return due <= new Date();
}

// ════════════════════════════════════════════════════════
// CHAT ÉQUIPE — Messagerie interne temps réel
// ════════════════════════════════════════════════════════
// ════════════════════════════════════════════════════════
// CHAT ÉQUIPE — Style WhatsApp, Supabase Postgres Changes
// ════════════════════════════════════════════════════════
let _chatChannel = null;
let _chatTypingTimer = null;

const ROLE_CHAT_COLORS = {
  admin:          {bg:'#1a3a1a', border:'#c9a84c', text:'#c9a84c',  label:'Admin'},
  gerant:         {bg:'#0e2a3a', border:'#7abce0', text:'#7abce0',  label:'Gérant'},
  receptionniste: {bg:'#0e2e1e', border:'#5ac888', text:'#5ac888',  label:'Récep.'},
};
const TYPE_ICO = {text:'', alert:'🚨', commandes:'📋'};

// ── Démarrer l'écoute Postgres Changes sur ilp_chat ──────
function _startChat(){
  if(!_supa || !CU || _chatChannel) return;
  _chatChannel = _supa
    .channel('chat-room')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'ilp_chat' },
      (payload) => {
        const msg = payload.new;
        if(!msg || !msg.id) return;
        // Éviter doublons
        if(DB.chat.find(m => m.id === msg.id)) return;
        // Normaliser readBy
        if(typeof msg.readBy === 'string') try { msg.readBy = JSON.parse(msg.readBy); } catch(e){ msg.readBy=[]; }
        if(!Array.isArray(msg.readBy)) msg.readBy = [];
        DB.chat.push(msg);
        // Son de notification si pas moi
        if(msg.fromId !== CU.id){
          updateBadges();
          if(curPage === 'chat'){
            _appendChatBubble(msg);
            _scrollChatBottom();
          } else {
            const col = ROLE_CHAT_COLORS[msg.fromRole] || ROLE_CHAT_COLORS.receptionniste;
            showToast('💬 ' + msg.fromName + ': ' + msg.msg.substring(0,50) + (msg.msg.length>50?'…':''), '');
          }
        }
      }
    )
    .subscribe((status, err) => {
      if(status === 'SUBSCRIBED') console.log('[ILP] Chat Realtime OK');
      if(status === 'CHANNEL_ERROR') console.error('[ILP] Chat error', err);
    });
}

function _stopChat(){
  if(_chatChannel){ _supa.removeChannel(_chatChannel); _chatChannel = null; }
}

// ── Envoyer un message ───────────────────────────────────
async function sendChatMsg(){
  const input  = document.getElementById('chatInput');
  const typeEl = document.getElementById('chatMsgType');
  const text   = input?.value.trim();
  if(!text || !CU) return;

  const msg = {
    id:       uid('MSG'),
    fromId:   CU.id,
    fromName: CU.name,
    fromRole: CU.role,
    fromSite: CU.site || '',
    msg:      text,
    type:     typeEl?.value || 'text',
    readBy:   JSON.stringify([CU.id]),
    createdAt: new Date().toISOString()
  };

  // Optimistic: ajouter localement immédiatement
  const localMsg = {...msg, readBy: [CU.id]};
  DB.chat.push(localMsg);
  _appendChatBubble(localMsg);
  _scrollChatBottom();

  // Reset saisie
  input.value = '';
  input.style.height = 'auto';
  if(typeEl) typeEl.value = 'text';

  // Insérer en base (déclenchera Realtime chez les autres)
  const {error} = await _supa.from('ilp_chat').insert(msg);
  if(error){
    console.error('[ILP] chat insert error:', error.message);
    showToast('Erreur envoi message','w');
    DB.chat = DB.chat.filter(m => m.id !== msg.id);
    renderChat();
  }
}

// ── Construire une bulle ─────────────────────────────────
function _buildBubble(m){
  const isMe = m.fromId === CU?.id;
  const col  = ROLE_CHAT_COLORS[m.fromRole] || ROLE_CHAT_COLORS.receptionniste;
  const ico  = TYPE_ICO[m.type] || '';
  const readBy = Array.isArray(m.readBy) ? m.readBy : [];
  const isRead = readBy.length > 1; // lu par quelqu'un d'autre

  const dt = new Date(m.createdAt);
  const timeStr = dt.toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});

  const msgText = _escHtml(m.msg);
  const ico_html = ico ? '<span style="margin-right:4px">'+ico+'</span>' : '';

  // Couleur bulle selon type
  let bubbleBg, bubbleBorder;
  if(isMe){
    bubbleBg     = m.type==='alert' ? 'linear-gradient(135deg,#5a1a0a,#7a2510)' : 'linear-gradient(135deg,#005c4b,#00796b)';
    bubbleBorder = m.type==='alert' ? 'rgba(212,75,58,.6)' : 'rgba(0,150,120,.4)';
  } else {
    bubbleBg     = m.type==='alert' ? 'linear-gradient(135deg,#3a0e0a,#5a1510)' : 'var(--surface2)';
    bubbleBorder = m.type==='alert' ? 'rgba(212,75,58,.4)' : 'var(--border)';
  }

  if(isMe){
    return `<div class="_chat-row" data-id="${m.id}" style="display:flex;flex-direction:column;align-items:flex-end;margin:1px 0 1px 48px">
      <div style="background:${bubbleBg};border:1px solid ${bubbleBorder};border-radius:16px 16px 3px 16px;padding:9px 13px 7px;max-width:78%;word-break:break-word;font-size:13px;color:#e8f0ff;line-height:1.5">
        ${ico_html}${msgText}
      </div>
      <div style="font-size:10px;color:var(--blanc-muted);margin-top:2px;display:flex;align-items:center;gap:4px">
        ${timeStr}
        <span style="color:${isRead?'#53bdeb':'var(--blanc-muted)'}">
          ${isRead ? '✓✓' : '✓'}
        </span>
      </div>
    </div>`;
  } else {
    const ini2 = m.fromName.split(' ').map(w=>w[0]).join('').substring(0,2).toUpperCase();
    return `<div class="_chat-row" data-id="${m.id}" style="display:flex;gap:8px;align-items:flex-end;margin:1px 48px 1px 0">
      <div style="width:32px;height:32px;border-radius:50%;background:${col.bg};border:2px solid ${col.border};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${col.text};flex-shrink:0">${ini2}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:10px;color:${col.text};margin-bottom:3px;font-weight:600">${m.fromName} · ${col.label}${m.fromSite?' · '+m.fromSite:''}</div>
        <div style="background:${bubbleBg};border:1px solid ${bubbleBorder};border-radius:3px 16px 16px 16px;padding:9px 13px 7px;max-width:100%;word-break:break-word;font-size:13px;color:var(--blanc);line-height:1.5">
          ${ico_html}${msgText}
        </div>
        <div style="font-size:10px;color:var(--blanc-muted);margin-top:2px">${timeStr}</div>
      </div>
    </div>`;
  }
}

// ── Ajouter une bulle sans tout re-render ────────────────
function _appendChatBubble(m){
  const box = document.getElementById('chatMessages');
  if(!box) return;
  // Vérifier séparateur de date
  const dt = new Date(m.createdAt);
  const dayKey = dt.toLocaleDateString('fr-FR');
  const lastSep = box.querySelector('[data-day]:last-of-type');
  if(!lastSep || lastSep.dataset.day !== dayKey){
    const today = new Date(); today.setHours(0,0,0,0);
    const yest  = new Date(today); yest.setDate(yest.getDate()-1);
    let label = dt>=today ? "Aujourd'hui" : dt>=yest ? "Hier" : dt.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    const sep = document.createElement('div');
    sep.dataset.day = dayKey;
    sep.style.cssText = 'text-align:center;margin:12px 0 8px;';
    sep.innerHTML = '<span style="font-size:10px;background:rgba(255,255,255,.06);color:var(--blanc-muted);padding:3px 12px;border-radius:10px;letter-spacing:.06em">'+label+'</span>';
    box.appendChild(sep);
  }
  const wrapper = document.createElement('div');
  wrapper.innerHTML = _buildBubble(m);
  box.appendChild(wrapper.firstChild);
}

function _scrollChatBottom(){
  const box = document.getElementById('chatMessages');
  if(box) setTimeout(()=>{ box.scrollTop = box.scrollHeight; }, 30);
}

// ── Render complet (chargement initial) ─────────────────
function renderChat(){
  const box = document.getElementById('chatMessages');
  if(!box) return;

  const filter = document.getElementById('chatFilter')?.value || '';
  const myId   = CU?.id || '';

  // Marquer comme lus côté local
  let changed = false;
  (DB.chat||[]).forEach(m => {
    if(!Array.isArray(m.readBy)) m.readBy = [];
    if(!m.readBy.includes(myId)){ m.readBy.push(myId); changed = true; }
  });
  if(changed) updateBadges();

  let msgs = [...(DB.chat||[])];
  if(filter) msgs = msgs.filter(m => m.type === filter);

  // Update sous-titre
  const onlineCount = Object.keys(_presenceState||{}).length + 1;
  const sub = document.getElementById('chatSub');
  if(sub) sub.textContent = (DB.chat||[]).length + ' message(s) · ' + onlineCount + ' membre(s) en ligne';

  // Présence dots
  const pd = document.getElementById('chatPresenceDots');
  if(pd){
    pd.innerHTML = Object.values(_presenceState||{}).map(u=>{
      const col = ROLE_CHAT_COLORS[u.userRole] || ROLE_CHAT_COLORS.receptionniste;
      const ini2 = u.userName.split(' ').map(w=>w[0]).join('').substring(0,2).toUpperCase();
      return '<div style="width:30px;height:30px;border-radius:50%;background:'+col.bg+';border:2px solid '+col.border+';display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:'+col.text+';position:relative;cursor:default" title="'+u.userName+' — en ligne">'+
        ini2+'<div style="position:absolute;bottom:-1px;right:-1px;width:9px;height:9px;border-radius:50%;background:#22c55e;border:2px solid var(--charbon);box-shadow:0 0 5px #22c55e88"></div></div>';
    }).join('');
  }

  if(!msgs.length){
    box.innerHTML = '<div style="text-align:center;color:var(--blanc-muted);padding:60px 20px;font-size:13px">💬<br><br>Aucun message<br><span style="font-size:11px;opacity:.6">Soyez le premier à écrire à l\'équipe !</span></div>';
    return;
  }

  // Construire tout le HTML
  box.innerHTML = '';
  let lastDay = '';
  msgs.forEach(m => {
    const dt = new Date(m.createdAt);
    const dayKey = dt.toLocaleDateString('fr-FR');
    const today = new Date(); today.setHours(0,0,0,0);
    const yest  = new Date(today); yest.setDate(yest.getDate()-1);
    let label = dt>=today ? "Aujourd'hui" : dt>=yest ? "Hier" : dt.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
    if(dayKey !== lastDay){
      const sep = document.createElement('div');
      sep.dataset.day = dayKey;
      sep.style.cssText = 'text-align:center;margin:12px 0 8px;';
      sep.innerHTML = '<span style="font-size:10px;background:rgba(255,255,255,.06);color:var(--blanc-muted);padding:3px 12px;border-radius:10px;letter-spacing:.06em">'+label+'</span>';
      box.appendChild(sep);
      lastDay = dayKey;
    }
    const wrapper = document.createElement('div');
    wrapper.innerHTML = _buildBubble(m);
    box.appendChild(wrapper.firstChild);
  });

  _scrollChatBottom();
}

function _escHtml(s){
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
}

// ════════════════════════════════════════════════════════
// PAGE RELANCE — Clients à relancer + Relances auto
// ════════════════════════════════════════════════════════
function renderRelance(){
  if(!canDo('viewRelances')){
    document.getElementById('relanceGrid').innerHTML='<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Accès restreint</div></div>';
    return;
  }
  const filter = document.getElementById('relanceFilter')?.value||'';
  let anciens = DB.clients.filter(c=>isClientAncien(c));
  if(filter==='inactif') anciens = DB.clients.filter(c=>{
    const cmds=DB.commandes.filter(cmd=>cmd.clientId===c.id);
    if(!cmds.length) return false;
    const last=cmds.reduce((a,b)=>new Date(a.dateEntree)>new Date(b.dateEntree)?a:b);
    return (Date.now()-new Date(last.dateEntree))/(1000*60*60*24)>14;
  });
  else if(filter==='jamais') anciens=DB.clients.filter(c=>DB.commandes.filter(cmd=>cmd.clientId===c.id).length===0);
  else if(filter==='programmee') anciens=[];

  document.getElementById('relanceCount').textContent=`${anciens.length} client(s) à relancer`;
  document.getElementById('relanceKpis').innerHTML=`
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('relanceFilter').value='';renderRelance()">
      <div class="kpi-ico">👥</div><div class="kpi-lbl">Total inactifs</div>
      <div class="kpi-val" style="color:#e8a030">${DB.clients.filter(c=>isClientAncien(c)).length}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('relanceFilter').value='jamais';renderRelance()">
      <div class="kpi-ico">🆕</div><div class="kpi-lbl">Jamais commandé</div>
      <div class="kpi-val">${DB.clients.filter(c=>DB.commandes.filter(cmd=>cmd.clientId===c.id).length===0).length}</div></div>
    <div class="kpi"><div class="kpi-ico">📅</div><div class="kpi-lbl">Relances auto</div>
      <div class="kpi-val" style="color:var(--vert)">${(DB.relancesAuto||[]).filter(r=>!r.sent).length}</div></div>
    <div class="kpi"><div class="kpi-ico">✅</div><div class="kpi-lbl">Envoyées</div>
      <div class="kpi-val">${(DB.relancesAuto||[]).filter(r=>r.sent).length}</div></div>`;

  // Relances auto programmées section
  const autoSec = document.getElementById('relancesAutoSection');
  if(autoSec && canDo('manageRelancesAuto')){
    const pending = (DB.relancesAuto||[]).filter(r=>!r.sent).sort((a,b)=>new Date(a.scheduledAt)-new Date(b.scheduledAt));
    if(pending.length>0){
      autoSec.innerHTML=`<div style="background:rgba(90,200,136,.06);border:1px solid rgba(90,200,136,.25);border-radius:var(--radius);padding:14px 16px;margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <div style="font-size:13px;color:var(--vert)">📅 ${pending.length} relance(s) automatique(s) programmée(s)</div>
          <button class="btn btn-sm" style="background:rgba(201,168,76,.12);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="openProgrammerRelance()">＋ Programmer</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          ${pending.slice(0,5).map(r=>{
            const cl=DB.clients.find(c=>c.id===r.clientId)||DB.prospects.find(p=>p.id===r.clientId)||{nom:'Inconnu'};
            const dt=new Date(r.scheduledAt);
            const isDue=dt<=new Date();
            const dtStr=dt.toLocaleString('fr-FR');
            const sendBtn=isDue&&cl.tel?'<button class="btn btn-xs" style="background:rgba(37,211,102,.15);color:#25D366;border:1px solid rgba(37,211,102,.3)" onclick="envoyerRelanceAuto(\''+r.id+'\')">💬 Envoyer</button>':'';
            return '<div style="background:var(--surface2);border-radius:5px;padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px">'+
              '<div><div style="font-size:12px;font-weight:600">'+cl.nom+'</div>'+
              '<div style="font-size:10px;color:'+(isDue?'var(--rouge)':'var(--blanc-muted)')+'">📅 '+dtStr+(isDue?' — ⚠ Due !':'')+'</div></div>'+
              '<div style="display:flex;gap:5px">'+sendBtn+
              '<button class="btn btn-xs" style="background:rgba(212,75,58,.1);color:var(--rouge);border:1px solid rgba(212,75,58,.3)" onclick="supprimerRelanceAuto(\''+r.id+'\')">🗑</button>'+
              '</div></div>';
          }).join('')}
          ${pending.length>5?`<div style="font-size:10px;color:var(--blanc-muted);text-align:center;padding:4px">… et ${pending.length-5} autre(s)</div>`:''}
        </div>
      </div>`;
    } else {
      autoSec.innerHTML=`<div style="display:flex;justify-content:flex-end;margin-bottom:12px">
        <button class="btn btn-sm" style="background:rgba(201,168,76,.12);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="openProgrammerRelance()">📅 Programmer une relance auto</button>
      </div>`;
    }
  }

  // Grid clients à relancer
  if(anciens.length===0){
    document.getElementById('relanceGrid').innerHTML=`<div class="empty" style="grid-column:1/-1"><div class="empty-ico">🎉</div><div class="empty-txt">Tous vos clients sont actifs !</div></div>`;
    return;
  }
  document.getElementById('relanceGrid').innerHTML=anciens.map(c=>{
    const cmds=DB.commandes.filter(cmd=>cmd.clientId===c.id);
    const last=cmds.length?cmds.reduce((a,b)=>new Date(a.dateEntree)>new Date(b.dateEntree)?a:b):null;
    const days=last?Math.floor((Date.now()-new Date(last.dateEntree))/(1000*60*60*24)):null;
    const ca=cmds.reduce((s,cmd)=>s+gTot(cmd.id),0);
    return`<div style="background:var(--surface);border:1px solid rgba(232,160,48,.25);border-radius:var(--radius);padding:14px;position:relative">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <div style="width:40px;height:40px;border-radius:50%;background:rgba(232,160,48,.1);color:#e8a030;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;flex-shrink:0">${ini(c.nom)}</div>
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${c.nom}</div>
          <div style="font-size:10px;color:var(--blanc-muted)">${c.tel||'Pas de tél'} · ${c.ville||'—'}</div>
        </div>
      </div>
      <div style="font-size:10px;color:#e8a030;margin-bottom:10px">
        ${days===null?'⚠ Jamais commandé':`⏱ Inactif depuis ${days} jour(s)`}
        ${cmds.length?`<span style="color:var(--blanc-muted);margin-left:8px">${cmds.length} cmd(s) · ${fmtM(ca)}</span>`:''}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        ${c.tel?`<button class="btn btn-sm" style="background:rgba(37,211,102,.12);color:#25D366;border:1px solid rgba(37,211,102,.3);flex:1" onclick="relancerClientWA('${c.id}',null)">💬 Relancer WA</button>`:'<span style="font-size:9px;color:var(--blanc-muted);padding:4px 8px">Pas de tél</span>'}
        ${canDo('manageRelancesAuto')?`<button class="btn btn-sm" style="background:rgba(201,168,76,.1);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="openProgrammerRelance('${c.id}')" title="Programmer relance auto">📅</button>`:''}
      </div>
    </div>`;
  }).join('');
}

function relancerTousWA(){
  if(!canDo('sendWhatsApp')){showToast('🔒 Non autorisé','w');return;}
  const anciens=DB.clients.filter(c=>isClientAncien(c)&&c.tel);
  if(!anciens.length){showToast('Aucun client inactif avec numéro','');return;}
  if(!confirm(`Ouvrir WhatsApp pour relancer ${anciens.length} client(s) ?`))return;
  // Open one by one with small delay to avoid browser blocking
  anciens.forEach((c,i)=>setTimeout(()=>relancerClientWA(c.id,null),i*300));
}

// ── Relances automatiques ──
function openProgrammerRelance(clientIdPrefill){
  const d=new Date(); d.setDate(d.getDate()+1); d.setHours(9,0,0,0);
  const dtStr=d.toISOString().slice(0,16);
  const modal=document.createElement('div');
  modal.id='_modalRelanceAuto';
  modal.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9100;display:flex;align-items:center;justify-content:center;padding:16px';
  const clientOpts=DB.clients.map(c=>`<option value="${c.id}" ${c.id===clientIdPrefill?'selected':''}>${c.nom}${c.tel?' ✓':' (pas de tél)'}</option>`).join('');
  modal.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:460px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:18px">📅 Programmer une relance automatique</div>
    <div class="fg" style="margin-bottom:12px"><label class="fl">Client</label>
      <select class="fi" id="_ral_client">${clientOpts}</select></div>
    <div class="fg" style="margin-bottom:12px"><label class="fl">Date & heure d'envoi</label>
      <input class="fi" type="datetime-local" id="_ral_dt" value="${dtStr}"></div>
    <div class="fg" style="margin-bottom:18px"><label class="fl">Message personnalisé (optionnel)</label>
      <textarea class="fi" id="_ral_msg" rows="3" placeholder="Laisser vide pour le message standard..." style="resize:vertical;min-height:60px"></textarea></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.getElementById('_modalRelanceAuto').remove()">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderRelanceAuto()">📅 Programmer</button>
    </div>
  </div>`;
  document.body.appendChild(modal);
}

async function sauvegarderRelanceAuto(){
  const clientId=document.getElementById('_ral_client')?.value;
  const dtStr=document.getElementById('_ral_dt')?.value;
  const msg=document.getElementById('_ral_msg')?.value.trim();
  if(!clientId||!dtStr){showToast('Données incomplètes','w');return;}
  const r={
    id:'RA-'+Date.now().toString(36).toUpperCase(),
    clientId, type:'client',
    message:msg||null,
    scheduledAt:new Date(dtStr).toISOString(),
    sent:false, createdBy:CU.id,
    createdAt:new Date().toISOString()
  };
  DB.relancesAuto=DB.relancesAuto||[];
  DB.relancesAuto.push(r);
  await saveDB();
  document.getElementById('_modalRelanceAuto')?.remove();
  showToast('Relance programmée pour '+new Date(dtStr).toLocaleString('fr-FR')+' ✓','s');
  renderRelance();
  // Schedule the check
  _scheduleRelanceCheck();
}

async function envoyerRelanceAuto(raId){
  const ra=(DB.relancesAuto||[]).find(r=>r.id===raId);
  if(!ra){showToast('Relance introuvable','w');return;}
  const client=DB.clients.find(c=>c.id===ra.clientId);
  if(!client||!client.tel){showToast('Client sans numéro de téléphone','w');return;}
  let tel=(client.tel||'').replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  const msg=ra.message||(
    '🏷 *IVOIRE LUXE PRESSING*\n_Redorer l\'éclat de votre linge_\n\n'+
    'Bonjour *'+client.nom+'*, nous pensons à vous ! 😊\n'+
    'Revenez nous confier votre linge — nous le traitons avec soin et élégance.\n\n'+
    '📞 01 01 81 33 01 / 05 85 05 41 16\n📍 Bingerville & Jacqueville · Côte d\'Ivoire'
  );
  window.open('https://wa.me/'+tel+'?text='+encodeURIComponent(msg),'_blank');
  ra.sent=true;
  ra.sentAt=new Date().toISOString();
  await saveDB();
  showToast('Relance envoyée à '+client.nom+' ✓','s');
  renderRelance();
}

async function supprimerRelanceAuto(raId){
  if(!confirm('Supprimer cette relance programmée ?'))return;
  DB.relancesAuto=(DB.relancesAuto||[]).filter(r=>r.id!==raId);
  await saveDB();
  showToast('Relance supprimée','s');
  renderRelance();
}

// ── Scheduler: vérifier les relances dues périodiquement ──
let _relanceCheckInterval=null;
function _scheduleRelanceCheck(){
  if(_relanceCheckInterval) clearInterval(_relanceCheckInterval);
  _relanceCheckInterval=setInterval(async()=>{
    const pending=(DB.relancesAuto||[]).filter(r=>!r.sent&&new Date(r.scheduledAt)<=new Date());
    if(!pending.length) return;
    // Notify
    pending.forEach(ra=>{
      const cl=DB.clients.find(c=>c.id===ra.clientId)||{nom:'Client'};
      addNotif('info','Relance due pour '+cl.nom+' — cliquez pour envoyer');
    });
    // Refresh badge
    updateBadges();
    renderRelance();
  }, 60000); // check every minute
}


// ════════════════════════════════════════════════════════
// PAGE BILAN MENSUEL — Admin seulement
// ════════════════════════════════════════════════════════
function initBilanPage(){
  // Populate year select
  const yearSel=document.getElementById('bilanAnnee');
  if(yearSel&&!yearSel.options.length){
    const y=new Date().getFullYear();
    for(let i=y;i>=y-3;i--){
      const o=document.createElement('option');
      o.value=i; o.textContent=i;
      yearSel.appendChild(o);
    }
  }
  // Default to current month
  const moisSel=document.getElementById('bilanMois');
  if(moisSel) moisSel.value=new Date().getMonth()+1;
  // Populate client filter
  const clientSel=document.getElementById('bilanClientFilter');
  if(clientSel){
    clientSel.innerHTML='<option value="">Tous les clients</option>'+
      DB.clients.map(c=>`<option value="${c.id}">${c.nom}</option>`).join('');
  }
}

function renderBilan(){
  if(!canDo('genBilan')){
    document.getElementById('bilanContent').innerHTML='<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Réservé Administrateur</div></div>';
    return;
  }
  const mois=+(document.getElementById('bilanMois')?.value||new Date().getMonth()+1);
  const annee=+(document.getElementById('bilanAnnee')?.value||new Date().getFullYear());
  const clientFlt=document.getElementById('bilanClientFilter')?.value||'';

  // Filter commandes for the selected month/year
  const cmdsMois=DB.commandes.filter(cmd=>{
    const d=new Date(cmd.dateEntree);
    return d.getMonth()+1===mois && d.getFullYear()===annee;
  });

  let clients=DB.clients;
  if(clientFlt) clients=clients.filter(c=>c.id===clientFlt);

  // Build per-client stats
  const bilanClients=clients.map(c=>{
    const cmds=cmdsMois.filter(cmd=>cmd.clientId===c.id);
    const totalCA=cmds.reduce((s,cmd)=>s+gTot(cmd.id),0);
    const totalEnc=cmds.reduce((s,cmd)=>s+(cmd.avance||0),0);
    const totalReste=cmds.reduce((s,cmd)=>s+gRest(cmd),0);
    return {c, cmds, totalCA, totalEnc, totalReste};
  }).filter(b=>b.cmds.length>0||clientFlt);

  const grandCA=bilanClients.reduce((s,b)=>s+b.totalCA,0);
  const grandEnc=bilanClients.reduce((s,b)=>s+b.totalEnc,0);
  const grandReste=bilanClients.reduce((s,b)=>s+b.totalReste,0);
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];

  document.getElementById('bilanSub').textContent=`${moisLabel} ${annee} · ${bilanClients.filter(b=>b.cmds.length).length} client(s) actif(s)`;
  document.getElementById('bilanKpis').innerHTML=`
    <div class="kpi"><div class="kpi-ico">💰</div><div class="kpi-lbl">CA du mois</div><div class="kpi-val sm">${fmtM(grandCA)}</div></div>
    <div class="kpi"><div class="kpi-ico">✅</div><div class="kpi-lbl">Encaissé</div><div class="kpi-val sm" style="color:var(--vert)">${fmtM(grandEnc)}</div></div>
    <div class="kpi"><div class="kpi-ico">⚠️</div><div class="kpi-lbl">Reste à recouvrer</div><div class="kpi-val sm" style="color:var(--rouge)">${fmtM(grandReste)}</div></div>
    <div class="kpi"><div class="kpi-ico">📦</div><div class="kpi-lbl">Commandes</div><div class="kpi-val">${cmdsMois.length}</div></div>`;

  if(!bilanClients.filter(b=>b.cmds.length).length){
    document.getElementById('bilanContent').innerHTML=`<div class="empty"><div class="empty-ico">📊</div><div class="empty-txt">Aucune commande en ${moisLabel} ${annee}</div></div>`;
    return;
  }

  document.getElementById('bilanContent').innerHTML=`
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
      <div style="font-size:11px;color:var(--blanc-muted)">Cliquez sur un client pour voir le détail et imprimer</div>
      <button class="btn btn-gold btn-sm" onclick="imprimerBilanGlobal(${mois},${annee})">🖨 Imprimer bilan global</button>
    </div>
    <div style="display:flex;flex-direction:column;gap:10px">
      ${bilanClients.filter(b=>b.cmds.length).map(b=>`
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;cursor:pointer;gap:12px" onclick="toggleBilanClient('bc-${b.c.id}')">
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:36px;height:36px;border-radius:50%;background:rgba(201,168,76,.1);color:var(--or-clair);display:flex;align-items:center;justify-content:center;font-weight:700">${ini(b.c.nom)}</div>
              <div>
                <div style="font-size:13px;font-weight:600">${b.c.nom}</div>
                <div style="font-size:10px;color:var(--blanc-muted)">${b.cmds.length} commande(s) · ${b.c.tel||'—'}</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:16px;flex-shrink:0">
              <div style="text-align:right">
                <div style="font-family:var(--f-d);font-size:18px;color:var(--or-clair)">${fmtM(b.totalCA)}</div>
                <div style="font-size:9px;color:${b.totalReste>0?'var(--rouge)':'var(--vert)'}">
                  ${b.totalReste>0?'Reste: '+fmtM(b.totalReste):'Soldé ✓'}</div>
              </div>
              <button class="btn btn-gold btn-sm" onclick="event.stopPropagation();imprimerBilanClient('${b.c.id}',${mois},${annee})">🖨 Relevé</button>
              ${b.c.tel?`<button class="btn btn-sm" style="background:rgba(37,211,102,.12);color:#25D366;border:1px solid rgba(37,211,102,.3)" onclick="event.stopPropagation();envoyerBilanWA('${b.c.id}',${mois},${annee})">💬 WA</button>`:''}
            </div>
          </div>
          <div id="bc-${b.c.id}" style="display:none;padding:0 16px 14px">
            <table style="width:100%;border-collapse:collapse;font-size:11px">
              <thead><tr style="border-bottom:1px solid var(--border)">
                <th style="text-align:left;padding:6px 0;color:var(--blanc-muted)">Commande</th>
                <th style="text-align:left;padding:6px 0;color:var(--blanc-muted)">Date</th>
                <th style="text-align:right;padding:6px 0;color:var(--blanc-muted)">Total</th>
                <th style="text-align:right;padding:6px 0;color:var(--blanc-muted)">Avancé</th>
                <th style="text-align:right;padding:6px 0;color:var(--blanc-muted)">Reste</th>
                <th style="padding:6px 0"></th>
              </tr></thead>
              <tbody>
                ${b.cmds.map(cmd=>`<tr style="border-bottom:1px solid rgba(255,255,255,.04)">
                  <td style="padding:5px 0;color:var(--or-clair);font-family:var(--f-d)">${cmd.id}</td>
                  <td style="padding:5px 0">${fmtD(cmd.dateEntree)}</td>
                  <td style="padding:5px 0;text-align:right;font-family:var(--f-d)">${fmtM(gTot(cmd.id))}</td>
                  <td style="padding:5px 0;text-align:right;color:var(--vert)">${fmtM(cmd.avance||0)}</td>
                  <td style="padding:5px 0;text-align:right;color:${gRest(cmd)>0?'var(--rouge)':'var(--vert)'}">${fmtM(gRest(cmd))}</td>
                  <td style="padding:5px 0;text-align:right">
                    <button class="btn btn-ghost btn-xs" onclick="genFacture('${cmd.id}')">📄</button>
                  </td>
                </tr>`).join('')}
              </tbody>
              <tfoot><tr style="border-top:2px solid var(--border)">
                <td colspan="2" style="padding:7px 0;font-weight:700;font-size:12px">TOTAL</td>
                <td style="padding:7px 0;text-align:right;font-family:var(--f-d);font-weight:700;color:var(--or-clair)">${fmtM(b.totalCA)}</td>
                <td style="padding:7px 0;text-align:right;color:var(--vert);font-weight:700">${fmtM(b.totalEnc)}</td>
                <td style="padding:7px 0;text-align:right;color:${b.totalReste>0?'var(--rouge)':'var(--vert)'};font-weight:700">${fmtM(b.totalReste)}</td>
                <td></td>
              </tr></tfoot>
            </table>
          </div>
        </div>`).join('')}
    </div>`;
}

function toggleBilanClient(id){
  const el=document.getElementById(id);
  if(el) el.style.display=el.style.display==='none'?'block':'none';
}

function imprimerBilanClient(clientId, mois, annee){
  const c=DB.clients.find(x=>x.id===clientId);if(!c)return;
  const cmdsMois=DB.commandes.filter(cmd=>{
    if(cmd.clientId!==clientId) return false;
    const d=new Date(cmd.dateEntree);
    return d.getMonth()+1===mois&&d.getFullYear()===annee;
  });
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];
  const totalCA=cmdsMois.reduce((s,cmd)=>s+gTot(cmd.id),0);
  const totalEnc=cmdsMois.reduce((s,cmd)=>s+(cmd.avance||0),0);
  const totalReste=cmdsMois.reduce((s,cmd)=>s+gRest(cmd),0);

  const rows=cmdsMois.map(cmd=>{
    const its=gi(cmd.id);
    return`<tr>
      <td style="padding:7px 8px;border-bottom:1px solid #eee;font-family:monospace;font-size:13px">${cmd.id}</td>
      <td style="padding:7px 8px;border-bottom:1px solid #eee">${new Date(cmd.dateEntree).toLocaleDateString('fr-FR')}</td>
      <td style="padding:7px 8px;border-bottom:1px solid #eee;font-size:11px">${its.map(i=>i.art+' ×'+i.qte).join(', ')||'—'}</td>
      <td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace">${gTot(cmd.id).toLocaleString('fr-FR')} FCFA</td>
      <td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:right;color:#2a8a4e;font-family:monospace">${(cmd.avance||0).toLocaleString('fr-FR')} FCFA</td>
      <td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:right;color:${gRest(cmd)>0?'#c0392b':'#2a8a4e'};font-family:monospace">${gRest(cmd).toLocaleString('fr-FR')} FCFA</td>
    </tr>`;
  }).join('');

  const html=`<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
  <title>Relevé ${moisLabel} ${annee} — ${c.nom}</title>
  <style>
    body{font-family:Georgia,serif;color:#1a1a1a;margin:0;padding:30px;background:#fff}
    .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:30px;border-bottom:3px solid #8a6b28;padding-bottom:16px}
    .logo-zone h1{font-size:22px;color:#8a6b28;margin:0 0 4px}
    .logo-zone p{font-size:11px;color:#666;margin:0}
    .doc-info{text-align:right;font-size:12px;color:#444}
    .doc-info h2{font-size:18px;color:#1a1a1a;margin:0 0 4px}
    .client-block{background:#f8f5ef;border-left:4px solid #8a6b28;padding:12px 16px;margin-bottom:24px;border-radius:0 6px 6px 0}
    table{width:100%;border-collapse:collapse;margin-bottom:20px}
    th{background:#8a6b28;color:#fff;padding:9px 8px;text-align:left;font-size:12px}
    th:last-child,th:nth-child(4),th:nth-child(5){text-align:right}
    tfoot td{font-weight:700;font-size:14px;padding:10px 8px;border-top:3px solid #8a6b28}
    .summary{background:#f8f5ef;border-radius:8px;padding:16px;display:flex;gap:30px;margin-top:20px}
    .sum-item{flex:1;text-align:center}
    .sum-item .label{font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.05em}
    .sum-item .value{font-size:20px;font-weight:700;color:#1a1a1a;font-family:monospace}
    .footer{margin-top:30px;border-top:1px solid #ccc;padding-top:12px;font-size:10px;color:#888;text-align:center}
    @media print{body{padding:15px}}
  </style></head><body>
  <div class="header">
    <div class="logo-zone">
      <h1>🏷 IVOIRE LUXE PRESSING</h1>
      <p>Redorer l'éclat de votre linge</p>
      <p>📞 01 01 81 33 01 / 05 85 05 41 16</p>
      <p>📍 Bingerville & Jacqueville · Côte d'Ivoire</p>
    </div>
    <div class="doc-info">
      <h2>RELEVÉ MENSUEL</h2>
      <div>${moisLabel.toUpperCase()} ${annee}</div>
      <div>Généré le ${new Date().toLocaleDateString('fr-FR')}</div>
    </div>
  </div>
  <div class="client-block">
    <strong style="font-size:16px">${c.nom}</strong>
    <div style="font-size:12px;color:#555;margin-top:4px">${c.tel||'—'} · ${c.email||'—'} · ${c.ville||'—'}</div>
  </div>
  <table>
    <thead><tr>
      <th>N° Commande</th><th>Date</th><th>Articles</th>
      <th style="text-align:right">Total</th><th style="text-align:right">Avancé</th><th style="text-align:right">Reste</th>
    </tr></thead>
    <tbody>${rows}</tbody>
    <tfoot><tr>
      <td colspan="3">TOTAUX DU MOIS</td>
      <td style="text-align:right;font-family:monospace">${totalCA.toLocaleString('fr-FR')} FCFA</td>
      <td style="text-align:right;font-family:monospace;color:#2a8a4e">${totalEnc.toLocaleString('fr-FR')} FCFA</td>
      <td style="text-align:right;font-family:monospace;color:${totalReste>0?'#c0392b':'#2a8a4e'}">${totalReste.toLocaleString('fr-FR')} FCFA</td>
    </tr></tfoot>
  </table>
  <div class="summary">
    <div class="sum-item"><div class="label">CA Total</div><div class="value">${totalCA.toLocaleString('fr-FR')} <span style="font-size:12px">FCFA</span></div></div>
    <div class="sum-item"><div class="label">Encaissé</div><div class="value" style="color:#2a8a4e">${totalEnc.toLocaleString('fr-FR')} <span style="font-size:12px">FCFA</span></div></div>
    <div class="sum-item"><div class="label">Reste à payer</div><div class="value" style="color:${totalReste>0?'#c0392b':'#2a8a4e'}">${totalReste.toLocaleString('fr-FR')} <span style="font-size:12px">FCFA</span></div></div>
  </div>
  <div class="footer">Ivoire Luxe Pressing · Document confidentiel · ${new Date().toLocaleDateString('fr-FR')}</div>
  <script>window.onload=()=>window.print();<\/script>
  </body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}

function imprimerBilanGlobal(mois, annee){
  const cmdsMois=DB.commandes.filter(cmd=>{
    const d=new Date(cmd.dateEntree);
    return d.getMonth()+1===mois&&d.getFullYear()===annee;
  });
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];

  const bilanClients=DB.clients.map(c=>{
    const cmds=cmdsMois.filter(cmd=>cmd.clientId===c.id);
    if(!cmds.length) return null;
    return {c, cmds, totalCA:cmds.reduce((s,cmd)=>s+gTot(cmd.id),0),
      totalEnc:cmds.reduce((s,cmd)=>s+(cmd.avance||0),0),
      totalReste:cmds.reduce((s,cmd)=>s+gRest(cmd),0)};
  }).filter(Boolean);

  const grandCA=bilanClients.reduce((s,b)=>s+b.totalCA,0);
  const grandEnc=bilanClients.reduce((s,b)=>s+b.totalEnc,0);
  const grandReste=bilanClients.reduce((s,b)=>s+b.totalReste,0);

  const rows=bilanClients.map(b=>`<tr>
    <td style="padding:8px;border-bottom:1px solid #eee">${b.c.nom}</td>
    <td style="padding:8px;border-bottom:1px solid #eee">${b.c.tel||'—'}</td>
    <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${b.cmds.length}</td>
    <td style="padding:8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace">${b.totalCA.toLocaleString('fr-FR')}</td>
    <td style="padding:8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace;color:#2a8a4e">${b.totalEnc.toLocaleString('fr-FR')}</td>
    <td style="padding:8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace;color:${b.totalReste>0?'#c0392b':'#2a8a4e'}">${b.totalReste.toLocaleString('fr-FR')}</td>
  </tr>`).join('');

  const html=`<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8">
  <title>Bilan Global ${moisLabel} ${annee}</title>
  <style>body{font-family:Georgia,serif;color:#1a1a1a;margin:0;padding:30px;background:#fff}
  .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:30px;border-bottom:3px solid #8a6b28;padding-bottom:16px}
  h1{font-size:22px;color:#8a6b28;margin:0 0 4px}
  table{width:100%;border-collapse:collapse}
  th{background:#8a6b28;color:#fff;padding:9px 8px;font-size:12px}
  th:nth-child(n+3){text-align:right}th:nth-child(3){text-align:center}
  tfoot td{font-weight:700;font-size:14px;padding:10px 8px;border-top:3px solid #8a6b28}
  .footer{margin-top:20px;border-top:1px solid #ccc;padding-top:10px;font-size:10px;color:#888;text-align:center}
  @media print{body{padding:15px}}</style></head><body>
  <div class="header">
    <div><h1>🏷 IVOIRE LUXE PRESSING</h1><p>Bilan mensuel — ${moisLabel.toUpperCase()} ${annee}</p></div>
    <div style="text-align:right;font-size:12px"><strong>BILAN GLOBAL</strong><br>Généré le ${new Date().toLocaleDateString('fr-FR')}<br>${bilanClients.length} client(s) actif(s)</div>
  </div>
  <table>
    <thead><tr><th>Client</th><th>Téléphone</th><th style="text-align:center">Cmds</th><th style="text-align:right">Total (FCFA)</th><th style="text-align:right">Encaissé (FCFA)</th><th style="text-align:right">Reste (FCFA)</th></tr></thead>
    <tbody>${rows}</tbody>
    <tfoot><tr>
      <td colspan="3">TOTAUX</td>
      <td style="text-align:right;font-family:monospace">${grandCA.toLocaleString('fr-FR')}</td>
      <td style="text-align:right;font-family:monospace;color:#2a8a4e">${grandEnc.toLocaleString('fr-FR')}</td>
      <td style="text-align:right;font-family:monospace;color:${grandReste>0?'#c0392b':'#2a8a4e'}">${grandReste.toLocaleString('fr-FR')}</td>
    </tr></tfoot>
  </table>
  <div class="footer">Ivoire Luxe Pressing · Document confidentiel · ${new Date().toLocaleDateString('fr-FR')}</div>
  <script>window.onload=()=>window.print();<\/script>
  </body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}

function envoyerBilanWA(clientId, mois, annee){
  const c=DB.clients.find(x=>x.id===clientId);if(!c||!c.tel)return;
  const cmdsMois=DB.commandes.filter(cmd=>{
    if(cmd.clientId!==clientId) return false;
    const d=new Date(cmd.dateEntree);
    return d.getMonth()+1===mois&&d.getFullYear()===annee;
  });
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];
  const totalCA=cmdsMois.reduce((s,cmd)=>s+gTot(cmd.id),0);
  const totalEnc=cmdsMois.reduce((s,cmd)=>s+(cmd.avance||0),0);
  const totalReste=cmdsMois.reduce((s,cmd)=>s+gRest(cmd),0);
  let tel=c.tel.replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  const lines=cmdsMois.map(cmd=>`  • ${cmd.id} — ${fmtM(gTot(cmd.id))}`).join('\n');
  const msg=[
    '🏷 *IVOIRE LUXE PRESSING*',
    '_Redorer l\'éclat de votre linge_',
    '',
    `📊 *RELEVÉ ${moisLabel.toUpperCase()} ${annee}*`,
    `👤 *Client :* ${c.nom}`,
    '',
    '📋 *Commandes du mois :*',
    lines||'  Aucune commande',
    '',
    `💰 *Total CA :* ${fmtM(totalCA)}`,
    `✅ *Encaissé :* ${fmtM(totalEnc)}`,
    totalReste>0?`⚠️ *Reste à payer :* ${fmtM(totalReste)}`:'✅ *Compte soldé*',
    '',
    '📞 01 01 81 33 01 / 05 85 05 41 16',
  ].join('\n');
  window.open('https://wa.me/'+tel+'?text='+encodeURIComponent(msg),'_blank');
  showToast('Relevé envoyé par WhatsApp à '+c.nom+' 💬','s');
}



// ════════════════════════════════════════════════════════
// STOCK LINGE CLIENT
// Colonnes Supabase: id, clientId, article, quantite, categorie,
//   description, statut, dateEntree, dateSortie, cmdId, createdBy, site, notes
// ════════════════════════════════════════════════════════

function renderStockLinge(){
  const q   = (document.getElementById('stockLingeSearch')?.value||'').toLowerCase();
  const sf  = document.getElementById('stockLingeFilter')?.value||'';
  const src = document.getElementById('stockLingeSource')?.value||''; // 'manuel'|'commandes'|''

  // ── Construire la liste unifiée depuis commandes + stock manuel ──────
  // 1) Articles issus des commandes (non livrées = toujours en pressing)
  const fromCommandes = [];
  DB.commandes.forEach(cmd => {
    if(cmd.statut === 'livré') return; // livré = parti du pressing
    const items = gi(cmd.id);
    items.forEach(it => {
      if(!it.qte || it.qte <= 0) return;
      // Mapper le statut commande → statut linge
      const statutMap = {
        'reçu':       'en_attente',
        'lavage':     'en_traitement',
        'séchage':    'en_traitement',
        'repassage':  'en_traitement',
        'prêt':       'pret',
        'livré':      'livre',
      };
      fromCommandes.push({
        id:        'CMD-'+cmd.id+'-'+it.id,   // ID virtuel stable
        clientId:  cmd.clientId,
        article:   it.art,
        quantite:  it.qte,
        statut:    statutMap[cmd.statut] || 'en_attente',
        dateEntree:cmd.dateEntree,
        cmdId:     cmd.id,
        site:      cmd.site,
        _source:   'commande',
        description: 'Cmd ' + cmd.id,
      });
    });
  });

  // 2) Entrées manuelles du stock linge
  const fromManuel = (DB.stockLinge||[]).map(l=>({...l, _source:'manuel'}));

  // 3) Fusionner : si un article d'une commande a déjà une entrée manuelle liée, ne pas dupliquer
  const linkedCmdIds = new Set(fromManuel.filter(l=>l.cmdId).map(l=>l.cmdId));
  const cmdsNonDupliques = fromCommandes.filter(l=>!linkedCmdIds.has(l.cmdId));

  let list = [...fromManuel, ...cmdsNonDupliques];

  // ── Filtres ──────────────────────────────────────────────────────────
  if(src === 'manuel')    list = list.filter(l=>l._source==='manuel');
  if(src === 'commandes') list = list.filter(l=>l._source==='commande');
  if(q)  list = list.filter(l=>(l.article+gc(l.clientId).nom+(l.description||'')).toLowerCase().includes(q));
  if(sf) list = list.filter(l=>l.statut===sf);

  // ── Tri alphabétique par client ──────────────────────────────────────
  list.sort((a,b)=>gc(a.clientId).nom.localeCompare(gc(b.clientId).nom,'fr',{sensitivity:'base'}));

  // ── Regroupement par client ──────────────────────────────────────────
  const byClient = {};
  list.forEach(l=>{
    if(!byClient[l.clientId]) byClient[l.clientId]=[];
    byClient[l.clientId].push(l);
  });

  // ── Totaux ──────────────────────────────────────────────────────────
  const totalPieces = list.reduce((s,l)=>s+(+l.quantite||0), 0);
  const enAttente   = list.filter(l=>l.statut==='en_attente').reduce((s,l)=>s+(+l.quantite||0),0);
  const enTrait     = list.filter(l=>l.statut==='en_traitement').reduce((s,l)=>s+(+l.quantite||0),0);
  const pret        = list.filter(l=>l.statut==='pret').reduce((s,l)=>s+(+l.quantite||0),0);
  const livre       = list.filter(l=>l.statut==='livre').reduce((s,l)=>s+(+l.quantite||0),0);
  const nbClients   = Object.keys(byClient).length;
  const total       = list.length; // nb de lignes (pour compatibilité)

  document.getElementById('stockLingeCount').textContent = `${totalPieces} pièce(s) · ${nbClients} client(s)`;
  document.getElementById('stockLingeKpis').innerHTML = `
    <div class="kpi"><div class="kpi-ico">🧺</div><div class="kpi-lbl">Total pièces</div><div class="kpi-val">${totalPieces}</div><div class="kpi-sub">${nbClients} client(s)</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('stockLingeFilter').value='en_attente';renderStockLinge()">
      <div class="kpi-ico">⏳</div><div class="kpi-lbl">En attente</div><div class="kpi-val" style="color:#e8a030">${enAttente}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('stockLingeFilter').value='en_traitement';renderStockLinge()">
      <div class="kpi-ico">⚙️</div><div class="kpi-lbl">En traitement</div><div class="kpi-val" style="color:#7abce0">${enTrait}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('stockLingeFilter').value='pret';renderStockLinge()">
      <div class="kpi-ico">✅</div><div class="kpi-lbl">Prêt</div><div class="kpi-val" style="color:var(--vert)">${pret}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('stockLingeFilter').value='livre';renderStockLinge()">
      <div class="kpi-ico">🚚</div><div class="kpi-lbl">Livré</div><div class="kpi-val" style="color:var(--blanc-muted)">${livre}</div></div>`;

  const statutBadge = {
    en_attente: '<span style="background:rgba(232,160,48,.18);color:#e8a030;padding:2px 8px;border-radius:10px;font-size:9px;letter-spacing:.06em">⏳ EN ATTENTE</span>',
    en_traitement: '<span style="background:rgba(122,188,224,.18);color:#7abce0;padding:2px 8px;border-radius:10px;font-size:9px;letter-spacing:.06em">⚙️ EN TRAITEMENT</span>',
    pret: '<span style="background:rgba(90,200,136,.18);color:var(--vert);padding:2px 8px;border-radius:10px;font-size:9px;letter-spacing:.06em">✅ PRÊT</span>',
    livre: '<span style="background:rgba(150,150,150,.15);color:var(--blanc-muted);padding:2px 8px;border-radius:10px;font-size:9px;letter-spacing:.06em">🚚 LIVRÉ</span>',
  };

  if(!Object.keys(byClient).length){
    document.getElementById('stockLingeGrid').innerHTML=`<div class="empty"><div class="empty-ico">🧺</div><div class="empty-txt">Aucun linge en stock</div><div class="empty-sub">Ajoutez le linge déposé par les clients</div></div>`;
    return;
  }

  document.getElementById('stockLingeGrid').innerHTML = Object.entries(byClient).sort((a,b)=>gc(a[0]).nom.localeCompare(gc(b[0]).nom,'fr',{sensitivity:'base'})).map(([cId, items])=>{
    const client = gc(cId);
    const totalPiecesClient = items.reduce((s,l)=>s+(+l.quantite||0),0);
    const nbCmds = [...new Set(items.filter(l=>l.cmdId).map(l=>l.cmdId))].length;
    return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);margin-bottom:12px;overflow:hidden">
      <div style="padding:12px 16px;background:var(--surface2);display:flex;align-items:center;justify-content:space-between;gap:10px">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="width:36px;height:36px;border-radius:50%;background:rgba(201,168,76,.1);color:var(--or-clair);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;flex-shrink:0">${ini(client.nom)}</div>
          <div>
            <div style="font-size:13px;font-weight:600">${client.nom}</div>
            <div style="font-size:10px;color:var(--blanc-muted)">${client.tel||'—'} · <strong style="color:var(--or-clair)">${totalPiecesClient} pièce(s)</strong>${nbCmds?' · '+nbCmds+' cmd(s)':''}</div>
          </div>
        </div>
        <button class="btn btn-gold btn-sm" onclick="openModalStockLinge('${cId}')">＋ Ajouter</button>
      </div>
      <div style="padding:10px 16px">
        ${items.map(l=>`
          <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)">
            <div style="flex:1;min-width:0">
              <div style="font-size:12px;font-weight:600">${l.article} <span style="color:var(--or-clair);font-weight:700">×${l.quantite}</span>
                ${l._source==='commande'?'<span style="font-size:9px;background:rgba(122,188,224,.15);color:#7abce0;padding:1px 6px;border-radius:8px;margin-left:4px">📋 CMD</span>':'<span style="font-size:9px;background:rgba(201,168,76,.12);color:var(--or-clair);padding:1px 6px;border-radius:8px;margin-left:4px">✏️ Manuel</span>'}
              </div>
              <div style="display:flex;gap:6px;align-items:center;margin-top:3px;flex-wrap:wrap">
                ${statutBadge[l.statut]||''}
                <span style="font-size:9px;color:var(--blanc-muted)">${fmtD(l.dateEntree)}</span>
                ${l.cmdId?`<span style="font-size:9px;color:#7abce0">→ ${l.cmdId}</span>`:''}
                ${l.description&&!l.cmdId?`<span style="font-size:9px;color:var(--blanc-muted)">${l.description}</span>`:''}
              </div>
            </div>
            <div style="display:flex;gap:4px;flex-shrink:0">
              ${l._source==='commande'
                ? `<button class="btn btn-xs" style="background:rgba(122,188,224,.1);color:#7abce0;border:1px solid rgba(122,188,224,.3)" onclick="openDetail('${l.cmdId}')" title="Voir la commande">📋</button>`
                : (l.statut!=='livre'?`<button class="btn btn-xs" style="background:rgba(201,168,76,.1);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="changerStatutLinge('${l.id}')">→</button>`:'')
              }
              ${l._source!=='commande'&&canDo('editClient')?`<button class="btn btn-xs" style="background:rgba(212,75,58,.1);color:var(--rouge);border:1px solid rgba(212,75,58,.3)" onclick="supprimerLinge('${l.id}')">🗑</button>`:''}
            </div>
          </div>`).join('')}
      </div>
    </div>`;
  }).join('');
}

function openModalStockLinge(clientIdPrefill){
  // Dynamic modal
  document.querySelectorAll('._modal_stk_linge').forEach(e=>e.remove());
  const m = document.createElement('div');
  m.className='_modal_stk_linge';
  m.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9200;display:flex;align-items:center;justify-content:center;padding:16px';
  const clientOpts = DB.clients.map(c=>`<option value="${c.id}" ${c.id===clientIdPrefill?'selected':''}>${c.nom}</option>`).join('');
  const articleOpts = DB.tarifs.flatMap(cat=>cat.items.map(it=>`<option value="${it.nom}">${it.nom}</option>`)).join('');
  m.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:460px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:16px">🧺 Enregistrer du linge</div>
    <div class="fg" style="margin-bottom:10px"><label class="fl">Client</label><select class="fi" id="_sl_client">${clientOpts}</select></div>
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Article</label>
        <input class="fi" list="_sl_articles" id="_sl_article" placeholder="ex: Chemise, Costume...">
        <datalist id="_sl_articles">${articleOpts}</datalist>
      </div>
      <div class="fg"><label class="fl">Quantité</label><input class="fi" type="number" id="_sl_qte" value="1" min="1"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Site</label>
        <select class="fi" id="_sl_site"><option>Bingerville</option><option>Jacqueville</option></select></div>
      <div class="fg"><label class="fl">Statut</label>
        <select class="fi" id="_sl_statut">
          <option value="en_attente">⏳ En attente</option>
          <option value="en_traitement">⚙️ En traitement</option>
          <option value="pret">✅ Prêt</option>
        </select></div>
    </div>
    <div class="fg" style="margin-bottom:16px"><label class="fl">Note (optionnel)</label><input class="fi" id="_sl_note" placeholder="Tache, couleur, instructions..."></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.querySelectorAll('._modal_stk_linge').forEach(e=>e.remove())">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderLinge()">💾 Enregistrer</button>
    </div>
  </div>`;
  document.body.appendChild(m);
  if(CU?.site) document.getElementById('_sl_site').value=CU.site;
}

async function sauvegarderLinge(){
  const clientId = document.getElementById('_sl_client')?.value;
  const article  = document.getElementById('_sl_article')?.value.trim();
  const qte      = +(document.getElementById('_sl_qte')?.value||1);
  const site     = document.getElementById('_sl_site')?.value||CU?.site||'Bingerville';
  const statut   = document.getElementById('_sl_statut')?.value||'en_attente';
  const note     = document.getElementById('_sl_note')?.value.trim();
  if(!clientId||!article){showToast('Client et article requis','w');return;}
  const rec = {
    id:uid('SL'), clientId, article, quantite:qte,
    categorie:'linge', description:note||null,
    statut, dateEntree:new Date().toISOString(),
    dateSortie:null, cmdId:null,
    createdBy:CU.id, site, notes:note||null
  };
  DB.stockLinge.push(rec);
  await saveDB();
  document.querySelectorAll('._modal_stk_linge').forEach(e=>e.remove());
  showToast(`${article} ×${qte} enregistré pour ${gc(clientId).nom} ✓`,'s');
  addNotif('info',`Linge enregistré — ${article} ×${qte} pour ${gc(clientId).nom}`,{categorie:'commandes',clientId,notifyManagers:true});
  renderStockLinge();
}

async function changerStatutLinge(id){
  const l=DB.stockLinge.find(x=>x.id===id); if(!l) return;
  const seq=['en_attente','en_traitement','pret','livre'];
  const ci=seq.indexOf(l.statut);
  const next=seq[ci+1];
  if(!next){showToast('Statut final : livré','');return;}
  l.statut=next;
  if(next==='livre') l.dateSortie=new Date().toISOString();
  await saveDB();
  showToast(`Linge → ${next.replace('_',' ')} ✓`,'s');
  addNotif('info',`Linge ${l.article} — ${gc(l.clientId).nom} → ${next.replace('_',' ')}`,{categorie:'commandes',clientId:l.clientId,notifyManagers:true});
  renderStockLinge();
}

async function supprimerLinge(id){
  if(!confirm('Supprimer cet enregistrement ?'))return;
  DB.stockLinge=DB.stockLinge.filter(x=>x.id!==id);
  await saveDB(); showToast('Supprimé','s'); renderStockLinge();
}


// ════════════════════════════════════════════════════════
// STOCK PRODUITS D'ENTRETIEN
// Colonnes: id, nom, categorie, unite, quantite, seuil_alerte,
//   prix_achat, fournisseur, description, lastUpdate, updatedBy
// Mouvements: id, produitId, type, quantite, motif, byUser, createdAt
// ════════════════════════════════════════════════════════

function renderStockProduits(){
  const cat = document.getElementById('stockProduitsFilter')?.value||'';
  let list = [...(DB.stockProduits||[])];
  if(cat) list = list.filter(p=>p.categorie===cat);
  list.sort((a,b)=>a.nom.localeCompare(b.nom,'fr'));

  const total = list.length;
  const alertes = list.filter(p=>p.quantite<=p.seuil_alerte).length;
  document.getElementById('stockProduitsCount').textContent=`${total} produit(s) · ${alertes>0?alertes+' alerte(s)':'stock OK'}`;

  // Alertes de stock bas
  const alertSec=document.getElementById('stockProduitsAlert');
  const bas=list.filter(p=>p.quantite<=p.seuil_alerte);
  if(alertSec&&bas.length){
    alertSec.innerHTML=`<div style="background:rgba(212,75,58,.08);border:1px solid rgba(212,75,58,.3);border-radius:var(--radius);padding:12px 16px">
      <div style="font-size:13px;color:var(--rouge);margin-bottom:6px">⚠️ ${bas.length} produit(s) en dessous du seuil d'alerte</div>
      <div style="font-size:11px;color:var(--blanc-muted)">${bas.map(p=>`<strong>${p.nom}</strong> (${p.quantite} ${p.unite})`).join(' · ')}</div>
    </div>`;
  } else if(alertSec){ alertSec.innerHTML=''; }

  const catIco={detergent:'🧼',assouplissant:'🌸',nettoyant:'✨',emballage:'📦',autre:'📋'};

  document.getElementById('stockProduitsGrid').innerHTML = list.map(p=>{
    const pct=p.seuil_alerte>0?Math.min(100,Math.round(p.quantite/Math.max(p.seuil_alerte*3,1)*100)):100;
    const barColor=p.quantite<=p.seuil_alerte?'var(--rouge)':p.quantite<=p.seuil_alerte*2?'#e8a030':'var(--vert)';
    return `<div style="background:var(--surface);border:1px solid ${p.quantite<=p.seuil_alerte?'rgba(212,75,58,.35)':'var(--border)'};border-radius:var(--radius);padding:14px;position:relative">
      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px">
        <div style="width:38px;height:38px;border-radius:8px;background:rgba(201,168,76,.08);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0">${catIco[p.categorie]||'📋'}</div>
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:600;margin-bottom:2px">${p.nom}</div>
          <div style="font-size:10px;color:var(--blanc-muted)">${p.categorie} · ${p.fournisseur||'—'}</div>
        </div>
        ${p.quantite<=p.seuil_alerte?'<div style="background:var(--rouge);color:#fff;font-size:8px;padding:2px 6px;border-radius:8px;letter-spacing:.06em;flex-shrink:0">⚠ BAS</div>':''}
      </div>
      <div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span style="font-size:11px;color:var(--blanc-muted)">Stock</span>
          <span style="font-family:var(--f-d);font-size:18px;color:${barColor}">${p.quantite} <span style="font-size:11px;color:var(--blanc-muted)">${p.unite}</span></span>
        </div>
        <div style="height:4px;background:rgba(255,255,255,.08);border-radius:2px;overflow:hidden">
          <div style="height:100%;background:${barColor};border-radius:2px;width:${pct}%;transition:width .4s"></div>
        </div>
        <div style="font-size:9px;color:var(--blanc-muted);margin-top:2px">Seuil alerte: ${p.seuil_alerte} ${p.unite}</div>
      </div>
      ${p.prix_achat?`<div style="font-size:10px;color:var(--blanc-muted);margin-bottom:8px">Prix: ${fmtM(p.prix_achat)}/${p.unite}</div>`:''}
      <div style="display:flex;gap:5px">
        <button class="btn btn-sm" style="flex:1;background:rgba(90,200,136,.12);color:var(--vert);border:1px solid rgba(90,200,136,.3)" onclick="openModalMouvement('${p.id}','entree')">＋ Entrée</button>
        <button class="btn btn-sm" style="flex:1;background:rgba(212,75,58,.1);color:var(--rouge);border:1px solid rgba(212,75,58,.25)" onclick="openModalMouvement('${p.id}','sortie')">− Sortie</button>
        ${canDo('editTarifs')?`<button class="btn btn-sm" style="background:rgba(201,168,76,.1);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="openModalProduit('${p.id}')">✏</button>`:''}
      </div>
    </div>`;
  }).join('')
  ||`<div class="empty" style="grid-column:1/-1"><div class="empty-ico">🧴</div><div class="empty-txt">Aucun produit</div><div class="empty-sub">Ajoutez vos produits d'entretien</div></div>`;

  // Journal des mouvements
  const mvts=[...(DB.stockMouvements||[])].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,20);
  const mvtEl=document.getElementById('stockMouvementsLog');
  if(mvtEl){
    mvtEl.innerHTML=mvts.map(mv=>{
      const p=DB.stockProduits.find(x=>x.id===mv.produitId)||{nom:'?',unite:''};
      return `<div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);align-items:center">
        <div style="width:22px;height:22px;border-radius:50%;background:${mv.type==='entree'?'rgba(90,200,136,.15)':'rgba(212,75,58,.12)'};display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">${mv.type==='entree'?'▲':'▼'}</div>
        <div style="flex:1">
          <div style="font-size:11px"><strong>${p.nom}</strong> — ${mv.type==='entree'?'Entrée':'Sortie'} de <strong>${mv.quantite} ${p.unite}</strong>${mv.motif?' · '+mv.motif:''}</div>
          <div style="font-size:9px;color:var(--blanc-muted)">${new Date(mv.createdAt).toLocaleDateString('fr-FR')} · par ${mv.byUser||'—'}</div>
        </div>
        <div style="font-size:14px;font-weight:700;color:${mv.type==='entree'?'var(--vert)':'var(--rouge)'};">${mv.type==='entree'?'+':'−'}${mv.quantite}</div>
      </div>`;
    }).join('')||'<div style="color:var(--blanc-muted);font-size:11px;padding:10px 0">Aucun mouvement enregistré</div>';
  }
}

function openModalProduit(produitId){
  const p = produitId ? DB.stockProduits.find(x=>x.id===produitId) : null;
  document.querySelectorAll('._modal_produit').forEach(e=>e.remove());
  const m = document.createElement('div');
  m.className='_modal_produit';
  m.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9200;display:flex;align-items:center;justify-content:center;padding:16px';
  m.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:480px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:16px">🧴 ${p?'Modifier':'Nouveau'} produit</div>
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Nom du produit</label><input class="fi" id="_sp_nom" value="${p?.nom||''}" placeholder="ex: Ariel, Comfort..."></div>
      <div class="fg"><label class="fl">Unité</label>
        <select class="fi" id="_sp_unite">
          ${['unité','litre','kg','rouleau','carton','sac'].map(u=>`<option ${(p?.unite||'unité')===u?'selected':''}>${u}</option>`).join('')}
        </select></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Catégorie</label>
        <select class="fi" id="_sp_cat">
          ${['detergent','assouplissant','nettoyant','emballage','autre'].map(c=>`<option value="${c}" ${(p?.categorie||'autre')===c?'selected':''}>${c}</option>`).join('')}
        </select></div>
      <div class="fg"><label class="fl">Stock actuel</label><input class="fi" type="number" id="_sp_qte" value="${p?.quantite||0}" min="0" step="0.5"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Seuil d'alerte</label><input class="fi" type="number" id="_sp_seuil" value="${p?.seuil_alerte||5}" min="0"></div>
      <div class="fg"><label class="fl">Prix d'achat (FCFA)</label><input class="fi" type="number" id="_sp_prix" value="${p?.prix_achat||0}" min="0"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      <div class="fg"><label class="fl">Fournisseur</label><input class="fi" id="_sp_fourn" value="${p?.fournisseur||''}" placeholder="Nom fournisseur"></div>
      <div class="fg"><label class="fl">Description</label><input class="fi" id="_sp_desc" value="${p?.description||''}" placeholder="Optionnel"></div>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.querySelectorAll('._modal_produit').forEach(e=>e.remove())">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderProduit('${produitId||''}')">💾 Enregistrer</button>
    </div>
  </div>`;
  document.body.appendChild(m);
}

async function sauvegarderProduit(id){
  const nom   = document.getElementById('_sp_nom')?.value.trim();
  if(!nom){showToast('Nom requis','w');return;}
  const rec = {
    id:id||uid('SP'), nom,
    categorie: document.getElementById('_sp_cat')?.value||'autre',
    unite: document.getElementById('_sp_unite')?.value||'unité',
    quantite: +(document.getElementById('_sp_qte')?.value||0),
    seuil_alerte: +(document.getElementById('_sp_seuil')?.value||5),
    prix_achat: +(document.getElementById('_sp_prix')?.value||0),
    fournisseur: document.getElementById('_sp_fourn')?.value.trim()||null,
    description: document.getElementById('_sp_desc')?.value.trim()||null,
    lastUpdate: new Date().toISOString(),
    updatedBy: CU.id
  };
  if(id){ const i=DB.stockProduits.findIndex(x=>x.id===id); if(i>=0) DB.stockProduits[i]=rec; }
  else DB.stockProduits.push(rec);
  await saveDB();
  document.querySelectorAll('._modal_produit').forEach(e=>e.remove());
  showToast(`${nom} enregistré ✓`,'s');
  renderStockProduits();
}

function openModalMouvement(produitId, typeDefaut){
  document.querySelectorAll('._modal_mouv').forEach(e=>e.remove());
  const m = document.createElement('div');
  m.className='_modal_mouv';
  m.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9200;display:flex;align-items:center;justify-content:center;padding:16px';
  const prodOpts=DB.stockProduits.map(p=>`<option value="${p.id}" ${p.id===produitId?'selected':''}>${p.nom} (${p.quantite} ${p.unite})</option>`).join('');
  m.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:400px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:16px">📦 Mouvement de stock</div>
    <div class="fg" style="margin-bottom:10px"><label class="fl">Produit</label><select class="fi" id="_mv_prod">${prodOpts}</select></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Type</label>
        <select class="fi" id="_mv_type">
          <option value="entree" ${typeDefaut==='entree'?'selected':''}>▲ Entrée (réception)</option>
          <option value="sortie" ${typeDefaut==='sortie'?'selected':''}>▼ Sortie (utilisation)</option>
        </select></div>
      <div class="fg"><label class="fl">Quantité</label><input class="fi" type="number" id="_mv_qte" value="1" min="0.1" step="0.5"></div>
    </div>
    <div class="fg" style="margin-bottom:16px"><label class="fl">Motif</label>
      <input class="fi" id="_mv_motif" placeholder="ex: Livraison fournisseur, lavage, nettoyage..."></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.querySelectorAll('._modal_mouv').forEach(e=>e.remove())">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderMouvement()">💾 Enregistrer</button>
    </div>
  </div>`;
  document.body.appendChild(m);
}

async function sauvegarderMouvement(){
  const produitId = document.getElementById('_mv_prod')?.value;
  const type      = document.getElementById('_mv_type')?.value||'entree';
  const qte       = +(document.getElementById('_mv_qte')?.value||1);
  const motif     = document.getElementById('_mv_motif')?.value.trim();
  if(!produitId||!qte){showToast('Données incomplètes','w');return;}
  const p=DB.stockProduits.find(x=>x.id===produitId);
  if(!p){showToast('Produit introuvable','w');return;}
  if(type==='sortie'&&p.quantite<qte){showToast(`Stock insuffisant (${p.quantite} ${p.unite})`, 'w');return;}
  const mv={id:uid('MV'),produitId,type,quantite:qte,motif:motif||null,createdBy:CU.id,createdAt:new Date().toISOString()};
  DB.stockMouvements.push(mv);
  p.quantite = type==='entree' ? p.quantite+qte : p.quantite-qte;
  p.lastUpdate=new Date().toISOString(); p.updatedBy=CU.id;
  await saveDB();
  document.querySelectorAll('._modal_mouv').forEach(e=>e.remove());
  showToast(`${type==='entree'?'+':'−'}${qte} ${p.unite} — ${p.nom} ✓`,'s');
  if(p.quantite<=p.seuil_alerte) addNotif('info',`⚠️ Stock bas — ${p.nom} : ${p.quantite} ${p.unite} restant(s)`,{categorie:'general',notifyManagers:true});
  renderStockProduits();
}


// ════════════════════════════════════════════════════════
// CHARGES
// Colonnes: id, libelle, montant, categorie, periodicite,
//   date_charge, site, paidBy, justificatif, createdBy, createdAt
// ════════════════════════════════════════════════════════

function renderCharges(){
  if(!canDo('genBilan')){
    document.getElementById('chargesContent').innerHTML='<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Réservé Administrateur</div></div>';
    return;
  }
  const periode = document.getElementById('chargesPeriode')?.value||'mois';
  const type    = document.getElementById('chargesType')?.value||'';

  const now=new Date(); const today=now.toISOString().slice(0,10);
  const firstDayWeek = new Date(now); firstDayWeek.setDate(now.getDate()-now.getDay());
  const firstDayMonth= new Date(now.getFullYear(),now.getMonth(),1).toISOString().slice(0,10);
  const firstDayWeekStr=firstDayWeek.toISOString().slice(0,10);

  let list=[...(DB.charges||[])];
  if(periode==='jour')   list=list.filter(c=>c.date_charge===today);
  else if(periode==='semaine') list=list.filter(c=>c.date_charge>=firstDayWeekStr&&c.date_charge<=today);
  else if(periode==='mois')    list=list.filter(c=>c.date_charge>=firstDayMonth&&c.date_charge<=today);
  if(type) list=list.filter(c=>c.periodicite===type);
  list.sort((a,b)=>b.date_charge.localeCompare(a.date_charge));

  const totalMois=list.reduce((s,c)=>s+c.montant,0);
  const allMois=[...(DB.charges||[])].filter(c=>c.date_charge>=firstDayMonth).reduce((s,c)=>s+c.montant,0);
  const allSemaine=[...(DB.charges||[])].filter(c=>c.date_charge>=firstDayWeekStr).reduce((s,c)=>s+c.montant,0);
  const allJour=[...(DB.charges||[])].filter(c=>c.date_charge===today).reduce((s,c)=>s+c.montant,0);

  document.getElementById('chargesSub').textContent=`${list.length} charge(s) · Total: ${fmtM(totalMois)}`;
  document.getElementById('chargesKpis').innerHTML=`
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('chargesPeriode').value='jour';renderCharges()">
      <div class="kpi-ico">📅</div><div class="kpi-lbl">Aujourd'hui</div><div class="kpi-val sm">${fmtM(allJour)}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('chargesPeriode').value='semaine';renderCharges()">
      <div class="kpi-ico">📆</div><div class="kpi-lbl">Cette semaine</div><div class="kpi-val sm">${fmtM(allSemaine)}</div></div>
    <div class="kpi" style="cursor:pointer" onclick="document.getElementById('chargesPeriode').value='mois';renderCharges()">
      <div class="kpi-ico">🗓️</div><div class="kpi-lbl">Ce mois</div><div class="kpi-val sm" style="color:var(--rouge)">${fmtM(allMois)}</div></div>
    <div class="kpi"><div class="kpi-ico">📋</div><div class="kpi-lbl">Filtre actif</div><div class="kpi-val sm">${fmtM(totalMois)}</div></div>`;

  const catIco={loyer:'🏠',electricite:'⚡',eau:'💧',salaires:'👥',transport:'🚗',fournitures:'📎',autre:'💸'};
  const perIco={journaliere:'📅',hebdo:'📆',mensuelle:'🗓️',ponctuelle:'⚡'};

  if(!list.length){
    document.getElementById('chargesContent').innerHTML=`<div class="empty"><div class="empty-ico">💸</div><div class="empty-txt">Aucune charge sur cette période</div></div>`;
    return;
  }

  // Group by type
  const byType={};
  list.forEach(c=>{
    const t=c.periodicite||'ponctuelle';
    if(!byType[t]) byType[t]=[];
    byType[t].push(c);
  });

  document.getElementById('chargesContent').innerHTML = `
    <div style="display:flex;justify-content:flex-end;margin-bottom:12px">
      <button class="btn btn-outline btn-sm" onclick="imprimerCharges(${JSON.stringify(periode)})">🖨 Imprimer</button>
    </div>
    ${Object.entries(byType).map(([tp,items])=>{
      const total=items.reduce((s,c)=>s+c.montant,0);
      return `<div style="margin-bottom:18px">
        <div style="font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--or);padding-bottom:6px;border-bottom:1px solid var(--border);margin-bottom:8px;display:flex;justify-content:space-between">
          <span>${perIco[tp]||'💸'} ${tp.toUpperCase()}</span>
          <span style="font-family:var(--f-d);color:var(--rouge)">${fmtM(total)}</span>
        </div>
        ${items.map(c=>`<div style="display:flex;gap:10px;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:6px;margin-bottom:6px;align-items:center">
          <div style="font-size:20px;flex-shrink:0">${catIco[c.categorie]||'💸'}</div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;font-weight:600">${c.libelle}</div>
            <div style="font-size:10px;color:var(--blanc-muted)">${c.date_charge} · ${c.site||'—'} · par ${c.paidBy||c.createdBy||'—'}</div>
            ${c.justificatif?`<div style="font-size:9px;color:var(--or-clair)">📎 ${c.justificatif}</div>`:''}
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-family:var(--f-d);font-size:18px;color:var(--rouge)">${fmtM(c.montant)}</div>
          </div>
          <button class="btn btn-xs" style="background:rgba(212,75,58,.1);color:var(--rouge);border:1px solid rgba(212,75,58,.3);flex-shrink:0" onclick="supprimerCharge('${c.id}')">🗑</button>
        </div>`).join('')}
      </div>`;
    }).join('')}`;
}

function openModalCharge(){
  document.querySelectorAll('._modal_charge').forEach(e=>e.remove());
  const m=document.createElement('div');
  m.className='_modal_charge';
  m.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9200;display:flex;align-items:center;justify-content:center;padding:16px';
  const today=new Date().toISOString().slice(0,10);
  m.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:480px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:16px">💸 Nouvelle charge</div>
    <div class="fg" style="margin-bottom:10px"><label class="fl">Libellé</label><input class="fi" id="_ch_lib" placeholder="ex: Loyer du mois, Facture EAU..."></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Montant (FCFA)</label><input class="fi" type="number" id="_ch_mnt" min="0" placeholder="0"></div>
      <div class="fg"><label class="fl">Date</label><input class="fi" type="date" id="_ch_date" value="${today}"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Périodicité</label>
        <select class="fi" id="_ch_per">
          <option value="journaliere">📅 Journalière</option>
          <option value="hebdo">📆 Hebdomadaire</option>
          <option value="mensuelle" selected>🗓️ Mensuelle</option>
          <option value="ponctuelle">⚡ Ponctuelle</option>
        </select></div>
      <div class="fg"><label class="fl">Catégorie</label>
        <select class="fi" id="_ch_cat">
          ${['loyer','electricite','eau','transport','fournitures','salaires','autre'].map(c=>`<option value="${c}">${c}</option>`).join('')}
        </select></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      <div class="fg"><label class="fl">Site</label>
        <select class="fi" id="_ch_site"><option>Bingerville</option><option>Jacqueville</option><option>Les deux</option></select></div>
      <div class="fg"><label class="fl">Justificatif (N° reçu…)</label><input class="fi" id="_ch_just" placeholder="Optionnel"></div>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.querySelectorAll('._modal_charge').forEach(e=>e.remove())">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderCharge()">💾 Enregistrer</button>
    </div>
  </div>`;
  document.body.appendChild(m);
  if(CU?.site) document.getElementById('_ch_site').value=CU.site;
}

async function sauvegarderCharge(){
  const libelle=document.getElementById('_ch_lib')?.value.trim();
  const montant=+(document.getElementById('_ch_mnt')?.value||0);
  if(!libelle||!montant){showToast('Libellé et montant requis','w');return;}
  const rec={
    id:uid('CH'), libelle, montant,
    categorie: document.getElementById('_ch_cat')?.value||'autre',
    periodicite: document.getElementById('_ch_per')?.value||'mensuelle',
    date_charge: document.getElementById('_ch_date')?.value||new Date().toISOString().slice(0,10),
    site: document.getElementById('_ch_site')?.value||'Bingerville',
    paidBy: CU.name,
    justificatif: document.getElementById('_ch_just')?.value.trim()||null,
    createdBy: CU.id,
    createdAt: new Date().toISOString()
  };
  DB.charges.push(rec);
  await saveDB();
  document.querySelectorAll('._modal_charge').forEach(e=>e.remove());
  showToast(`${libelle} — ${fmtM(montant)} enregistré ✓`,'s');
  renderCharges();
}

async function supprimerCharge(id){
  if(!confirm('Supprimer cette charge ?'))return;
  DB.charges=DB.charges.filter(x=>x.id!==id);
  await saveDB(); showToast('Charge supprimée','s'); renderCharges();
}

function imprimerCharges(periode){
  const now=new Date(); const today=now.toISOString().slice(0,10);
  const firstDayWeek=new Date(now); firstDayWeek.setDate(now.getDate()-now.getDay());
  const firstDayMonth=new Date(now.getFullYear(),now.getMonth(),1).toISOString().slice(0,10);
  const fw=firstDayWeek.toISOString().slice(0,10);
  let list=[...(DB.charges||[])];
  let titre='Toutes les charges';
  if(periode==='jour'){list=list.filter(c=>c.date_charge===today);titre="Charges du jour — "+today;}
  else if(periode==='semaine'){list=list.filter(c=>c.date_charge>=fw&&c.date_charge<=today);titre="Charges de la semaine";}
  else if(periode==='mois'){list=list.filter(c=>c.date_charge>=firstDayMonth&&c.date_charge<=today);titre="Charges du mois de "+['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][now.getMonth()]+" "+now.getFullYear();}
  list.sort((a,b)=>b.date_charge.localeCompare(a.date_charge));
  const total=list.reduce((s,c)=>s+c.montant,0);
  const rows=list.map(c=>`<tr><td style="padding:6px 8px;border-bottom:1px solid #eee">${c.date_charge}</td><td style="padding:6px 8px;border-bottom:1px solid #eee">${c.libelle}</td><td style="padding:6px 8px;border-bottom:1px solid #eee">${c.categorie}</td><td style="padding:6px 8px;border-bottom:1px solid #eee">${c.periodicite}</td><td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace">${c.montant.toLocaleString('fr-FR')} FCFA</td></tr>`).join('');
  const html=`<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>${titre}</title><style>body{font-family:Georgia,serif;padding:30px;color:#1a1a1a}.header{border-bottom:3px solid #8a6b28;padding-bottom:12px;margin-bottom:20px;display:flex;justify-content:space-between}h1{font-size:20px;color:#8a6b28;margin:0}table{width:100%;border-collapse:collapse}th{background:#8a6b28;color:#fff;padding:8px;text-align:left;font-size:12px}tfoot td{font-weight:700;border-top:3px solid #8a6b28;padding:8px}@media print{body{padding:15px}}</style></head><body>
  <div class="header"><div><h1>🏷 IVOIRE LUXE PRESSING</h1><p style="font-size:12px;color:#666;margin:4px 0">${titre}</p></div><div style="text-align:right;font-size:12px">Généré le ${new Date().toLocaleDateString('fr-FR')}</div></div>
  <table><thead><tr><th>Date</th><th>Libellé</th><th>Catégorie</th><th>Périodicité</th><th style="text-align:right">Montant</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><td colspan="4" style="padding:8px">TOTAL</td><td style="text-align:right;font-family:monospace;padding:8px">${total.toLocaleString('fr-FR')} FCFA</td></tr></tfoot></table>
  <script>window.onload=()=>window.print();<\/script></body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}


// ════════════════════════════════════════════════════════
// EMPLOYÉS & SALAIRES
// Colonnes employés: id, nom, prenom, poste, site, salaire_base,
//   telephone, email, date_embauche, statut, userId, notes, createdAt
// Colonnes salaires: id, employeId, mois, annee, montant, statut,
//   paidAt, paidBy, notes, createdAt
// ════════════════════════════════════════════════════════

function initEmployesPage(){
  const ySel=document.getElementById('employesAnnee');
  if(ySel&&!ySel.options.length){
    const y=new Date().getFullYear();
    for(let i=y;i>=y-3;i--){const o=document.createElement('option');o.value=i;o.textContent=i;ySel.appendChild(o);}
  }
  const mSel=document.getElementById('employesMois');
  if(mSel) mSel.value=new Date().getMonth()+1;
}

function renderEmployes(){
  if(!canDo('genBilan')){
    document.getElementById('employesContent').innerHTML='<div class="restricted"><div class="restricted-ico">🔒</div><div class="restricted-txt">Réservé Administrateur</div></div>';
    return;
  }
  const mois  = +(document.getElementById('employesMois')?.value||new Date().getMonth()+1);
  const annee = +(document.getElementById('employesAnnee')?.value||new Date().getFullYear());
  const list  = [...(DB.employes||[])].filter(e=>e.statut!=='inactif');

  const totalSalaires=list.reduce((s,e)=>s+e.salaire_base,0);
  const salMois=(DB.salaires||[]).filter(s=>s.mois===mois&&s.annee===annee);
  const totalPaye=salMois.reduce((s,sl)=>s+(sl.statut==='paye'?sl.montant:0),0);
  const totalRestant=totalSalaires-totalPaye;
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];

  document.getElementById('employesSub').textContent=`${list.length} employé(s) actif(s) · ${moisLabel} ${annee}`;
  document.getElementById('employesKpis').innerHTML=`
    <div class="kpi"><div class="kpi-ico">👥</div><div class="kpi-lbl">Effectif</div><div class="kpi-val">${list.length}</div></div>
    <div class="kpi"><div class="kpi-ico">💰</div><div class="kpi-lbl">Masse salariale</div><div class="kpi-val sm">${fmtM(totalSalaires)}</div></div>
    <div class="kpi"><div class="kpi-ico">✅</div><div class="kpi-lbl">Payé</div><div class="kpi-val sm" style="color:var(--vert)">${fmtM(totalPaye)}</div></div>
    <div class="kpi"><div class="kpi-ico">⏳</div><div class="kpi-lbl">Restant</div><div class="kpi-val sm" style="color:${totalRestant>0?'var(--rouge)':'var(--vert)'}">${fmtM(totalRestant)}</div></div>`;

  if(!list.length){
    document.getElementById('employesContent').innerHTML=`<div class="empty"><div class="empty-ico">👨‍💼</div><div class="empty-txt">Aucun employé actif</div><div class="empty-sub">Ajoutez vos employés pour gérer leurs salaires</div></div>`;
    return;
  }

  const statutEmpl={actif:'<span style="background:rgba(90,200,136,.15);color:var(--vert);padding:2px 8px;border-radius:10px;font-size:9px">ACTIF</span>',conge:'<span style="background:rgba(232,160,48,.15);color:#e8a030;padding:2px 8px;border-radius:10px;font-size:9px">CONGÉ</span>'};

  document.getElementById('employesContent').innerHTML=`
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-bottom:12px">
      <button class="btn btn-outline btn-sm" onclick="imprimerFichePaie(${mois},${annee})">🖨 Fiche de paie</button>
      <button class="btn btn-outline btn-sm" onclick="imprimerJournalSalaires(${mois},${annee})">🖨 Journal salaires</button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px">
      ${list.map(e=>{
        const sal=salMois.find(s=>s.employeId===e.id);
        const paye=sal?.statut==='paye';
        return `<div style="background:var(--surface);border:1px solid ${paye?'rgba(90,200,136,.3)':'var(--border)'};border-radius:var(--radius);padding:16px">
          <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:12px">
            <div style="width:42px;height:42px;border-radius:50%;background:rgba(201,168,76,.1);color:var(--or-clair);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:17px;flex-shrink:0">${ini(e.nom)}</div>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:700">${e.prenom||''} ${e.nom}</div>
              <div style="font-size:10px;color:var(--blanc-muted)">${e.poste||'—'} · ${e.site}</div>
              <div style="margin-top:4px">${statutEmpl[e.statut]||''}</div>
            </div>
            ${canDo('manageUsers')?`<button class="btn btn-xs" style="background:rgba(201,168,76,.1);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="openModalEmploye('${e.id}')">✏</button>`:''}
          </div>
          <div style="background:var(--surface2);border-radius:6px;padding:10px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:10px;color:var(--blanc-muted)">Salaire de base</span>
              <span style="font-family:var(--f-d);font-size:18px;color:var(--or-clair)">${fmtM(e.salaire_base)}</span>
            </div>
            <div style="font-size:10px;color:var(--blanc-muted)">${e.telephone||'—'} · Depuis ${e.date_embauche||'—'}</div>
          </div>
          <div style="margin-bottom:10px">
            <div style="font-size:10px;color:var(--blanc-muted);margin-bottom:4px">Salaire ${moisLabel} ${annee}</div>
            ${paye?`<div style="background:rgba(90,200,136,.08);border:1px solid rgba(90,200,136,.25);border-radius:6px;padding:8px 12px;display:flex;justify-content:space-between;align-items:center">
              <span style="font-size:11px;color:var(--vert)">✅ Payé — ${fmtM(sal.montant)}</span>
              <span style="font-size:9px;color:var(--blanc-muted)">${sal.paidAt?new Date(sal.paidAt).toLocaleDateString('fr-FR'):''}</span>
            </div>`:`<div style="background:rgba(212,75,58,.06);border:1px solid rgba(212,75,58,.2);border-radius:6px;padding:8px 12px">
              <span style="font-size:11px;color:var(--rouge)">⏳ Non payé — ${fmtM(sal?.montant||e.salaire_base)}</span>
            </div>`}
          </div>
          <div style="display:flex;gap:6px">
            ${!paye?`<button class="btn btn-sm" style="flex:1;background:rgba(90,200,136,.12);color:var(--vert);border:1px solid rgba(90,200,136,.3)" onclick="payerSalaire('${e.id}',${mois},${annee})">💳 Payer</button>`:''}
            ${canDo('manageUsers')?`<button class="btn btn-sm btn-danger btn-outline" onclick="archivEmploye('${e.id}')">Archiver</button>`:''}
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

function openModalEmploye(empId){
  const e=empId?DB.employes.find(x=>x.id===empId):null;
  document.querySelectorAll('._modal_empl').forEach(x=>x.remove());
  const m=document.createElement('div');
  m.className='_modal_empl';
  m.style.cssText='position:fixed;inset:0;background:rgba(6,13,31,.88);z-index:9200;display:flex;align-items:center;justify-content:center;padding:16px';
  m.innerHTML=`<div style="background:var(--surface);border:1px solid var(--border);border-radius:10px;max-width:500px;width:100%;padding:20px 24px">
    <div style="font-family:var(--f-d);font-size:16px;color:var(--or-clair);margin-bottom:16px">👨‍💼 ${e?'Modifier':'Nouvel'} employé</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Nom</label><input class="fi" id="_em_nom" value="${e?.nom||''}"></div>
      <div class="fg"><label class="fl">Prénom</label><input class="fi" id="_em_prenom" value="${e?.prenom||''}"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Poste</label><input class="fi" id="_em_poste" value="${e?.poste||''}" placeholder="ex: Lavandier, Repasseur..."></div>
      <div class="fg"><label class="fl">Site</label>
        <select class="fi" id="_em_site"><option ${(e?.site||'')==='Bingerville'?'selected':''}>Bingerville</option><option ${(e?.site||'')==='Jacqueville'?'selected':''}>Jacqueville</option><option ${(e?.site||'')==='Les deux'?'selected':''}>Les deux</option></select></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
      <div class="fg"><label class="fl">Téléphone</label><input class="fi" id="_em_tel" value="${e?.telephone||''}"></div>
      <div class="fg"><label class="fl">Date d'embauche</label><input class="fi" type="date" id="_em_date" value="${e?.date_embauche||''}"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px">
      <div class="fg"><label class="fl">Salaire de base (FCFA)</label><input class="fi" type="number" id="_em_sal" value="${e?.salaire_base||0}" min="0"></div>
      <div class="fg"><label class="fl">Statut</label>
        <select class="fi" id="_em_statut"><option value="actif" ${(e?.statut||'actif')==='actif'?'selected':''}>Actif</option><option value="conge" ${e?.statut==='conge'?'selected':''}>Congé</option></select></div>
    </div>
    <div class="fg" style="margin-bottom:16px"><label class="fl">Notes</label><input class="fi" id="_em_notes" value="${e?.notes||''}" placeholder="Optionnel"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end">
      <button class="btn btn-ghost" onclick="document.querySelectorAll('._modal_empl').forEach(x=>x.remove())">Annuler</button>
      <button class="btn btn-gold" onclick="sauvegarderEmploye('${empId||''}')">💾 Enregistrer</button>
    </div>
  </div>`;
  document.body.appendChild(m);
}

async function sauvegarderEmploye(id){
  const nom=document.getElementById('_em_nom')?.value.trim();
  if(!nom){showToast('Nom requis','w');return;}
  const rec={
    id:id||uid('EM'), nom,
    prenom:     document.getElementById('_em_prenom')?.value.trim()||null,
    poste:      document.getElementById('_em_poste')?.value.trim()||null,
    site:       document.getElementById('_em_site')?.value||'Bingerville',
    telephone:  document.getElementById('_em_tel')?.value.trim()||null,
    date_embauche: document.getElementById('_em_date')?.value||null,
    salaire_base: +(document.getElementById('_em_sal')?.value||0),
    statut:     document.getElementById('_em_statut')?.value||'actif',
    notes:      document.getElementById('_em_notes')?.value.trim()||null,
    createdBy:  CU.id, email:null, userId:null,
    createdAt:  new Date().toISOString()
  };
  if(id){const i=DB.employes.findIndex(x=>x.id===id);if(i>=0)DB.employes[i]=rec;}
  else DB.employes.push(rec);
  await saveDB();
  document.querySelectorAll('._modal_empl').forEach(x=>x.remove());
  showToast(`${rec.prenom||''} ${rec.nom} enregistré ✓`,'s');
  renderEmployes();
}

async function payerSalaire(employeId, mois, annee){
  const e=DB.employes.find(x=>x.id===employeId);if(!e)return;
  const montantDefaut=e.salaire_base;
  const m=prompt(`Salaire de ${e.prenom||''} ${e.nom} — Montant à verser (FCFA) :`, montantDefaut);
  if(!m||isNaN(+m))return;
  const existant=DB.salaires.find(s=>s.employeId===employeId&&s.mois===mois&&s.annee===annee);
  if(existant){
    existant.statut='paye'; existant.montant=+m;
    existant.paidAt=new Date().toISOString(); existant.paidBy=CU.name;
  } else {
    DB.salaires.push({
      id:uid('SAL'), employeId, mois, annee, montant:+m,
      statut:'paye', paidAt:new Date().toISOString(),
      paidBy:CU.name, notes:null, createdBy:CU.id,
      createdAt:new Date().toISOString()
    });
  }
  await saveDB();
  showToast(`${fmtM(+m)} versé à ${e.prenom||''} ${e.nom} ✓`,'s');
  addNotif('paiement',`Salaire ${['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1]} ${annee} — ${e.prenom||''} ${e.nom} : ${fmtM(+m)}`,{categorie:'paiements'});
  renderEmployes();
}

function ouvrirPaiementMasse(){
  const mois=+(document.getElementById('employesMois')?.value||new Date().getMonth()+1);
  const annee=+(document.getElementById('employesAnnee')?.value||new Date().getFullYear());
  const nonPayes=DB.employes.filter(e=>e.statut!=='inactif'&&!DB.salaires.find(s=>s.employeId===e.id&&s.mois===mois&&s.annee===annee&&s.statut==='paye'));
  if(!nonPayes.length){showToast('Tous les salaires ont été versés ce mois ✅','s');return;}
  if(!confirm(`Marquer ${nonPayes.length} salaire(s) comme payés avec le montant de base ?\n${nonPayes.map(e=>`${e.prenom||''} ${e.nom}: ${fmtM(e.salaire_base)}`).join('\n')}`))return;
  nonPayes.forEach(e=>{
    DB.salaires.push({
      id:uid('SAL'), employeId:e.id, mois, annee, montant:e.salaire_base,
      statut:'paye', paidAt:new Date().toISOString(), paidBy:CU.name,
      notes:'Paiement groupé', createdBy:CU.id, createdAt:new Date().toISOString()
    });
  });
  saveDB().then(()=>{showToast(`${nonPayes.length} salaires versés ✓`,'s');renderEmployes();});
}

async function archivEmploye(id){
  const e=DB.employes.find(x=>x.id===id);if(!e)return;
  if(!confirm(`Archiver ${e.prenom||''} ${e.nom} ?`))return;
  e.statut='inactif';
  await saveDB(); showToast('Employé archivé','s'); renderEmployes();
}

function imprimerJournalSalaires(mois,annee){
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];
  const list=DB.employes.filter(e=>e.statut!=='inactif');
  const salMois=(DB.salaires||[]).filter(s=>s.mois===mois&&s.annee===annee);
  const rows=list.map(e=>{
    const sal=salMois.find(s=>s.employeId===e.id);
    const paye=sal?.statut==='paye';
    return `<tr><td style="padding:7px 8px;border-bottom:1px solid #eee">${e.prenom||''} ${e.nom}</td><td style="padding:7px 8px;border-bottom:1px solid #eee">${e.poste||'—'}</td><td style="padding:7px 8px;border-bottom:1px solid #eee">${e.site}</td><td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace">${(e.salaire_base).toLocaleString('fr-FR')}</td><td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:right;font-family:monospace;color:${paye?'#2a8a4e':'#c0392b'}">${paye?'PAYÉ':'IMPAYÉ'}</td></tr>`;
  }).join('');
  const totalSal=list.reduce((s,e)=>s+e.salaire_base,0);
  const html=`<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Journal Salaires ${moisLabel} ${annee}</title><style>body{font-family:Georgia,serif;padding:30px;color:#1a1a1a}.hd{border-bottom:3px solid #8a6b28;padding-bottom:12px;margin-bottom:20px;display:flex;justify-content:space-between}h1{font-size:20px;color:#8a6b28;margin:0}table{width:100%;border-collapse:collapse}th{background:#8a6b28;color:#fff;padding:9px 8px;text-align:left;font-size:12px}th:last-child,th:nth-child(4){text-align:right}tfoot td{font-weight:700;border-top:3px solid #8a6b28;padding:9px 8px}@media print{body{padding:15px}}</style></head><body>
  <div class="hd"><div><h1>🏷 IVOIRE LUXE PRESSING</h1><p style="font-size:12px;color:#666;margin:4px 0">Journal des salaires — ${moisLabel.toUpperCase()} ${annee}</p></div><div style="text-align:right;font-size:12px">Généré le ${new Date().toLocaleDateString('fr-FR')}</div></div>
  <table><thead><tr><th>Nom</th><th>Poste</th><th>Site</th><th style="text-align:right">Salaire (FCFA)</th><th style="text-align:right">Statut</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><td colspan="3">MASSE SALARIALE</td><td style="text-align:right;font-family:monospace">${totalSal.toLocaleString('fr-FR')}</td><td></td></tr></tfoot></table>
  <script>window.onload=()=>window.print();<\/script></body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}

function imprimerFichePaie(mois, annee){
  const moisLabel=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'][mois-1];
  const list=DB.employes.filter(e=>e.statut!=='inactif');
  const fiches=list.map(e=>{
    const sal=(DB.salaires||[]).find(s=>s.employeId===e.id&&s.mois===mois&&s.annee===annee);
    return `<div style="page-break-inside:avoid;border:2px solid #8a6b28;border-radius:8px;padding:20px;margin-bottom:20px">
      <div style="display:flex;justify-content:space-between;border-bottom:1px solid #ccc;padding-bottom:10px;margin-bottom:12px">
        <div><strong style="font-size:16px">🏷 Ivoire Luxe Pressing</strong><br><small style="color:#666">${e.site}</small></div>
        <div style="text-align:right"><strong>BULLETIN DE PAIE</strong><br><small>${moisLabel} ${annee}</small></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div><strong>Employé :</strong> ${e.prenom||''} ${e.nom}<br><strong>Poste :</strong> ${e.poste||'—'}<br><strong>Site :</strong> ${e.site}</div>
        <div><strong>Date embauche :</strong> ${e.date_embauche||'—'}<br><strong>Tél :</strong> ${e.telephone||'—'}</div>
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:10px">
        <tr style="background:#f8f5ef"><td style="padding:6px 8px;font-weight:700">Salaire de base</td><td style="text-align:right;font-weight:700;font-family:monospace">${e.salaire_base.toLocaleString('fr-FR')} FCFA</td></tr>
      </table>
      <div style="display:flex;justify-content:space-between;border-top:2px solid #8a6b28;padding-top:8px">
        <strong>NET À PAYER</strong>
        <strong style="font-size:18px;font-family:monospace">${(sal?.montant||e.salaire_base).toLocaleString('fr-FR')} FCFA</strong>
      </div>
      <div style="font-size:10px;color:#888;margin-top:8px">Statut : ${sal?.statut==='paye'?'PAYÉ le '+new Date(sal.paidAt).toLocaleDateString('fr-FR'):'EN ATTENTE'}</div>
    </div>`;
  }).join('');
  const html=`<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Fiches de paie ${moisLabel} ${annee}</title><style>body{font-family:Georgia,serif;padding:20px;color:#1a1a1a}@media print{body{padding:10px}}</style></head><body>${fiches}<script>window.onload=()=>window.print();<\/script></body></html>`;
  const w=window.open('','_blank');w.document.write(html);w.document.close();
}

function isClientAncien(c){
  // Client sans commande depuis plus de 2 semaines
  const cmds = DB.commandes.filter(cmd=>cmd.clientId===c.id);
  if(cmds.length===0) return true; // jamais commandé
  const lastCmd = cmds.reduce((a,b)=>new Date(a.dateEntree)>new Date(b.dateEntree)?a:b);
  const daysSince = (Date.now()-new Date(lastCmd.dateEntree))/(1000*60*60*24);
  return daysSince > 14;
}

function renderProspects(){
  const sf = document.getElementById('prospectFilter')?.value||'';
  let list = [...DB.prospects];

  // Apply filter
  if(sf === 'relance_due'){
    list = list.filter(p=>isRelanceDue(p) && p.statut !== 'converti');
  } else if(sf){
    list = list.filter(p=>p.statut===sf);
  }

  // Sort: alphabétique par nom, puis relances dues en priorité
  list.sort((a,b)=>{
    const aDue = isRelanceDue(a)?0:1;
    const bDue = isRelanceDue(b)?0:1;
    if(aDue !== bDue) return aDue - bDue;
    return (a.nom||'').localeCompare(b.nom||'','fr',{sensitivity:'base'});
  });

  // Stats
  const total = DB.prospects.length;
  const due = DB.prospects.filter(p=>isRelanceDue(p) && p.statut!=='converti').length;
  const convertis = DB.prospects.filter(p=>p.statut==='converti').length;
  const clients_anciens = DB.clients.filter(c=>isClientAncien(c)).length;

  document.getElementById('prospectCount').textContent = `${list.length} prospect(s)`;
  document.getElementById('prospectKpis').innerHTML = `
    <div class="kpi"><div class="kpi-ico">🎯</div><div class="kpi-lbl">Total</div><div class="kpi-val">${total}</div></div>
    <div class="kpi" style="${due>0?'border-color:var(--rouge)':''}"><div class="kpi-ico">⚠️</div><div class="kpi-lbl">Relances dues</div><div class="kpi-val" style="color:${due>0?'var(--rouge)':'var(--or-clair)'}">${due}</div></div>
    <div class="kpi"><div class="kpi-ico">✅</div><div class="kpi-lbl">Convertis</div><div class="kpi-val" style="color:var(--vert)">${convertis}</div></div>
    <div class="kpi" style="${clients_anciens>0?'border-color:#e8a030':''}"><div class="kpi-ico">🔔</div><div class="kpi-lbl">Clients +2sem</div><div class="kpi-val" style="color:${clients_anciens>0?'#e8a030':'var(--or-clair)'}">${clients_anciens}</div></div>`;

  const statutColors = {
    'nouveau':'#7abce0','contacté':'#c9a84c','relancé':'#e8a030',
    'converti':'#5ac888','perdu':'#d44b3a'
  };

  document.getElementById('prospectsGrid').innerHTML = list.map(p => {
    const due = isRelanceDue(p);
    const cr = DB.users.find(u=>u.id===p.createdBy);
    const sc = statutColors[p.statut]||'#888';
    const dueStr = p.nextRelance ? new Date(p.nextRelance).toLocaleDateString('fr-FR') : '—';
    return `<div class="profile-card" style="${due?'border-color:var(--rouge);':''}" onclick="openProspect('${p.id}')">
      ${due?`<div style="position:absolute;top:6px;right:8px;background:var(--rouge);color:#fff;font-size:8px;padding:2px 6px;border-radius:10px;letter-spacing:.08em">⚠ RELANCE DUE</div>`:''}
      <div class="pc-avatar" style="background:${sc}22;color:${sc}">${ini(p.nom)}</div>
      <div class="pc-name">${p.nom}</div>
      <div class="pc-meta">${p.tel||'—'}</div>
      <div class="pc-meta">${p.ville||''} ${p.type?'· '+p.type:''}</div>
      <div style="margin-top:5px;display:flex;align-items:center;justify-content:space-between">
        <span style="font-size:9px;background:${sc}22;color:${sc};padding:2px 7px;border-radius:10px;letter-spacing:.06em">${p.statut.toUpperCase()}</span>
        <span style="font-size:9px;color:var(--blanc-muted)">📅 ${dueStr}</span>
      </div>
      <div style="margin-top:4px;font-size:9px;color:var(--blanc-muted)">
        Par: ${cr?cr.name:'—'} · Relances: ${p.relanceCount||0}
      </div>
      <div style="margin-top:8px;display:flex;gap:4px;flex-wrap:wrap">
        ${p.statut!=='converti'&&canDo('sendWhatsApp')?`<button class="btn btn-xs" style="background:rgba(37,211,102,.12);color:#25D366;border:1px solid rgba(37,211,102,.3)" onclick="event.stopPropagation();relanceProspectWA('${p.id}')">💬 Relancer</button>`:''}
        <button class="btn btn-xs" style="background:rgba(201,168,76,.1);color:var(--or-clair);border:1px solid rgba(201,168,76,.3)" onclick="event.stopPropagation();openProspect('${p.id}')">✏ Modifier</button>
        ${p.statut!=='converti'?`<button class="btn btn-xs" style="background:rgba(90,200,136,.1);color:var(--vert);border:1px solid rgba(90,200,136,.3)" onclick="event.stopPropagation();convertirProspectEnClient('${p.id}')">✓ Convertir</button>`:'<span style="font-size:9px;padding:2px 6px;background:rgba(90,200,136,.1);color:var(--vert);border-radius:10px">✓ Converti</span>'}
        ${canDo('deleteClient')?`<button class="btn btn-xs" style="background:rgba(212,75,58,.1);color:var(--rouge);border:1px solid rgba(212,75,58,.3)" onclick="event.stopPropagation();supprimerProspect('${p.id}')">🗑</button>`:''}
      </div>
    </div>`;
  }).join('')
  || `<div class="empty" style="grid-column:1/-1"><div class="empty-ico">🎯</div><div class="empty-txt">Aucun prospect</div><div class="empty-sub">Ajoutez des prospects à suivre</div></div>`;

  // Also show old clients section
  renderClientsAnciens();
}

function renderClientsAnciens(){
  // Already rendered in the kpis - clicking the card navigates
  // The kpi badge is enough for now
}

function openNewProspect(){
  document.getElementById('np-id').value='';
  document.getElementById('np-nom').value='';
  document.getElementById('np-tel').value='';
  document.getElementById('np-email').value='';
  document.getElementById('np-ville').value='';
  document.getElementById('np-type').value='particulier';
  document.getElementById('np-statut').value='nouveau';
  document.getElementById('np-notes').value='';
  // Set default nextRelance to 2 weeks from now
  const dt = new Date(); dt.setDate(dt.getDate()+14);
  document.getElementById('np-relance').value = dt.toISOString().split('T')[0];
  document.getElementById('newProspectTitle').textContent='Nouveau Prospect';
  openModal('newProspect');
}

function openProspect(id){
  const p = DB.prospects.find(x=>x.id===id);
  if(!p) return;
  document.getElementById('np-id').value=p.id;
  document.getElementById('np-nom').value=p.nom;
  document.getElementById('np-tel').value=p.tel||'';
  document.getElementById('np-email').value=p.email||'';
  document.getElementById('np-ville').value=p.ville||'';
  document.getElementById('np-type').value=p.type||'particulier';
  document.getElementById('np-statut').value=p.statut||'nouveau';
  document.getElementById('np-notes').value=p.notes||'';
  document.getElementById('np-relance').value=p.nextRelance?new Date(p.nextRelance).toISOString().split('T')[0]:'';
  document.getElementById('newProspectTitle').textContent='Modifier Prospect';
  openModal('newProspect');
}

async function saveProspect(){
  const nom = document.getElementById('np-nom').value.trim();
  if(!nom){showToast('Nom requis','w');return;}
  const existingId = document.getElementById('np-id').value;
  const relDate = document.getElementById('np-relance').value;
  if(existingId){
    // Update
    const p = DB.prospects.find(x=>x.id===existingId);
    if(!p)return;
    p.nom = nom;
    p.tel = document.getElementById('np-tel').value;
    p.email = document.getElementById('np-email').value;
    p.ville = document.getElementById('np-ville').value;
    p.type = document.getElementById('np-type').value;
    p.notes = document.getElementById('np-notes').value;
    p.statut = document.getElementById('np-statut').value;
    p.nextRelance = relDate?new Date(relDate).toISOString():null;
    showToast(`${nom} mis à jour ✓`,'s');
  } else {
    // New
    const id = uid_prospect();
    DB.prospects.push({
      id, nom,
      tel: document.getElementById('np-tel').value,
      email: document.getElementById('np-email').value,
      ville: document.getElementById('np-ville').value,
      type: document.getElementById('np-type').value,
      notes: document.getElementById('np-notes').value,
      statut: document.getElementById('np-statut').value,
      createdBy: CU.id,
      createdAt: new Date().toISOString(),
      nextRelance: relDate?new Date(relDate).toISOString():null,
      relanceCount: 0,
    });
    addNotif('info',`Prospect ${nom} ajouté par ${CU.name}`);
    showToast(`${nom} enregistré ✓`,'s');
  }
  await saveDB();
  closeModal('newProspect');
  renderProspects();
}

async function relanceProspectWA(id){
  if(!canDo('sendWhatsApp')){showToast('🔒 Réservé Administrateur et Gérant','w');return;}
  const p = DB.prospects.find(x=>x.id===id);
  if(!p){showToast('Prospect introuvable','w');return;}
  let tel=(p.tel||'').replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  if(!tel){
    tel = prompt('Numéro WhatsApp de '+p.nom+' (ex: 2250700000000):');
    if(!tel) return;
    tel=tel.replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  }
  const msg = [
    '\uD83C\uDFF7 *IVOIRE LUXE PRESSING*',
    '_Redorer l\'\u00e9clat de votre linge_',
    '',
    'Bonjour *'+p.nom+'*,',
    '',
    'Nous vous contactons pour vous rappeler nos services de pressing haut de gamme.',
    '',
    '\uD83D\uDC54 Linge de maison, v\u00eatements, hôtellerie',
    '\uD83D\uDCCD Sites : Bingerville &amp; Jacqueville',
    '\uD83D\uDCDE 01 01 81 33 01 / 05 85 05 41 16',
    '\u2709 ivoireluxe.pressing@gmail.com',
    '',
    'Nous sommes \u00e0 votre service ! \uD83E\uDE84',
  ].join('\n');
  const url='https://wa.me/'+tel+'?text='+encodeURIComponent(msg);
  window.open(url,'_blank');
  // Update prospect
  p.statut='relancé';
  p.lastRelance=new Date().toISOString();
  p.relanceCount=(p.relanceCount||0)+1;
  // Set next relance to 2 weeks
  const next=new Date(); next.setDate(next.getDate()+14);
  p.nextRelance=next.toISOString();
  addNotif('info',`Relance WhatsApp envoyée à ${p.nom}`);
  await saveDB();
  renderProspects();
  showToast('Relance envoyée à '+p.nom+' 💬','s');
}

async function relancerClientsAnciens(){
  // Get all clients with no order in last 14 days
  if(!canDo('viewRelances')){showToast('🔒 Accès non autorisé','w');return;}
  const anciens = DB.clients.filter(c=>isClientAncien(c));
  if(anciens.length===0){showToast('Aucun client inactif depuis +2 semaines','');return;}
  const client = anciens[0]; // Send to first one, user can navigate
  let tel=(client.tel||'').replace(/\s+/g,'').replace(/^\+/,'').replace(/^00/,'');
  if(!tel){showToast('Pas de téléphone pour '+client.nom,'w');return;}
  const msg = [
    '\uD83C\uDFF7 *IVOIRE LUXE PRESSING*',
    '_Redorer l\'\u00e9clat de votre linge_',
    '',
    'Bonjour *'+client.nom+'*,',
    '',
    'Nous avons remarqu\u00e9 que vous ne nous avez pas rendu visite depuis un moment !',
    '\uD83D\uDC54 Votre linge m\u00e9rite le meilleur soin.',
    '',
    'Revenez nous voir \u00e0 *Ivoire Luxe Pressing* —',
    'nous vous pr\u00e9parons votre linge avec soin et \u00e9l\u00e9gance.',
    '',
    '\uD83D\uDCDE 01 01 81 33 01 / 05 85 05 41 16',
    '\uD83D\uDCCD Bingerville &amp; Jacqueville',
  ].join('\n');
  window.open('https://wa.me/'+tel+'?text='+encodeURIComponent(msg),'_blank');
  addNotif('info',`Relance client ${client.nom} envoyée`);
  showToast('Relance WhatsApp → '+client.nom,'s');
}

// Badge for relance due prospects in navigation
function getProspectsBadgeCount(){
  if(badge==='relances') return DB.clients.filter(c=>isClientAncien(c)).length;
  if(badge==='chat'){
    const myId = CU?.id||'';
    return (DB.chat||[]).filter(m=>!m.readBy?.includes(myId)&&m.fromId!==myId).length;
  }
  return DB.prospects.filter(p=>isRelanceDue(p) && p.statut!=='converti').length
       + DB.clients.filter(c=>isClientAncien(c)).length;
}


async function convertirProspectEnClient(id){
  const p = DB.prospects.find(x=>x.id===id);
  if(!p){showToast('Prospect introuvable','w');return;}
  // Check if client already exists
  const existing = DB.clients.find(c=>c.tel&&p.tel&&c.tel===p.tel);
  if(existing){
    showToast(`${p.nom} est déjà client(e) ✓`,'s');
    p.statut='converti';
    await saveDB();
    renderProspects();
    return;
  }
  // Create client from prospect
  const newClientId = 'C'+Date.now().toString(36).toUpperCase();
  DB.clients.push({
    id: newClientId,
    nom: p.nom,
    tel: p.tel||'',
    type: p.type||'particulier',
    ville: p.ville||'',
    email: p.email||'',
    notes: p.notes||'',
    createdBy: CU.id,
    since: new Date().toISOString(),
  });
  p.statut='converti';
  addNotif('info',`Prospect ${p.nom} converti en client par ${CU.name}`);
  await saveDB();
  showToast(`${p.nom} converti(e) en client ✓`,'s');
  renderProspects();
}

async function supprimerProspect(id){
  if(!canDo('deleteClient')){showToast('Réservé administrateur','w');return;}
  if(!confirm('Supprimer ce prospect ?')) return;
  DB.prospects = DB.prospects.filter(p=>p.id!==id);
  await saveDB();
  showToast('Prospect supprimé','s');
  renderProspects();
}
// ════════════════════════════════════════════════════════
// EXPORT
// ════════════════════════════════════════════════════════
async function exportData(){
  const b=new Blob([JSON.stringify(DB,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download=`ilp_${new Date().toISOString().split('T')[0]}.json`;a.click();
  showToast('Export téléchargé ✓','s');
}

// ════════════════════════════════════════════════════════
// TOAST
// ════════════════════════════════════════════════════════
async function showToast(msg,t=''){
  const icons={s:'✅',w:'⚠️','':'ℹ️'};
  const el=document.createElement('div');el.className=`toast ${t}`;
  el.innerHTML=`<span>${icons[t]||'ℹ️'}</span><span class="toast-msg" style="font-size:12px;color:var(--blanc);flex:1">${msg}</span>`;
  document.getElementById('toasts').appendChild(el);
  setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .4s';setTimeout(()=>el.remove(),400);},3500);
}

// ════════════════════════════════════════════════════════
// PWA — Installation sur tous appareils
// ════════════════════════════════════════════════════════
let dPwA = null;

function isIOS(){ return /iphone|ipad|ipod/i.test(navigator.userAgent.toLowerCase()); }
function isStandalone(){ return window.matchMedia('(display-mode:standalone)').matches || !!window.navigator.standalone; }

async function initPWA(){
  // ── Service Worker réel (fichier externe sw.js) ───────
  if('serviceWorker' in navigator){
    try {
      const reg = await navigator.serviceWorker.register('./sw.js', {scope:'./'});
      reg.addEventListener('updatefound', () => {
        const newSW = reg.installing;
        newSW?.addEventListener('statechange', () => {
          if(newSW.state==='installed' && navigator.serviceWorker.controller){
            showToast('🔄 Mise à jour disponible — Rechargez pour l\'appliquer','');
          }
        });
      });
      console.log('[ILP] SW enregistré:', reg.scope);
    } catch(e){
      console.warn('[ILP] SW échec:', e.message);
    }
  }
}

// ── Événements PWA ──────────────────────────────────────
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  dPwA = e;
  setTimeout(() => {
    if(!isStandalone() && localStorage.getItem('ilp_banner_dismissed')!=='1'){
      const banner = document.getElementById('_installBanner');
      if(banner) banner.style.display = 'flex';
    }
  }, 2500);
});

window.addEventListener('appinstalled', () => {
  const banner = document.getElementById('_installBanner');
  if(banner) banner.style.display = 'none';
  showToast('✅ ILP TAB installée avec succès !','s');
});

async function installPWA(){
  if(dPwA){
    dPwA.prompt();
    const r = await dPwA.userChoice;
    if(r.outcome === 'accepted'){
      showToast('📲 Installation en cours...','s');
      document.getElementById('_installBanner').style.display='none';
    } else {
      showToast('Installation annulée','');
    }
    dPwA = null;
  } else if(isIOS()){
    _showInstallInstructions();
  } else if(isStandalone()){
    showToast('✅ Application déjà installée !','s');
  } else {
    _showInstallInstructions();
  }
}

function _showInstallInstructions(){
  const ua = navigator.userAgent.toLowerCase();
  const isChrome = /chrome/.test(ua) && !/edge/.test(ua);
  const isEdge = /edge|edg/.test(ua);
  const isSafari = /safari/.test(ua) && !/chrome/.test(ua);
  const isFirefox = /firefox/.test(ua);

  let steps = '';
  if(isIOS() && isSafari){
    steps = '<div style="margin-bottom:8px">Sur <strong>Safari iOS</strong> :</div>'+
      '<div>1. Appuyez sur <strong>□↑</strong> (partager) en bas</div>'+
      '<div>2. Faites d&eacute;filer et tapez <strong>Sur l\'&eacute;cran d\'accueil</strong></div>'+
      '<div>3. Appuyez sur <strong>"Ajouter"</strong></div>';
  } else if(isChrome){
    steps = '<div style="margin-bottom:8px">Sur <strong>Chrome</strong> :</div>'+
      '<div>1. Cliquez sur ⋮ (3 points) en haut à droite</div>'+
      '<div>2. S&eacute;lectionnez <strong>Installer l&apos;application</strong> ou <strong>Ajouter &agrave; l&apos;&eacute;cran d&apos;accueil</strong></div>';
  } else if(isEdge){
    steps = '<div style="margin-bottom:8px">Sur <strong>Edge</strong> :</div>'+
      '<div>1. Cliquez sur … (3 points) en haut à droite</div>'+
      '<div>2. S&eacute;lectionnez <strong>Applications &rarr; Installer ce site en tant qu&apos;application</strong></div>';
  } else if(isFirefox){
    steps = '<div style="margin-bottom:8px">Sur <strong>Firefox</strong> :</div>'+
      '<div>L&apos;installation PWA n&apos;est pas support&eacute;e nativement.<br>Utilisez Chrome ou Edge pour installer.</div>';
  } else {
    steps = '<div>Utilisez le menu de votre navigateur &rarr;<br><strong>Installer l&apos;application</strong> ou <strong>Ajouter &agrave; l&apos;&eacute;cran d&apos;accueil</strong></div>';
  }

  document.querySelectorAll('.ilp-install-modal').forEach(e=>e.remove());
  const modal = document.createElement('div');
  modal.className = 'ilp-install-modal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(6,13,31,.9);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
  modal.innerHTML = '<div style="background:var(--surface);border:1px solid rgba(201,168,76,.4);border-radius:12px;max-width:380px;width:100%;padding:24px">'+
    '<div style="font-family:var(--f-d);font-size:18px;color:var(--or-clair);margin-bottom:16px">📲 Installer ILP TAB</div>'+
    '<div style="font-size:13px;color:var(--blanc);line-height:1.8;margin-bottom:20px">'+steps+'</div>'+
    '<div style="text-align:right"><button class="btn btn-gold" onclick="document.querySelectorAll(\'.ilp-install-modal\').forEach(e=>e.remove())">Compris &#10003;</button></div>'+
    '</div>';
  document.body.appendChild(modal);
}

// ════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════
async function _initApp(){
  if(!window.supabase){
    console.error('[ILP] SDK Supabase non chargé');
    return;
  }
  try {
    _supa = window.supabase.createClient(SB_URL, SB_KEY);
    console.log('[ILP] Supabase OK');
  } catch(e){
    console.error('[ILP] createClient:', e);
    return;
  }
  await loadDB();
  loadTheme();
  if(typeof LOGO_B64 !== 'undefined'){
    const li = document.getElementById('loginLogo'); if(li) li.src = LOGO_B64;
    const tl = document.getElementById('topbarLogo'); if(tl) tl.src = LOGO_B64;
    const bl = document.getElementById('_bannerLogo');
    if(bl){
      const img = document.createElement('img');
      img.src = LOGO_B64;
      img.style.cssText = 'width:36px;height:36px;object-fit:contain;border-radius:8px;';
      bl.innerHTML = ''; bl.appendChild(img);
    }
  }
  if(isStandalone()){
    const b = document.getElementById('_installBanner'); if(b) b.style.display = 'none';
  }
  await initPWA();
  initLoginScreen();
  if(restoreSession()){
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    initApp();
  }
}

document.addEventListener('DOMContentLoaded', () => { _initApp(); });
