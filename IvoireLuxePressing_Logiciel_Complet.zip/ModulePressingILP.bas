
Attribute VB_Name = "ModulePressingILP"
Option Explicit

' ═══════════════════════════════════════════════════════════
'  CONSTANTES
' ═══════════════════════════════════════════════════════════
Const WS_TICKETS         As String = "TICKETS"
Const WS_DETAILS         As String = "DETAILS_TICKET"
Const WS_DEPENSES        As String = "DETAILS_DEPENSES"
Const WS_EDITION         As String = "EDITION"
Const WS_RECU            As String = "IMPRESSION_RECU_58MM"
Const WS_FACTURE         As String = "IMPRESSION_FACTURE_1PAGE"
Const WS_HISTORIQUE      As String = "MOIS_HISTORIQUE"
Const WS_PRESTATIONS     As String = "PRESTATIONS"
Const WS_CLIENTS         As String = "CLIENTS"
Const WS_PARAMS          As String = "PARAMETRES"

' ═══════════════════════════════════════════════════════════
'  UTILITAIRES
' ═══════════════════════════════════════════════════════════
Private Function GetParam(nom As String) As String
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets(WS_PARAMS)
    Dim i As Long
    For i = 2 To 20
        If ws.Cells(i, 1).Value = nom Then
            GetParam = CStr(ws.Cells(i, 2).Value)
            Exit Function
        End If
    Next i
    GetParam = ""
End Function

Private Function SetMessage(msg As String, isError As Boolean)
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets(WS_EDITION)
    ws.Range("B31:G32").Value = msg
    If isError Then
        ws.Range("B31:G32").Font.Color = RGB(231, 76, 60)
    Else
        ws.Range("B31:G32").Font.Color = RGB(46, 204, 113)
    End If
End Function

' ═══════════════════════════════════════════════════════════
'  GESTION ID MENSUEL
' ═══════════════════════════════════════════════════════════
Private Function GetNextTicketID(datDepot As Date) As String
    Dim moisCle As String
    moisCle = Format(datDepot, "YYYY-MM")
    
    Dim wsH As Worksheet
    Set wsH = ThisWorkbook.Sheets(WS_HISTORIQUE)
    
    Dim compteur As Long
    Dim foundRow As Long
    foundRow = 0
    Dim i As Long
    
    For i = 3 To 200
        If wsH.Cells(i, 1).Value = "" Then Exit For
        If wsH.Cells(i, 1).Value = moisCle Then
            foundRow = i
            Exit For
        End If
    Next i
    
    If foundRow = 0 Then
        ' Nouveau mois : ajouter ligne
        foundRow = i
        wsH.Cells(foundRow, 1).Value = moisCle
        wsH.Cells(foundRow, 2).Value = 1
        compteur = 1
    Else
        compteur = CLng(wsH.Cells(foundRow, 2).Value) + 1
        wsH.Cells(foundRow, 2).Value = compteur
    End If
    
    GetNextTicketID = moisCle & "/" & Format(compteur, "0000")
End Function

' ═══════════════════════════════════════════════════════════
'  NOUVEAU TICKET
' ═══════════════════════════════════════════════════════════
Sub NouveauTicket()
    Dim datDepot As Date
    datDepot = Date  ' Date du jour par défaut
    
    ' Demander date de dépôt
    Dim sDate As String
    sDate = InputBox("Date de dépôt (JJ/MM/AAAA) :", "Nouveau Ticket", Format(datDepot, "DD/MM/YYYY"))
    If sDate = "" Then Exit Sub
    
    On Error GoTo ErrDate
    datDepot = CDate(sDate)
    On Error GoTo 0
    
    ' Demander ID client
    Dim sClient As String
    sClient = InputBox("ID Client (ex: CLI001) :", "Nouveau Ticket")
    If sClient = "" Then
        Call SetMessage("⚠ Création annulée : client requis.", True)
        Exit Sub
    End If
    
    ' Vérifier client existe
    Dim wsC As Worksheet
    Set wsC = ThisWorkbook.Sheets(WS_CLIENTS)
    Dim clientFound As Boolean
    clientFound = False
    Dim ci As Long
    For ci = 3 To 200
        If wsC.Cells(ci, 1).Value = sClient Then
            clientFound = True
            Exit For
        End If
    Next ci
    
    If Not clientFound Then
        Call SetMessage("⚠ Client introuvable : " & sClient & ". Vérifiez l'onglet CLIENTS.", True)
        Exit Sub
    End If
    
    ' Générer ID
    Dim newID As String
    newID = GetNextTicketID(datDepot)
    
    ' Trouver première ligne vide dans TICKETS
    Dim wsT As Worksheet
    Set wsT = ThisWorkbook.Sheets(WS_TICKETS)
    Dim tRow As Long
    For tRow = 3 To 200
        If wsT.Cells(tRow, 1).Value = "" Then Exit For
    Next tRow
    
    ' Remplir le ticket
    wsT.Cells(tRow, 1).Value = newID         ' ID_TICKET (VERROUILLÉ)
    wsT.Cells(tRow, 2).Value = datDepot      ' DATE_DEPOT
    wsT.Cells(tRow, 4).Value = sClient       ' ID_CLIENT
    wsT.Cells(tRow, 6).Value = "Reçu"        ' STATUT initial
    
    ' Sélectionner le ticket dans EDITION
    Dim wsE As Worksheet
    Set wsE = ThisWorkbook.Sheets(WS_EDITION)
    wsE.Range("D8").Value = newID
    
    Call SetMessage("✅ Ticket créé : " & newID & " — Ajoutez les prestations dans DETAILS_TICKET.", False)
    
    ' Aller sur DETAILS_TICKET
    Dim wsD As Worksheet
    Set wsD = ThisWorkbook.Sheets(WS_DETAILS)
    wsD.Activate
    
    ' Trouver ligne vide dans DETAILS_TICKET et préremplir ID
    Dim dRow As Long
    For dRow = 3 To 600
        If wsD.Cells(dRow, 1).Value = "" Then Exit For
    Next dRow
    wsD.Cells(dRow, 1).Value = newID
    wsD.Cells(dRow, 2).Value = 1
    wsD.Cells(dRow, dRow).Select
    Exit Sub
    
ErrDate:
    Call SetMessage("⚠ Date invalide. Format requis : JJ/MM/AAAA", True)
End Sub

' ═══════════════════════════════════════════════════════════
'  VALIDATION AVANT GÉNÉRATION
' ═══════════════════════════════════════════════════════════
Private Function ValiderTicket(ticketID As String) As Boolean
    ValiderTicket = False
    
    If ticketID = "" Then
        Call SetMessage("⚠ Aucun ticket sélectionné.", True)
        Exit Function
    End If
    
    ' Vérifier ticket existe
    Dim wsT As Worksheet
    Set wsT = ThisWorkbook.Sheets(WS_TICKETS)
    Dim found As Boolean
    found = False
    Dim i As Long
    For i = 3 To 200
        If wsT.Cells(i, 1).Value = ticketID Then
            found = True
            Exit For
        End If
    Next i
    
    If Not found Then
        Call SetMessage("⚠ Ticket " & ticketID & " introuvable dans TICKETS.", True)
        Exit Function
    End If
    
    ' Vérifier lignes de prestations
    Dim wsD As Worksheet
    Set wsD = ThisWorkbook.Sheets(WS_DETAILS)
    Dim hasLines As Boolean
    hasLines = False
    For i = 3 To 600
        If wsD.Cells(i, 1).Value = ticketID And wsD.Cells(i, 3).Value <> "" Then
            hasLines = True
            Exit For
        End If
    Next i
    
    If Not hasLines Then
        Call SetMessage("⚠ Ticket sans lignes de prestation. Ajoutez des prestations dans DETAILS_TICKET.", True)
        Exit Function
    End If
    
    ValiderTicket = True
End Function

' ═══════════════════════════════════════════════════════════
'  REÇU THERMIQUE 58MM
' ═══════════════════════════════════════════════════════════
Sub GenererRecu()
    Dim wsE As Worksheet
    Set wsE = ThisWorkbook.Sheets(WS_EDITION)
    Dim ticketID As String
    ticketID = CStr(wsE.Range("D8").Value)
    
    If Not ValiderTicket(ticketID) Then Exit Sub
    
    ' Récupérer données ticket
    Dim wsT As Worksheet
    Set wsT = ThisWorkbook.Sheets(WS_TICKETS)
    Dim tRow As Long
    For tRow = 3 To 200
        If wsT.Cells(tRow, 1).Value = ticketID Then Exit For
    Next tRow
    
    Dim dateDepot As String
    dateDepot = Format(wsT.Cells(tRow, 2).Value, "DD/MM/YYYY")
    Dim nomClient As String
    nomClient = CStr(wsT.Cells(tRow, 5).Value)
    Dim statut As String
    statut = CStr(wsT.Cells(tRow, 6).Value)
    
    ' Récupérer lignes prestations
    Dim wsD As Worksheet
    Set wsD = ThisWorkbook.Sheets(WS_DETAILS)
    
    Dim wsR As Worksheet
    Set wsR = ThisWorkbook.Sheets(WS_RECU)
    
    ' Remplir infos ticket (lignes 5,6,7)
    wsR.Cells(5, 1).Value = "TICKET N° : " & ticketID
    wsR.Cells(6, 1).Value = "DATE     : " & dateDepot
    wsR.Cells(7, 1).Value = "CLIENT   : " & Left(nomClient, 22)
    
    ' Effacer les 15 lignes détail (commence ligne 10)
    Dim detailStart As Long
    detailStart = 10
    Dim i As Long
    For i = 0 To 14
        wsR.Cells(detailStart + i, 1).Value = ""
        wsR.Cells(detailStart + i, 2).Value = ""
        wsR.Cells(detailStart + i, 3).Value = ""
    Next i
    
    ' Remplir lignes prestations
    Dim totalPresta As Double
    totalPresta = 0
    Dim lineCount As Long
    lineCount = 0
    
    For i = 3 To 600
        If wsD.Cells(i, 1).Value = ticketID Then
            If wsD.Cells(i, 3).Value <> "" And lineCount < 15 Then
                Dim libl As String
                libl = Left(CStr(wsD.Cells(i, 4).Value), 18)
                Dim qte As Double
                qte = CDbl(wsD.Cells(i, 5).Value)
                Dim pu As Double
                pu = CDbl(wsD.Cells(i, 6).Value)
                Dim stLine As Double
                stLine = qte * pu
                totalPresta = totalPresta + stLine
                
                Dim rRow As Long
                rRow = detailStart + lineCount
                wsR.Cells(rRow, 1).Value = libl
                wsR.Cells(rRow, 2).Value = qte
                wsR.Cells(rRow, 3).Value = Format(stLine, "#,##0") & " F"
                lineCount = lineCount + 1
            End If
        End If
    Next i
    
    ' Dépenses (commence ligne 28 = après détails + séparateur)
    Dim wsDP As Worksheet
    Set wsDP = ThisWorkbook.Sheets(WS_DEPENSES)
    
    Dim depStart As Long
    depStart = 28
    For i = 0 To 4
        wsR.Cells(depStart + i, 1).Value = ""
        wsR.Cells(depStart + i, 2).Value = ""
        wsR.Cells(depStart + i, 3).Value = ""
    Next i
    
    Dim totalDep As Double
    totalDep = 0
    Dim depCount As Long
    depCount = 0
    
    For i = 3 To 300
        If wsDP.Cells(i, 1).Value = ticketID Then
            If depCount < 5 Then
                Dim depLibl As String
                depLibl = Left(CStr(wsDP.Cells(i, 2).Value), 18)
                Dim depMnt As Double
                depMnt = CDbl(wsDP.Cells(i, 3).Value)
                totalDep = totalDep + depMnt
                wsR.Cells(depStart + depCount, 1).Value = depLibl
                wsR.Cells(depStart + depCount, 3).Value = Format(depMnt, "#,##0") & " F"
                depCount = depCount + 1
            End If
        End If
    Next i
    
    ' Totaux (lignes 35, 36, 37)
    Dim totRow As Long
    totRow = 35
    wsR.Cells(totRow, 3).Value = Format(totalPresta, "#,##0") & " F"
    wsR.Cells(totRow + 1, 3).Value = Format(totalDep, "#,##0") & " F"
    wsR.Cells(totRow + 2, 3).Value = Format(totalPresta + totalDep, "#,##0") & " F"
    
    ' Activer l'onglet reçu
    wsR.Activate
    
    Call SetMessage("✅ Reçu généré pour " & ticketID & " — Imprimez l'onglet IMPRESSION_RECU_58MM.", False)
    wsE.Activate
End Sub

' ═══════════════════════════════════════════════════════════
'  FACTURE GLOBALE 1 PAGE
' ═══════════════════════════════════════════════════════════
Sub GenererFacture()
    Dim wsE As Worksheet
    Set wsE = ThisWorkbook.Sheets(WS_EDITION)
    Dim ticketID As String
    ticketID = CStr(wsE.Range("D8").Value)
    
    If Not ValiderTicket(ticketID) Then Exit Sub
    
    ' Données ticket
    Dim wsT As Worksheet
    Set wsT = ThisWorkbook.Sheets(WS_TICKETS)
    Dim tRow As Long
    For tRow = 3 To 200
        If wsT.Cells(tRow, 1).Value = ticketID Then Exit For
    Next tRow
    
    Dim dateDepot As String
    dateDepot = Format(wsT.Cells(tRow, 2).Value, "DD/MM/YYYY")
    Dim nomClient As String
    nomClient = CStr(wsT.Cells(tRow, 5).Value)
    Dim statut As String
    statut = CStr(wsT.Cells(tRow, 6).Value)
    
    Dim wsF As Worksheet
    Set wsF = ThisWorkbook.Sheets(WS_FACTURE)
    
    ' Remplir infos ticket
    wsF.Range("D8").Value = ticketID
    wsF.Range("D9").Value = dateDepot
    wsF.Range("D10").Value = nomClient
    wsF.Range("D11").Value = statut
    
    ' Effacer détails (lignes 15 à 29)
    Dim i As Long
    For i = 15 To 29
        wsF.Cells(i, 2).Value = ""
        wsF.Cells(i, 4).Value = ""
        wsF.Cells(i, 5).Value = ""
        wsF.Cells(i, 6).Value = ""
    Next i
    
    ' Remplir lignes prestations
    Dim wsD As Worksheet
    Set wsD = ThisWorkbook.Sheets(WS_DETAILS)
    
    Dim totalPresta As Double
    totalPresta = 0
    Dim lineCount As Long
    lineCount = 0
    
    For i = 3 To 600
        If wsD.Cells(i, 1).Value = ticketID Then
            If wsD.Cells(i, 3).Value <> "" And lineCount < 15 Then
                Dim fRow As Long
                fRow = 15 + lineCount
                wsF.Cells(fRow, 2).Value = CStr(wsD.Cells(i, 4).Value)  ' Désignation
                wsF.Cells(fRow, 4).Value = CDbl(wsD.Cells(i, 6).Value)  ' PU
                wsF.Cells(fRow, 5).Value = CDbl(wsD.Cells(i, 5).Value)  ' Qté
                wsF.Cells(fRow, 6).Value = CDbl(wsD.Cells(i, 7).Value)  ' Total
                totalPresta = totalPresta + CDbl(wsD.Cells(i, 7).Value)
                lineCount = lineCount + 1
            End If
        End If
    Next i
    
    ' Dépenses (lignes 32 à 36)
    Dim wsDP As Worksheet
    Set wsDP = ThisWorkbook.Sheets(WS_DEPENSES)
    
    For i = 32 To 36
        wsF.Cells(i, 4).Value = ""
        wsF.Cells(i, 6).Value = ""
    Next i
    
    Dim totalDep As Double
    totalDep = 0
    Dim depCount As Long
    depCount = 0
    
    For i = 3 To 300
        If wsDP.Cells(i, 1).Value = ticketID Then
            If depCount < 5 Then
                wsF.Cells(32 + depCount, 4).Value = CStr(wsDP.Cells(i, 2).Value)
                wsF.Cells(32 + depCount, 6).Value = CDbl(wsDP.Cells(i, 3).Value)
                totalDep = totalDep + CDbl(wsDP.Cells(i, 3).Value)
                depCount = depCount + 1
            End If
        End If
    Next i
    
    ' Totaux (lignes 38, 39, 40)
    wsF.Cells(38, 6).Value = totalPresta
    wsF.Cells(39, 6).Value = totalDep
    wsF.Cells(40, 6).Value = totalPresta + totalDep
    
    ' Activer onglet facture
    wsF.Activate
    
    Call SetMessage("✅ Facture générée pour " & ticketID & " — Imprimez l'onglet IMPRESSION_FACTURE_1PAGE.", False)
    wsE.Activate
End Sub

' ═══════════════════════════════════════════════════════════
'  RÉINITIALISER
' ═══════════════════════════════════════════════════════════
Sub ResetFormulaire()
    Dim wsE As Worksheet
    Set wsE = ThisWorkbook.Sheets(WS_EDITION)
    wsE.Range("D8").Value = ""
    Call SetMessage("🔄 Formulaire réinitialisé. Sélectionnez un ticket.", False)
End Sub

' ═══════════════════════════════════════════════════════════
'  MISE À JOUR STATS MENSUELLES
' ═══════════════════════════════════════════════════════════
Sub UpdateStatsMensuel()
    Dim wsH As Worksheet
    Set wsH = ThisWorkbook.Sheets(WS_HISTORIQUE)
    Dim wsT As Worksheet
    Set wsT = ThisWorkbook.Sheets(WS_TICKETS)
    
    Dim i As Long, j As Long
    
    For i = 3 To 100
        Dim mois As String
        mois = CStr(wsH.Cells(i, 1).Value)
        If mois = "" Then Exit For
        
        Dim totPr As Double, totDep As Double, nbTkt As Long
        totPr = 0 : totDep = 0 : nbTkt = 0
        
        For j = 3 To 200
            Dim tID As String
            tID = CStr(wsT.Cells(j, 1).Value)
            If tID = "" Then Exit For
            If Left(tID, 7) = mois Then
                nbTkt = nbTkt + 1
                totPr = totPr + CDbl(wsT.Cells(j, 7).Value)
                totDep = totDep + CDbl(wsT.Cells(j, 8).Value)
            End If
        Next j
        
        wsH.Cells(i, 3).Value = nbTkt
        wsH.Cells(i, 4).Value = totPr
        wsH.Cells(i, 5).Value = totDep
        wsH.Cells(i, 6).Value = totPr + totDep
    Next i
    
    MsgBox "Statistiques mensuelles mises à jour !", vbInformation
End Sub
